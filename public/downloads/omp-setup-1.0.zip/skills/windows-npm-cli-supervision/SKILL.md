---
name: windows-npm-cli-supervision
description: "Use when a supervised or PTY-spawned process on Windows fails with os error 193 / '%1 is not a valid Win32 application' or ENOENT uv_spawn, when launching any global npm CLI under process supervision, or when diagnosing which process owns a TCP port."
---

# Supervising npm CLIs on Windows

## The failure

Global npm packages install `.cmd`/`.ps1` shims into `%APPDATA%\npm%` (`C:/Users/__USERNAME__/AppData/Roaming/npm/` on this machine). Process supervision spawns via `CreateProcessW`/`uv_spawn`, which cannot execute `.cmd` scripts directly. Observed symptoms:

- `Failed to launch ...: ENOENT: no such file or directory, uv_spawn '<tool>'` (hub `start`)
- `Failed to spawn PTY command: CreateProcessW ... %1 is not a valid Win32 application. (os error 193)`

Plain `bash` calls work (the shell resolves the shim); supervised `start` does not.

## The fix

Bypass the shim — launch node with the package's real bin script:

1. Find the entry point: read the shim (`%APPDATA%/npm/<tool>.cmd`) — last line names the script, typically `%APPDATA%/npm/node_modules/<pkg>/bin/<file>.js`. Or check `bin` in the package's `package.json`.
2. Supervise as:
   ```
   application: node
   args: ["C:/Users/__USERNAME__/AppData/Roaming/npm/node_modules/<pkg>/bin/<file>.js", "<subcommand>", ...]
   ```
3. Prefer `ready.log` (a banner regex) over `ready.port` when the tool may auto-increment past busy ports.

Same principle for other script shims: python tools → `python <script>`, never the `.cmd`.

## Port diagnostics

- Owners: `netstat -ano | findstr :<port>` → PID → `tasklist /FI "PID eq <pid>"`.
- Full command line of a PID: `powershell -NoProfile -Command "Get-CimInstance Win32_Process -Filter 'ProcessId=<pid>' | Select -ExpandProperty CommandLine"` — always check this BEFORE killing anything.
- On some Windows machines port 7680 is held by `svchost.exe` (Delivery Optimization / DoSvc) — it accepts TCP then drops HTTP, looking like a flaky app. On THIS machine (__USERNAME__) 7680 is normally free and is used by the TokenTracker dashboard — verify with netstat, don't assume.
- Kill a verified duplicate with its children: `taskkill /PID <pid> /T /F`.
