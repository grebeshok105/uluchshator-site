# Skills Index

Installed skills in `~/.claude/skills`. Load on demand via `skill://<name>`.

## Process (superpowers)

| Skill | Use when |
|---|---|
| `brainstorming` | You MUST use this before any creative work - creating features, building components, adding functionality, or  |
| `dispatching-parallel-agents` | Use when facing 2+ independent tasks that can be worked on without shared state or sequential dependencies |
| `executing-plans` | Use when you have a written implementation plan to execute in a separate session with review checkpoints |
| `finishing-a-development-branch` | Use when implementation is complete, all tests pass, and you need to decide how to integrate the work |
| `nodumb` | Use when собираешься реализовать решение, фикс, фичу, дизайн — перед выполнением первой идеи, пришедшей в голову. Несколько вариантов решения, цена ошибки высока, просят сравнить плюсы/минусы. Не для тривиальных правок и явно предписанных способов |
| `receiving-code-review` | Use when receiving code review feedback, before implementing suggestions, especially if feedback seems unclear |
| `requesting-code-review` | Use when completing tasks, implementing major features, or before merging to verify work meets requirements |
| `rule-of-four` | Use when a task is large enough to warrant a 5-block plan — «правило четырёх»: 4 scouts → plan-spec into 5 blocks → 4 workers + main block → user-gated 4 reviewers |
| `subagent-driven-development` | Use when executing implementation plans with independent tasks in the current session |
| `systematic-debugging` | Use when encountering any bug, test failure, or unexpected behavior, before proposing fixes |
| `using-git-worktrees` | Use when starting feature work that needs isolation from current workspace or before executing implementation  |
| `using-superpowers` | Use when starting any conversation - establishes how to find and use skills, requiring skill invocation before |
| `verification-before-completion` | Use when about to claim work is complete, fixed, or passing, before committing or creating PRs - requires runn |
| `writing-plans` | Use when you have a spec or requirements for a multi-step task, before touching code |
| `writing-skills` | Use when creating new skills, editing existing skills, or verifying skills work before deployment |

| `omp-self-orchestration` | Session bootstrap #3 with using-superpowers and skill-system. Use at the start of every main omp session (FIRST ACTION loads this via CLAUDE.md), and whenever doing non-trivial coding — bugfix, feature, multi-file change, issue implementation, qualitygate — or when editing alone without task/scout/tester. |
| `skill-system` | Session bootstrap companion to using-superpowers. Use at the start of every main session (FIRST ACTION loads this via CLAUDE.md). Explains how the skill system works, how to discover and load skills, and Matt Pocock / Agent Skills rules — progressive disclosure, description-triggered load, keep bodies lean. |
## Design / frontend

| Skill | Use when |
|---|---|
| `audit-design` | Audit the current project's frontend code for TailwindCSS design violations, anti-patterns, and inconsistencie |
| `brandkit` | Premium brand-kit image generation skill for creating high-end brand-guidelines boards, logo systems, identity |
| `design-taste-frontend` | Anti-slop frontend skill for landing pages, portfolios, and redesigns. The agent reads the brief, infers the r |
| `generate-component` | Generate a production-ready TailwindCSS UI component skeleton that matches the project's design system. Use wh |
| `gpt-taste` | Elite UX/UI & Advanced GSAP Motion Engineer. Enforces Python-driven true randomization for layout variance, st |
| `high-end-visual-design` | Teaches the AI to design like a high-end agency. Defines the exact fonts, spacing, shadows, card structures, a |
| `image-to-code` | Elite website image-to-code skill for Codex. For visually important web tasks, it must first generate the desi |
| `industrial-brutalist-ui` | Raw mechanical interfaces fusing Swiss typographic print with military terminal aesthetics. Rigid grids, extre |
| `minimalist-ui` | Clean editorial-style interfaces. Warm monochrome palette, typographic contrast, flat bento grids, muted paste |
| `redesign-existing-projects` | Upgrades existing websites and apps to premium quality. Audits current design, identifies generic AI patterns, |
| `stitch-design-taste` | Semantic Design System Skill for Google Stitch. Generates agent-friendly DESIGN.md files that enforce premium, |

| `frontend-bootstrap` | Активатор дизайн/фронтенд-скиллов: перед фронт-задачей загрузить профильный скилл по типу (design-taste-frontend, redesign-existing-projects, design-extract, image-to-code, brandkit, industrial-brutalist-ui, minimalist-ui, generate-component, audit-design, gpt-taste, high-end-visual-design); анти-слоуп-минимум; проверка браузером |
| `frontend-ai-rules` | ОБЯЗАТЕЛЕН для ЛЮБОЙ фронт-задачи: дизайн-правила владельца AI-RULES v3 (hero/композиция/типографика/CTA/motion/бан-лист/чеклист) — грузить ДО профильного скилла |
## Tools / process

| Skill | Use when |
|---|---|
| `agent-setup-verification` | Use when validating, auditing, or repairing this machine's omp agent environment — MCP servers not responding, LSP failures, skills not resolving, missing tokens, or after editing config files in ~/.omp/agent/ |
| `claude-md-hygiene` | Use when editing CLAUDE.md/AGENTS.md, deciding whether something belongs in CLAUDE.md vs a skill vs a referenc |
| `codebase-engineering` | Use when working on a user's codebase as an engineer—cloning repos, creating branches, making PRs, debugging,  |
| `codebase-memory` | Use the codebase knowledge graph for structural code queries. Triggers on: explore the codebase, understand th |
| `deploying-omp-skills` | Use when creating, installing, moving, or registering an agent skill on this machine, or when a written skill does not resolve via skill:// |
| `engineering-patterns` | Use when coding, reviewing, explaining code, or working with PRs — 14 proven coding patterns (Continue/Cline)  |
| `fable-domain` | Discuss a domain with the user, research it from real sources, then generate a trusted skill bundle for it — workflow with flowchart, domain adapter, trap fixture, smoke eval. Use when the user says "/fable-domain <sector>", "make a skill for <domain>", "add a domain to the fable method" |
| `fable-judge` | Adversarial verification of finished work: re-runs claimed verifications, diffs what changed, detects weakened tests and false completion, verdict VERIFIED / VERIFIED WITH CAVEATS / REFUTED. Use after any agent or model claims work is complete — "/fable-judge", "judge this work", "verify what it did" |
| `fable-method` | A step-by-step problem-solving loop (classify the ask, define done, gather evidence, decide, act surgically, verify by observation, report outcome-first). Use when the user says "/fable-method", "use the fable method", "approach this like Fable", or proactively on any multi-step task no task-specific skill covers |
| `find-skills` | Helps users discover and install agent skills when they ask questions like "how do I do X", "find a skill for  |
| `full-output-enforcement` | Overrides default LLM truncation behavior. Enforces complete code generation, bans placeholder patterns, and h |
| `github-pr-workflow` | Use when working with GitHub pull requests, creating or updating PRs, pushing branches, using GitHub CLI gh, c |
| `knowledge-loop` | Use when начинаешь или завершаешь нетривиальную задачу — recall прошлых findings/решений/failure-patterns из Mnemopi и RAG до работы, capture переиспользуемых выводов после, promotion finding → rule → skill. Не для тривиальных правок |
| `knowledge-rag-setup` | Use when настраивать knowledge-rag MCP для нового проекта — создать базу RAG, config.yaml, запись в ~/.omp/age |
| `launching-tokentracker` | Use when starting, restarting, or checking the TokenTracker AI token/cost dashboard at http://localhost:7680 — "подними токен трекер", "tokentracker не работает", port 7680 down |
| `project-bootstrapper` | Use when user asks «активируй улучшатора» / «улучши настройку проекта» / project setup — read-only аудит и настройка локальной обвязки проекта: AGENTS.md, SESSION.md, RAG, codegraph, проектные скиллы; запись только после подтверждения |
| `prompt-optimizer` | Analyze raw prompts, identify intent and gaps, match ECC components (skills/commands/agents/hooks), and output |
| `security-review` | Use this skill when adding authentication, handling user input, working with secrets, creating API endpoints,  |
| `skill-creation` | Create reusable skills with proper structure and frontmatter. Use when creating or editing a skill or workflow |
| `subagent-contract` | Use when working as a delegated subagent: report contract, scope discipline, honesty, and verification rules. Autoloaded by executor roles |
| `tdd` | Test-driven development. Use when the user wants to build features or fix bugs test-first, mentions "red-green |
| `transferring-omp-setup` | Use when переносить конфигурацию omp на другой ПК или собирать/обновлять архив переноса — «собери omp-setup.zip», «перенеси настройки на второй пк» |
| `windows-npm-cli-supervision` | Use when a supervised or PTY-spawned process on Windows fails with os error 193 / '%1 is not a valid Win32 application' or ENOENT uv_spawn, or when diagnosing which process owns a TCP port |
Total: 53 skills.