---
name: skill-system
description: "Session bootstrap companion to using-superpowers. Use at the start of every main session (FIRST ACTION loads this via CLAUDE.md). Explains how the skill system works, how to discover and load skills, and Matt Pocock / Agent Skills rules — progressive disclosure, description-triggered load, keep bodies lean."
---

# Skill System

## Overview

Skills are on-demand playbooks. Only each skill’s **description** sits in context; the body loads when you `read skill://name` (or `/skill-name`).

This skill is the **system map** (how skills work).  
`using-superpowers` is the **enforcement** (you must actually load matching skills).  
Load **both** at session start. Neither replaces the other.

## Matt Pocock / Agent Skills rules

These are the durable rules (Matt Pocock-style Agent Skills, same family as Anthropic skills):

1. **Progressive disclosure** — description in context is cheap; full body is loaded only when needed. Do not paste entire skill libraries into CLAUDE.md.
2. **Description is the trigger** — match on **description**, not filename. If the description fits the task even ~1%, load the skill.
3. **One skill = one job** — focused playbook, not a novel. Prefer a small skill over a bloated CLAUDE.md section.
4. **CLAUDE.md / AGENTS.md stays thin** — durable always-on rules only. Procedures live in skills.
5. **Load before acting** — `read skill://…` before the workflow that skill governs (explore, edit, test, dispatch).
6. **Follow the loaded skill** — after read, execute it; do not skim and improvise a weaker version.
7. **Announce lightly** — “using X for Y” then do the steps (checklists → todos when the skill says so).

## How discovery works here

1. Session starts → bootstrap set (4: `using-superpowers`, `skill-system`, `omp-self-orchestration`, `frontend-bootstrap` — см. FIRST ACTION в CLAUDE.md).
2. Task arrives → scan discovered skill **descriptions**.
3. Match → `read skill://name` **before** the work that skill covers.
4. Skill overrides default behavior where it conflicts.
5. More than one match → load process/orchestration skills first, then implementation skills.

## Bootstrap set (main sessions)

Every **main** session (not a dispatched subagent), first tool batch:

| # | skill | role |
|---|--------|------|
| 1 | `using-superpowers` | must-load enforcement |
| 2 | `skill-system` | this file — how skills work (Matt Pocock rules) |
| 3 | `omp-self-orchestration` | default subagent fan-out |
| 4 | `frontend-bootstrap` | диспетчер дизайн/фронтенд-скиллов: грузится всегда, активирует профильный при фронт-задачах |

Skipping any of the four silently degrades the session.

## When to load more skills

| situation | load |
|-----------|------|
| 2+ independent slices / issue fix multi-file | `dispatching-parallel-agents` (via orchestration skill) |
| bug / unexpected failure | `systematic-debugging` |
| about to claim done / fixed / green | `verification-before-completion` |
| writing or editing a skill | `writing-skills` |
| CLAUDE.md vs skill placement | `claude-md-hygiene` |

## Anti-patterns

| don’t | do |
|-------|-----|
| only load `using-superpowers` then code | load the full bootstrap set, then task skills |
| dump procedures into CLAUDE.md | new/updated **skill** |
| “I know this skill” without read | `read skill://…` every session you need it |
| match on skill **name** only | match on **description** |
| treat description list as “already loaded” | description ≠ body; body needs `read` |
| read skill then ignore it | **execute** the skill steps (hooks will nag if you skip) |
| call `task` without `tasks[].agent` | always set `agent: scout\|reviewer\|tester\|…` |

## Subagents

If you were dispatched as a subagent: skip this bootstrap set; follow `subagent-contract` and the task brief only.

## Related

- `using-superpowers` — mandatory invoke rule  
- `omp-self-orchestration` — self fan-out  
- `writing-skills` / `claude-md-hygiene` — authoring and placement  
