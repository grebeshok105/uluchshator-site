---
name: launching-tokentracker
description: "Use when starting, restarting, or checking the TokenTracker AI token/cost dashboard at http://localhost:7680 — \"подними токен трекер\", \"tokentracker не работает\", port 7680 down. Not for interpreting usage data."
---

# Launching TokenTracker

## Overview
TokenTracker = локальный dashboard расхода токенов по всем агентам (omp, Codex, Claude, opencode, Grok): расходы по провайдерам, cache-hit rate, daily breakdown. Сервер слушает `http://localhost:7680`, данные живут в `~/.tokentracker/`.

## Critical rule (Windows)
НИКОГДА не запускай сервер командой `tokentracker` / `tokentracker.cmd` из omp/hub — uv_spawn не резолвит Windows .cmd-шимы. Всегда запускай через node с полным путём к `tracker.js`.

## Steps

### 1. Найти tracker.js
Путь (если неизвестен): `npm root -g` → `node_modules\tokentracker-cli\bin\tracker.js`, или `where tokentracker` → рядом `node_modules\...\bin\tracker.js`.

### 2. Проверить, не запущен ли уже
`fetch('http://localhost:7680')` → HTTP 200 = сервер работает, ничего делать не надо.

### 3. Запуск
Сначала `hub` `op: start`:
- name: `tokentracker`
- application: `node`
- args: `["<путь>\tracker.js", "serve", "--port", "7680", "--no-open"]`
- ready: `{"port": 7680}`
Если 7680 занят чужим процессом — tokentracker сам авто-инкрементит порт; тогда вместо ready.port используй ready.log: `{"log": "dashboard running at"}` и читай фактический порт из логов процесса.

Если hub падает с `Failed to start daemon broker: connect ENOENT \\.\pipe\omp-daemon-...` — fallback: `bash` с `async: true` и той же node-командой. **В fallback обязательно `timeout: 0`** — дефолтный дедлайн 300 с убивает сервер.

### 4. Проверка
`fetch('http://localhost:7680')` → HTTP 200, title `Token Tracker — AI Token Usage & Cost Tracker for Coding CLIs`.

### 4b. Проверка данных (не только страницы)
`fetch('http://127.0.0.1:7680/functions/tokentracker-usage-summary')` → JSON, поле `rolling.last_7d.totals.billable_total_tokens` > 0, когда данные есть. Топ-левел `totals` = 0 без date range — норма. Корень — Vite SPA: статический маркетинговый текст на главной — не ошибка.

## Edge cases
- `--no-open` обязателен при запуске из агента — иначе откроется браузер пользователя.
- Порт уже занят → сервер работает (или другой процесс): проверь ответ на 7680.
- Fetch сразу после старта может обогнать node — подожди 2–3 сек и повтори.
- Управление процессом (стоп/рестарт) из omp возможно только если он запущен через hub; после fallback через bash — убивать по job id или порту.
- Фоновый job сам сообщает о завершении (`Command timed out`) — после этого обязательно проверить порт: сервер скорее всего мёртв, перезапустить.

## Troubleshooting
| Error | Cause | Solution |
|---|---|---|
| `Failed to start daemon broker: connect ENOENT` | hub-брокер не поднят | bash async + node напрямую |
| `ERR fetch failed` на 7680 | сервер ещё стартует или упал | sleep 3, повтор; смотреть лог job'а |
| `tokentracker` не резолвится в omp | .cmd-шим, uv_spawn его не понимает | node + полный путь к tracker.js |
| Job завершился с `Command timed out after 300 seconds` | bash async убил процесс по дедлайну | перезапуск с `timeout: 0` |
