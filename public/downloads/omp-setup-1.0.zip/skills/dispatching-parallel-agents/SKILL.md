---
name: dispatching-parallel-agents
description: Use when facing 2+ independent tasks that can be worked on without shared state or sequential dependencies
---

# Dispatching Parallel Agents

## Overview

You delegate tasks to specialized agents with isolated context. By precisely crafting their instructions and context, you ensure they stay focused and succeed at their task. They should never inherit your session's context or history — you construct exactly what they need. This also preserves your own context for coordination work.

When you have multiple unrelated failures (different test files, different subsystems, different bugs), investigating them sequentially wastes time. Each investigation is independent and can happen in parallel.

**Core principle:** Dispatch one agent per independent problem domain. Let them work concurrently.

## When to Use

```dot
digraph when_to_use {
    "Multiple failures?" [shape=diamond];
    "Are they independent?" [shape=diamond];
    "Single agent investigates all" [shape=box];
    "One agent per problem domain" [shape=box];
    "Can they work in parallel?" [shape=diamond];
    "Sequential agents" [shape=box];
    "Parallel dispatch" [shape=box];

    "Multiple failures?" -> "Are they independent?" [label="yes"];
    "Are they independent?" -> "Single agent investigates all" [label="no - related"];
    "Are they independent?" -> "Can they work in parallel?" [label="yes"];
    "Can they work in parallel?" -> "Parallel dispatch" [label="yes"];
    "Can they work in parallel?" -> "Sequential agents" [label="no - shared state"];
}
```

**Use when:**
- 3+ test files failing with different root causes
- Multiple subsystems broken independently
- Each problem can be understood without context from others
- No shared state between investigations

**Don't use when:**
- Failures are related (fix one might fix others)
- Need to understand full system state
- Agents would interfere with each other

## The Pattern

### 1. Identify Independent Domains

Group failures by what's broken:
- File A tests: Tool approval flow
- File B tests: Batch completion behavior
- File C tests: Abort functionality

Each domain is independent - fixing tool approval doesn't affect abort tests.

### 2. Create Focused Agent Tasks

Each agent gets:
- **Specific scope:** One test file or subsystem
- **Clear goal:** Make these tests pass
- **Constraints:** Don't change other code
- **Expected output:** Summary of what you found and fixed

### 3. Dispatch in Parallel

Issue all three subagent dispatches in the same response — they run in parallel:

```text
Subagent (general-purpose): "Fix agent-tool-abort.test.ts failures"
Subagent (general-purpose): "Fix batch-completion-behavior.test.ts failures"
Subagent (general-purpose): "Fix tool-approval-race-conditions.test.ts failures"
# All three run concurrently.
```

Multiple dispatch calls in one response = parallel execution. One per response = sequential.

### 4. Dispatch-and-Continue: work while agents run

Dispatch is NOT a waiting point. After the batch, immediately continue any
independent work that does not depend on the agents' results: other slices,
preparing integration points, scaffolding, docs, your own share of the task.

- Results arrive on their own (auto-delivery). Consume them as they settle —
  do not hold integration hostage to the slowest agent.
- Waiting is allowed ONLY at an explicit synchronization barrier: before
  integrating a result your next step depends on, before the final
  verification / merge, or before declaring the task done.
- Never: start integrating before the research you delegated is back; make
  architectural decisions you already delegated; finish the task before the
  results arrive; do the delegated work yourself in parallel (you will get a
  conflicting answer and waste the dispatch).
- A slow or hung agent is not a blocker for the rest: keep working on
  independent slices; if it is clearly stuck, `hub cancel` it and re-dispatch
  or take the slice yourself.

### 5. Review and Integrate (at the sync barrier)

Integrate when the result your next step depends on has arrived — not when
every agent has returned:
- Consume each settled result: read the summary, verify the changes
- Check for conflicts between completed slices
- Run the full suite / verification once the dependent results are in
- If one slice is still running and the next step does not depend on it,
  proceed and fold it in when it lands

## Agent Prompt Structure

Good agent prompts are:
1. **Focused** - One clear problem domain
2. **Self-contained** - All context needed to understand the problem
3. **Specific about output** - What should the agent return?

```markdown
Fix the 3 failing tests in src/agents/agent-tool-abort.test.ts:

1. "should abort tool with partial output capture" - expects 'interrupted at' in message
2. "should handle mixed completed and aborted tools" - fast tool aborted instead of completed
3. "should properly track pendingToolCount" - expects 3 results but gets 0

These are timing/race condition issues. Your task:

1. Read the test file and understand what each test verifies
2. Identify root cause - timing issues or actual bugs?
3. Fix by:
   - Replacing arbitrary timeouts with event-based waiting
   - Fixing bugs in abort implementation if found
   - Adjusting test expectations if testing changed behavior

Do NOT just increase timeouts - find the real issue.

Return: Summary of what you found and what you fixed.
```

## Common Mistakes

**❌ Too broad:** "Fix all the tests" - agent gets lost
**✅ Specific:** "Fix agent-tool-abort.test.ts" - focused scope

**❌ No context:** "Fix the race condition" - agent doesn't know where
**✅ Context:** Paste the error messages and test names

**❌ No constraints:** Agent might refactor everything
**✅ Constraints:** "Do NOT change production code" or "Fix tests only"

**❌ Vague output:** "Fix it" - you don't know what changed
**✅ Specific:** "Return summary of root cause and changes"

**❌ Dispatch, then wait for everyone before touching anything:** the slowest agent stalls the whole task
**✅ Dispatch-and-continue:** dispatch, keep working independent slices, sync only at the barrier your next step needs

## When NOT to Use

**Related failures:** Fixing one might fix others - investigate together first
**Need full context:** Understanding requires seeing entire system
**Exploratory debugging:** You don't know what's broken yet
**Shared state:** Agents would interfere (editing same files, using same resources)

## Real Example from Session

**Scenario:** 6 test failures across 3 files after major refactoring

**Failures:**
- agent-tool-abort.test.ts: 3 failures (timing issues)
- batch-completion-behavior.test.ts: 2 failures (tools not executing)
- tool-approval-race-conditions.test.ts: 1 failure (execution count = 0)

**Decision:** Independent domains - abort logic separate from batch completion separate from race conditions

**Dispatch:**
```
Agent 1 → Fix agent-tool-abort.test.ts
Agent 2 → Fix batch-completion-behavior.test.ts
Agent 3 → Fix tool-approval-race-conditions.test.ts
```

**Results:**
- Agent 1: Replaced timeouts with event-based waiting
- Agent 2: Fixed event structure bug (threadId in wrong place)
- Agent 3: Added wait for async tool execution to complete

**Integration:** All fixes independent, no conflicts, full suite green

## Verification

After agents return:
1. **Review each summary** - Understand what changed
2. **Check for conflicts** - Did agents edit same code?
3. **Run full suite** - Verify all fixes work together
4. **Spot check** - Agents can make systematic errors

## Roles on this machine

This machine (omp, Windows) has dedicated agent roles — pick the most specific one for each slice instead of defaulting to the general worker:

| Task | Role | Notes |
|---|---|---|
| Codebase exploration, rapid research | `scout` | read-only; has codegraph + project RAG |
| General multi-step work with edits | `task` | full tools; has codegraph + RAG + context7 |
| Running tests, reproducing failures, regressions | `tester` | read-only (no edits); bash + codegraph + RAG; reports runs/failures/next_steps |
| Condensing multiple large reports | `briefer` | read-only; verbatim reads (`read-summarize: false`); structured brief incl. contradictions |
| UI/UX implementation or review | `designer` | loads taste skills (design-taste-frontend, gpt-taste, high-end-visual-design, ...) |
| Code review | `reviewer` | read-only; P0-P3 findings; has codegraph + RAG |
| Security review | `security-reviewer` | read-only; severity/CWE/evidence |
| Library/API research from source | `librarian` | read-only; verbatim source evidence |
| Mechanical updates, data collection | `sonic` | cheap model; same prompt as task |

Notes:
- Roles marked read-only never edit project files; they also never gain write tools from a dispatch.
- Executor roles (`task`, `tester`, `briefer`, `sonic`, `scout`) autoload the `subagent-contract` skill — do not repeat its report/scope/verification rules in the dispatch.
- The role picker reads each role's `description` from its frontmatter (the system prompt's Available Agents list) — tune descriptions there to change selection behavior.
- **`tasks[].agent` is REQUIRED.** Omitting it selects the anonymous default worker — that is NOT `reviewer` / `scout` even if the prompt says "review".
- **Dispatch is non-blocking:** `task` returns IDs immediately and results auto-deliver. Continue your own independent work; sync only at explicit barriers (integration of a dependent result, final verification, task completion).

### Canonical omp `task` call

```js
task({
  i: "review + map project",
  context: "# Goal\n...\n# Constraints\n...",
  tasks: [
    { agent: "scout", name: "Map", task: "# Target\n...\n# Acceptance\n..." },
    { agent: "reviewer", name: "Review", task: "# Target\n...\n# Acceptance\n..." },
  ],
})
```

Wrong: `tasks: [{ task: "Review the project..." }]` // no agent → default worker  
Right: `tasks: [{ agent: "reviewer", name: "Review", task: "..." }]`
