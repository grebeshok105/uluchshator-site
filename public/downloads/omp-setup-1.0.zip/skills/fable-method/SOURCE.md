# Source

Upstream: `Sahir619/fable-method` (main), MIT License.

Pack contains: `fable-method`, `fable-judge`, `fable-domain`. `fable-loop` intentionally excluded.

Note: `/fable-judge suite` additionally expects the upstream `eval/` directory, which is not included in this compact skills-only pack.
