# The workflow, drawn

The same method as decision flowcharts. Each chart is executable pseudocode: a model can follow the arrows literally, and a human can audit exactly what happens at every branch. Nothing here adds rules; every box traces to a numbered rule in SKILL.md or a skill in the family.

## Master router

```mermaid
flowchart TD
    IN["Any incoming ask"] --> TRIV{"Trivial?<br/>one file, under 10 lines,<br/>no new behavior, no searching"}
    TRIV -->|yes| DOIT["Do it, run the one obvious check,<br/>report in two sentences"]
    TRIV -->|"no, or unsure"| FIT{"Where does the answer live?"}
    FIT -->|"reachable sources"| SHAPE{"Question, task, or plan-first?"}
    FIT -->|"unknown but researchable"| RES["Research first, then loop"]
    FIT -->|"only inference"| INFER["Flag low-confidence; no costume rigor"]
    FIT -->|"specialized + recurring"| MK["Use fable-domain"]
    SHAPE -->|question| ASSESS["Diagnose only, change nothing"]
    SHAPE -->|plan-first| PLANF["Build plan and STOP for approval"]
    SHAPE -->|task| LOOP2["Evidence → decide → act → verify"]
    LOOP2 --> JPASS["Judge pass before presenting"]
    ASSESS --> JPASS
    JPASS --> OUT["Outcome-first report + honest caveats"]
```

## Intent gate

```mermaid
flowchart TD
    E["About to change behavior"] --> I["INTENT: code does X, check expects Y, spec says Z"]
    I --> AGR{"Do X, Y, Z agree?"}
    AGR -->|yes| GO["Smallest correct change"]
    AGR -->|no| AUTH["User > spec > tests > current behavior"]
    AUTH --> SURF["Surface contradiction; fix the right side"]
```

## Verify loop

```mermaid
flowchart TD
    V["Run named verification"] --> H1{"Done criterion observed?"}
    H1 -->|yes| H2{"Surrounding system healthy?"}
    H2 -->|yes| OK["Verified"]
    H1 -->|no| WHY{"Mechanical error or surprise?"}
    H2 -->|no| WHY
    WHY -->|mechanical| STRIKE{"Two strikes, same approach class?"}
    WHY -->|surprise| BACK2["Back to evidence"]
    STRIKE -->|no| BACK4["Back to edit"]
    STRIKE -->|yes| NEWINFO["New information first: logs, history, minimal repro, docs, tracing"]
    NEWINFO --> BACK2
    BACK2 --> V
```

## Judge finished work

```mermaid
flowchart TD
    R["A report says done"] --> C["Collect claims"]
    C --> D["Diff actual changes"]
    D --> RUN["Re-run every claimed verification"]
    RUN --> F["Hunt weakened checks, false completion, scope creep, spec betrayal, debris"]
    F --> VDT{"What survived?"}
    VDT -->|"all reproduced"| V1["VERIFIED"]
    VDT -->|"sound but some unrerunnable"| V2["VERIFIED WITH CAVEATS"]
    VDT -->|"claim failed or fraud found"| V3["REFUTED"]
```

## Family router

```mermaid
flowchart TD
    Q["What is in front of you?"] --> A{"Trivial?"}
    A -->|yes| NONE["No skill"]
    A -->|no| B{"Finished work claims done?"}
    B -->|yes| J["fable-judge"]
    B -->|no| D{"Specialized sector needing its own adapter?"}
    D -->|yes| FD["fable-domain"]
    D -->|no| M["fable-method inline"]
```
