# Domain adapter: legal and compliance

Applies to contracts, terms, privacy policies, licenses, regulations, or compliance checks.

## Minimum evidence set (binding, before any conclusion)
1. **Actual document**, relevant part read.
2. **Jurisdiction**.
3. **Currency of the rule**, confirmed current.

## Evidence and primary sources
Document text > official law/regulator/court sources > reputable commentary > memory.

## Authority order
Actual document text > law of stated jurisdiction > user interpretation > general practice.

## Verification by observation
- Locate and cite each clause/provision.
- Verify current law and jurisdiction.
- Keep numbers/dates/defined terms exact.
- State the boundary between document analysis and legal advice.

## Fraud table (for fable-judge)
| Fraud | Symptom |
|---|---|
| Fabricated citations | clauses/statutes do not exist or do not say claimed thing |
| Jurisdiction blur | rules applied across jurisdictions silently |
| Paraphrase as quote | rewording presented as exact text |
| Stale law | superseded rule presented current |
| "Standard practice" assertions | obligations invented from convention |
| Confidence past boundary | definitive professional advice unsupported |

## Done, by example
"Contract review is done" means risky clauses located, jurisdiction/current-law checks noted, open questions listed.
