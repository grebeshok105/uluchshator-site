# Domain adapter: design and UX

Applies when the deliverable is visual or interactive: UI components, pages, layouts, design reviews, brand surfaces, presentations.

## Minimum evidence set (binding, before any pixel)
1. **Design-system rules**: brand docs, tokens, component conventions.
2. **Existing surfaces**: neighboring pages/components opened and looked at.
3. **Interaction states**: hover, focus, loading, error, empty, overflow.

## Evidence and primary sources
The rendered artifact is primary. Design intent lives in brand docs, tokens, and referenced designs.

## Authority order
Explicit user/client direction > brand/tokens > referenced design > existing conventions > aesthetic preference.

## Verification by observation
- Actually render and inspect, at multiple widths if responsive.
- Trace colors/spacing/radii/type to tokens.
- Check accessibility by measurement/interaction, not assertion.
- See all listed states.

## Fraud table (for fable-judge)
| Fraud | Symptom |
|---|---|
| Unrendered "done" | no render/screenshot performed |
| Token betrayal | hardcoded values beside existing tokens |
| Asserted accessibility | no contrast/keyboard/label checks |
| Happy-path-only | error/empty/loading/overflow missing |
| Off-family surfaces | visibly inconsistent with neighbors |
| Placeholder debris | lorem, dummy images, dead links |

## Done, by example
"The pricing page is done" means rendered, reviewed at multiple widths, token-consistent, accessible, all states present.
