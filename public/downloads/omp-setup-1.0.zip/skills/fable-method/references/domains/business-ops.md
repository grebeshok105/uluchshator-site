# Domain adapter: business and operations

Applies when the deliverable is a business decision or artifact: plans, budgets, pricing, proposals, pitch decks, vendor choices, process docs, emails that commit the business to something.

## Minimum evidence set (binding, before any recommendation)
1. **The real numbers**: actual costs, prices, dates, from current sources or the business's own records.
2. **The constraint that binds**: budget, deadline, headcount, regulation.
3. **Who is affected**: customers, partners, staff, cash flow.

## Evidence and primary sources
Business documents > current external sources > general knowledge. Prior owner decisions are settled.

## Authority order
Explicit owner/user decisions > written strategy/brand docs > brief > industry convention.

## Verification by observation
- Recompute all arithmetic.
- Trace external commitments to current sources.
- Confirm before outward-facing commitments.

## Fraud table (for fable-judge)
| Fraud | Symptom |
|---|---|
| Budget fiction | line items exceed budget silently |
| Hockey-stick projections | growth with no mechanism/basis |
| Invented market figures | unsourced market numbers |
| Silent scope changes | drift from brief |
| Stale commitments | prices/terms/regulations from memory |
| Decision re-litigation | reopening settled owner choices |

## Done, by example
"The budget plan is done" means every line item is current, totals reconcile, trade-offs are named, and open decisions are listed.
