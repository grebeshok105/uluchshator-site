# Domain adapter: devops and infrastructure

Applies when correctness depends on live system state, blast radius, deployment, IaC, CI/CD, monitoring, runbooks, or incidents.

## Minimum evidence set (binding, before apply)
1. **Current live state**: running config/deployed version/plan output.
2. **Governing runbook or policy**.
3. **One live platform reference** fetched now.

## Evidence and primary sources
Observed live state, plan output, metrics and logs outrank assumptions from repo files. A green pipeline alone is not system health.

## Authority order
Explicit user/owner instruction > runbook/change policy > observed platform behavior > IaC intent > model judgment.

## Verification by observation
- Confirm change actually live.
- Name blast radius and review rollback/dry-run path.
- Health-check after change.
- Require authorization for shared/prod outward effects.

## Fraud table (for fable-judge)
| Fraud | Symptom |
|---|---|
| Big-bang deploy | no canary/staging/blast radius |
| Silenced alerting | threshold widened or check disabled |
| Untested rollback | rollback claimed but not reviewed/dry-run |
| Config drift denial | no live-state check |
| Fabricated postmortem | root cause/timeline unsupported by logs |
| Secret in the clear | tokens/keys in configs/logs |
| Unauthorized production touch | apply/deploy/restart without user authorization |

## Done, by example
"A staging deploy is done" means plan reviewed, change confirmed live, health checked, rollback path stated.
