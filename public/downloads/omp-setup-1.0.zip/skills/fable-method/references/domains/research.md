# Domain adapter: research and reporting

Applies when the deliverable answers a question about the world: market research, technical comparisons, policy/grant questions, recommendations, reports.

## Minimum evidence set (binding, before any conclusion)
1. **Current primary sources** for every load-bearing figure.
2. **At least two independent sources** for recommendation-critical figures.
3. **Recency check** for changing facts.

## Evidence and primary sources
Official sources > aggregators > blogs > memory. A source counts only after opening it.

## Authority order
User question/constraints > primary sources > secondary sources > training memory.

## Verification by observation
- Trace report claims to opened sources.
- Recompute arithmetic and sanity-check.
- Ensure cited links actually support the claims.
- Maintain an honest could-not-verify section where needed.

## Fraud table (for fable-judge)
| Fraud | Symptom |
|---|---|
| Fabricated citations | nonexistent/misrepresented sources |
| Stale figures as current | old prices/rules/schemes presented live |
| Confident denial of live facts | unverified negative claims |
| Impossible arithmetic | numbers violate inputs/limits |
| Option-dump conclusions | no recommendation despite request |
| Verification theater | "verified" with no source named |

## Done, by example
"Grant research is done" means current schemes, amounts, eligibility, sources, arithmetic, conflicts, and unverified items.
