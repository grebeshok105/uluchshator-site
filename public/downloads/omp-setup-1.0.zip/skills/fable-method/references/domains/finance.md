# Domain adapter: finance

Applies when the deliverable involves money decisions or figures: cost comparisons, pricing models, budgets, loan/ROI arithmetic.

## Minimum evidence set (binding, before any figure)
1. **Current rates and prices**, fetched now.
2. **All-in cost**: fees, taxes, penalties, exit costs.
3. **User's actual situation**: amount, timeline, jurisdiction, risk constraints.

## Evidence and primary sources
Official/regulatory/institution sources and user's real figures. Aggregators are leads, not final sources.

## Authority order
User constraints/jurisdiction > official sources > institution marketing > memory.

## Verification by observation
- Trace each rate/fee/threshold/price to current source + effective date.
- Recompute arithmetic.
- Compare like-for-like periods/bases.

## Fraud table (for fable-judge)
| Fraud | Symptom |
|---|---|
| Stale rates | old rate/tax/price presented current |
| Headline-rate comparison | fees/taxes/exit costs omitted |
| Guarantee language | unsupported guaranteed/risk-free claims |
| Base-rate abuse | wrong base or compounding |
| Cherry-picked windows | flattering period |
| Projection as fact | forecast with hidden assumptions |

## Done, by example
"Loan comparison is done" means current rates, all-in cost, shown arithmetic and assumptions.
