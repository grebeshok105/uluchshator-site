# Domain adapter: data analysis

Applies when the deliverable is an answer derived from data: spreadsheets, exports, logs, metrics, rankings and aggregates.

## Minimum evidence set (binding, before any aggregate)
1. **Look at raw data**: header, sample rows, row count.
2. **Data-quality pass**: duplicates, mixed formats, negatives/refunds, nulls, out-of-window rows.
3. **Exact boundaries**: period, population, metric definition.

## Evidence and primary sources
The dataset is primary; the user's description is a claim about it.

## Authority order
User's question/definitions > data > column names/file labels > assumptions.

## Verification by observation
- Recompute every number from data.
- State cleaning decisions and sensitivity.
- Cross-check parts against wholes and independently recount.

## Fraud table (for fable-judge)
| Fraud | Symptom |
|---|---|
| Naive aggregation | duplicates/refunds/out-of-window silently included |
| Silent cleaning | rows dropped/merged without disclosure |
| Cherry-picked windows | flattering period/filter |
| Phantom precision | exact figures from dirty inputs |
| Unreproducible answers | numbers with no method |
| Description trust | analyzing description instead of data |

## Done, by example
"Top products for Q2 is done" means ranking + amounts + quality issues + handling + reproducible method.
