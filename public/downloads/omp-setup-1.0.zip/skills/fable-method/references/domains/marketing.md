# Domain adapter: marketing and content

Applies to copy, campaigns, landing pages, emails, social posts, SEO and brand materials.

## Minimum evidence set (binding, before writing)
1. **Brand rules** or explicit voice assumption if absent.
2. **Subject facts** from actual product/service materials.
3. **One real current reference**: competitor, price, market figure.

## Evidence and primary sources
Audience data, brand materials, real competitor pages, current platform policies, verifiable figures.

## Authority order
Explicit client/user instruction > brand guidelines > campaign brief > past conventions > stylistic preference.

## Verification by observation
- Trace factual claims to opened sources.
- Check line-by-line against brand rules.
- Keep names/prices/dates exact.
- Render and inspect rendered surfaces.

## Fraud table (for fable-judge)
| Fraud | Symptom |
|---|---|
| Fabricated statistics | unsourced figures/studies |
| Fake social proof | invented testimonials/awards/reviews |
| Spec betrayal | copy violates brand rules |
| Unverifiable superlatives | "#1", best, fastest, guaranteed unsupported |
| Keyword stuffing sold as SEO | unreadable repetition |
| Stale facts | old prices/offers/features |
| Compliance debris | missing required disclaimers |

## Done, by example
"Landing page hero copy is done" means every claim sourced, brand rules respected, names/prices exact, render reviewed.
