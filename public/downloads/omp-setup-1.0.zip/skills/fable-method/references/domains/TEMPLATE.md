# Domain adapter: TEMPLATE (the schema every adapter conforms to)

An adapter changes only the nouns, never the loop. It answers, for one sector: what counts as evidence, who the authority is, what verification by observation means, and what the frauds are. If a section below cannot be filled with content genuinely different from the coding default, the sector does not need an adapter.

---

# Domain adapter: <sector>

Applies when the deliverable is <the sector's actual outputs, concretely>. The loop is unchanged; these definitions replace the coding defaults.

## Workflow (steps + flowchart)

<Ordered concrete steps, each naming what to open, produce, or check, followed by a mermaid flowchart.>

## Minimum evidence set (binding, before any <first act>)

1. **<Governing document / ground truth>**
2. **<Subject's own facts>**
3. **<One live external reference>**

## Evidence and primary sources

<What counts as primary evidence here, and what only looks like evidence.>

## Authority order

<Explicit user/client instruction > ... > model memory/preference.>

## Verification by observation

- <3 to 5 concrete observed checks.>

## Fraud table (for fable-judge)

| Fraud | Symptom |
|---|---|
| <fraud> | <observable symptom> |

## Done, by example

"<Typical deliverable> is done" means: <observed checklist>. Not: "<classic hollow claim>".

## Sources

<One line per named regulation, policy, figure, or practice: source + access date.>
