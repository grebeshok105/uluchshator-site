---
name: agent-setup-verification
description: "Use when validating, auditing, or repairing this machine's omp agent environment — MCP servers not responding, LSP failures, skills not resolving, missing tokens, or after editing config files in ~/.omp/agent/."
---

# Agent setup verification (this machine)

Config root: `C:/Users/__USERNAME__/.omp/agent/`. Verify by exercising, not by reading configs alone.

## 1. MCP servers (`mcp.json`)

Servers are defined in `~/.omp/agent/mcp.json`. For each: confirm it is mounted (an `xd://mcp__<name>_*` route exists in the session) and answers a cheap call (e.g. knowledge-rag `get_index_stats`, context7 `resolve-library-id`). A server in config but absent from routes = failed handshake; run its `npx` command manually in bash to see the real error.

Known env deps (set per-server in mcp.json):
- `knowledge-rag` needs `KNOWLEDGE_RAG_DIR=D:/RAG/jujutsu`
- `knowledge-rag-general` was disabled in 0.7 (memory economy) — absence is expected, not a failure; restore recipe lives in CLAUDE.md RAG section.

## 2. Secrets (`.env`)

`~/.omp/agent/.env` does NOT exist on this machine (as of 2026-08). If it appears, check keys without leaking values:
`powershell -NoProfile -Command "(Get-Content C:/Users/__USERNAME__/.omp/agent/.env) -replace '=.*','=<set>'"`
GitHub-backed features need `GITHUB_TOKEN` there — never fabricate tokens; list missing secrets as blockers.

## 3. LSP (`lsp.json`)

For each server: binary exists (`jdtls` → `C:/Users/__USERNAME__/scoop/shims/jdtls.exe`, `rust-analyzer` → `C:/Users/__USERNAME__/scoop/shims/rust-analyzer.exe`; pyright is an npm global, not in lsp.json), then a live probe — create a temp source file with a deliberate error, run `lsp diagnostics` on it, expect the error reported. Config parse: `lsp status`.

## 4. Skills

- Scanned roots: `~/.claude/skills/` (primary, has `skill_registry.json` + `SKILLS_INDEX.md`), `~/.claude/jujutsu-skills/` (via `config.yml` `skills.customDirectories`), `~/.omp/agent/skills/` if it exists. NOT a source: `~/.omp/agent/managed-skills/` — resolver does not scan it (launching-tokentracker has a stale copy there; the live one is in `~/.claude/skills/`).
- Every dir under a scanned root must contain `SKILL.md` with `name` + `description` frontmatter.
- Spot-check resolution: `read skill://<name>` for one skill per root.
- `~/.claude/skills/skill_registry.json` must be valid JSON and `SKILLS_INDEX.md` `Total: N skills.` counter must match directory count.

## 5. Report

Per subsystem: OK / broken (with the failing command and error) / degraded (works but missing optional deps). Fix what config allows; list missing secrets as blockers — never fabricate tokens.

## Staleness warning

Do NOT trust remembered inventory (server counts, skill counts) — configs change between sessions. Enumerate from the files listed above every time.
