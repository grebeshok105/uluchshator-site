---
name: transferring-omp-setup
description: "Use when переносить конфигурацию omp на другой ПК или собирать/обновлять архив переноса — «собери omp-setup.zip», «перенеси настройки на второй пк», «обнови архив настроек», а также при установке из omp-setup.zip на новой машине или когда INSTALL.md устарел."
---

# Transferring omp setup

## Overview

Перенос слепка omp между машинами = архив `Desktop/omp-setup.zip`: конфиги + скиллы + ключи + `INSTALL.md` (готовый промпт агенту-установщику). Архив собирается скриптом из живой системы и **верифицируется побайтово** — «на глаз» не считается.

## Манифест — что включать

| Живой путь | В архиве |
|---|---|
| `~/.claude/CLAUDE.md` | `CLAUDE.md` (+ `CLAUDE.neutral.md` — откат поведения, берётся из прошлого архива) |
| `~/.claude/skills/` | `skills/` (с SKILLS_INDEX.md и skill_registry.json) |
| `~/.claude/jujutsu-skills/` | `jujutsu-skills/` (подключены в config.yml `skills.customDirectories`) |
| `~/.omp/agent/config.yml, models.yml, mcp.json, lsp.json, APPEND_SYSTEM.md` | `omp/` |
| `~/.omp/agent/hooks/, agents/, managed-skills/, extensions/, themes/` | `omp/...` |
| `~/.omp/marketplaces.json` | `omp/marketplaces.json` |
| ключ opencode-go из `agent.db` | `omp/auth/opencode-go.json` |

**НЕ включать:** `*.db*`, sessions, memories, blobs, logs, terminal-sessions, кэши, `profiles/` (bench-профили), бэкапы `*.bak*` — и **конфиги других агентов** (Claude Code settings.json, Codex, Grok) без явной просьбы. Только omp.

## Ключи

- **forge** — лежит в `models.yml`, едет вместе с файлом.
- **opencode-go** — НЕ в файлах: `sqlite3 file:~/.omp/agent/agent.db?mode=ro` → `SELECT data FROM auth_credentials` → выписать в `omp/auth/opencode-go.json`.
- Архив с ключами = секрет: предупреждение в README и INSTALL, не публиковать.

## Сборка

1. Staging-копия по манифесту (ignore: `__pycache__`, `node_modules`, `.git`, `.system`).
2. Плейсхолдер юзернейма: `re.sub(rb"KOMP1", b"__USERNAME__", raw, flags=re.IGNORECASE)` — **только байтовый режим** и по **всем** файлам, включая безрасширенные (hooks).
3. Написать `INSTALL.md` (свойства ниже), `README.md`, `WELCOME.md`.
4. Zip → `Desktop/omp-setup.zip`.
5. **Верификация (обязательна):** `testzip`; побайтовая сверка каждого файла архива с живым оригиналом после подстановки; ключи присутствуют; `KOMP1` нигде не остался; счётчики скиллов сходятся; лишних деревьев (claude/, codex/, grok/) нет.

## INSTALL.md — обязательные свойства

- Правило №1: **уже установленный софт НЕ трогать** — scoop/JDK/jdtls/rust-analyzer/node/tokentracker не переустанавливать; заменяются только конфиги из архива, и только после бэкапа в `omp-setup-backup-<дата>`.
- `__USERNAME__` → `%USERNAME%` рекурсивно по всем файлам архива.
- **Nerd Font (ОБЯЗАТЕЛЬНЫЙ для symbolPreset: nerd):** если `symbolPreset: nerd` в config.yml, а Nerd Font не установлен — глифы будут квадратиками. Установить JetBrainsMono Nerd Font (скачать с github.com/ryanoasis/nerd-fonts/releases, распаковать, правый клик → «Установить», либо per-user: скопировать ttf в `%LOCALAPPDATA%\Microsoft\Windows\Fonts` + записи в `HKCU\...\Fonts`), затем в Windows Terminal: `profiles.defaults.font.face = "JetBrainsMono Nerd Font Mono"`. Перезапуск терминала обязателен.
- **MCP** (`/mcp list` + `/mcp test` обеих RAG-баз) и **LSP** (jdtls, rust-analyzer) — шаги с пометкой ОБЯЗАТЕЛЬНЫЙ: реальный установщик однажды их молча пропустил.
- Финальный чек-лист: агент обязан вставить в отчёт **живой вывод** каждой проверки; «готово» без вывода запрещено.

## Common mistakes

| Ошибка | Фикс |
|---|---|
| Замена через `write_text` | Портит line endings (LF→CRLF); только `read_bytes`/`write_bytes` |
| Тащить Codex/Claude/Grok «за компанию» | Только omp; чужие агенты — по явной просьбе |
| Забыть ключ opencode-go | Он в `agent.db`, не в конфигах — доставать sqlite-запросом |
| Плейсхолдер пропустил файлы без расширения | Байтовый проход по всем файлам, не по маске расширений |
| Установщик пропускает MCP/LSP | Шаги «ОБЯЗАТЕЛЬНЫЙ» + чек-лист с живым выводом |
| Верификация «на глаз» | Побайтовая сверка zip против живой системы |
