---
name: deploying-omp-skills
description: "Use when creating, installing, moving, or registering an agent skill on this machine, or when a written skill does not resolve via skill:// — covers scanned directories, the managed-skills trap, registry and index registration."
---

# Deploying skills on this machine (omp)

## The one rule

**Every new skill goes to `~/.claude/skills/<name>/SKILL.md`** (this machine's primary scanned root). Then register it (below) and verify with a `skill://<name>` read. A skill is NOT deployed until that read succeeds.

## The trap

`manage_skill` / `learn(skill: ...)` write to `~/.omp/agent/managed-skills/` — **the resolver does not scan that directory**. Skills written there are silently invisible (real case on this machine: `launching-tokentracker` has a stale copy in managed-skills; the live, registered copy is in `~/.claude/skills/`). If you used those tools, move the SKILL.md to `~/.claude/skills/<name>/` and delete the managed copy (single source of truth).

Scanned locations on this machine: `~/.claude/skills/` (primary), `~/.claude/jujutsu-skills/` (from `config.yml` `skills.customDirectories` — contains only `add-vessel`), `~/.omp/agent/skills/` if it exists. `~/.claude/skills/` is the only root with a registry + index.

**Shadowing trap:** a skill name present in BOTH `~/.claude/jujutsu-skills/` (customDirectories) and `~/.claude/skills/` resolves to the customDirectories copy — edits to the `~/.claude/skills` copy are silently ignored, and `skill://` serves the stale duplicate. Real case (2026-08-05): stale duplicates of `dispatching-parallel-agents`, `omp-self-orchestration`, `skill-system` shadowed fresh edits. Fix: delete the duplicates (keep `add-vessel`), then force a resolver rescan — the resolver index caches resolved paths, so after deletion `skill://` still points at the deleted files until you trigger a rescan (create a throwaway managed probe skill, retry `skill://`, delete the probe).

## Deployment checklist

1. `write` the skill to `~/.claude/skills/<name>/SKILL.md` (frontmatter: `name`, `description` starting with "Use when...").
2. Add an entry to `~/.claude/skills/skill_registry.json` (alphabetical; fields `name`, `description`, `path: "<name>/SKILL.md"`). Validate: `node -e "JSON.parse(require('fs').readFileSync('C:/Users/__USERNAME__/.claude/skills/skill_registry.json','utf8'))"`.
3. Add a row to `~/.claude/skills/SKILLS_INDEX.md` in the matching section; bump the `Total: N skills.` counter.
4. **Verify:** `read skill://<name>` must return the skill. If "Unknown skill", the file is in an unscanned location — recheck step 1.

## Red flags

- "It will show up next session" — unproven assumption; verify with `skill://` NOW.
- Skill exists on disk but `skill://` says "Unknown skill" — first suspect the resolver's cached index: any `manage_skill` create/delete triggers a rescan (create a throwaway probe skill, retry the read, delete the probe). If it still fails after a rescan, the file is in an unscanned directory — go to step 1.
- Two copies of one skill (managed + claude) — delete the managed one.
