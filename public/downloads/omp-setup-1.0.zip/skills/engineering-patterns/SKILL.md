---
name: engineering-patterns
description: Use when coding, reviewing, explaining code, or working with PRs — 14 proven coding patterns (Continue/Cline) and reliability techniques (OpenAI Cookbook): no-any, avoid build output in searches, bigger-picture explanations, API lookup instead of guessing, docs style, PR workflows, CoT and self-consistency for hard reasoning.
---

# Engineering Patterns

Проверенные кодинг-паттерны и техники надёжности. Источники: Continue (Apache 2.0), Cline (Apache 2.0), OpenAI Cookbook (MIT). Применяй при кодинге, ревью и объяснении кода.

## Кодинг-паттерны

1. **No `any` types.** Избегай `any`; используй `unknown` или точный тип. Исключение — typecasting в тест-моках. `any` отключает type safety: ошибка компиляции лучше ошибки runtime.
2. **Don't be overeager.** Решай ровно поставленную задачу. Починил баг — не рефактори модуль «заодно». Предложения по улучшению — отдельно, после основной задачи.
3. **Bigger picture.** Объясняя код: 1) что делает изолированно, 2) как взаимодействует с остальной кодбазой, 3) всегда включай вызывающую функцию (parent function) для контекста.
4. **Не искать в build output.** `out/`, `dist/`, `dist-standalone/`, `src/generated/`, `node_modules/` — не source of truth. Ищи в `src/`, уважай gitignore, используй file_pattern/исключения директорий.
5. **Bun для tooling, Node для runtime.** `bun install`/`bunx` для скриптов; не переписывай `node:` импорты и `engines.node` — они про runtime.
6. **SDK/API конвенции.** Look up APIs, don't guess — сначала посмотри, как API работает. При замене модуля — смотри предыдущую реализацию. Single entry point (один codepath, не env-флаги). Избегай `as`-кастов — явные функции конвертации с тестами. Никогда не хардкодь URL.
7. **Документация.** Concise, task-oriented, real examples над абстракциями, copy-pasteable сниппеты, prerequisites up front, одна тема на страницу, link don't repeat, показывай ожидаемый вывод. Тон: no personality, не снисходительно, без «Next Steps» секций, заголовки прямые и сканнируемые.
8. **Сеть.** Глобальный `fetch` — не в extension/library коде; proxy-aware wrapper, третьим клиентам — кастомный fetch. В webview/browser — глобальный fetch ок.
9. **Тесты: запуск.** Знай команду запуска для каждой части проекта (vitest/jest/...) — не угадывай.
10. **Юнит-тесты.** Top-level `test()`, не `describe()`-обёртки; имя тестируемой функции в описании теста.
11. **Truth over agreeableness.** Не поддакивай автоматически; будь готов мягко сказать, что пользователь неправ, и объяснить почему. Инженерная правда важнее социального комфорта.
12. **PR-комментарии.** Получи контекст PR (`gh pr view --json number,title,body`) → пойми diff и интент → сгруппируй комментарии → summary с рекомендацией (apply/skip/respond) → жди approval → commit/reply/push.
13. **Git diff анализ.** Собери git-статус/log/diff → тихий анализ без прозы → сбор контекста (не более 60% контекстного окна на чтение) → только потом интерактив.
14. **Поиск ревьюеров.** domain expertise > direct file expertise > line ownership; исключи себя; дай top-5.

## Техники надёжности (OpenAI Cookbook)

- **CoT (Chain of Thought).** Для многошаговых рассуждений: «Let's think step by step» поднял точность MultiArith с 18% до 79%. Не для тривиальных задач — там просто отвечай.
- **Разбиение сложных задач.** Сложное → подзадачи с явными этапами: «First, go through clues one by one... Second, combine... Third, map to format».
- **Кастомизация CoT.** Вместо generic: «First, think step by step about why X might be true. Second, think about why Y might be true. Third, decide which makes more sense».
- **Self-consistency.** Для high-stakes решений: сгенерируй N ответов (temperature > 0) → majority vote.
- **Разбиение сложных инструкций.** Многошаговая инструкция → отдельные шаги с явным форматом, иначе модель теряет фокус (пример: «сначала определи язык, потом переведи»).

## Когда использовать

- кодинг/ревью: паттерны 1-2, 4-6, 9-11
- объяснение кода: 3
- PR-работа: 12-14
- сложные рассуждения: CoT, разбиение, self-consistency
