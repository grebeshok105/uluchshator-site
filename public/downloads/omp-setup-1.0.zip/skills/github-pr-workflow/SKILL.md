---
name: github-pr-workflow
description: Use when working with GitHub pull requests, creating or updating PRs, pushing branches, using GitHub CLI gh, checking PR status, formatting PR bodies, recovering when gh is missing from PATH, or returning GitHub PR links to the user.
---

# GitHub PR Workflow

## Overview

Use this skill whenever the user asks to create a PR, push a branch, work with GitHub, inspect PR state, or communicate PR results. The goal is to be reliable and calm: verify first, avoid duplicate PRs, use the already installed GitHub CLI whenever possible, and return a clean PR link in the user's preferred format.

## Core Rules

- Before claiming success, run the command that proves it. For code PRs, use `verification-before-completion` first.
- Before finishing a branch with a PR, use `finishing-a-development-branch`.
- Do not reinstall GitHub CLI just because `gh` is not in `PATH`; search for an existing `gh.exe` first.
- Never print full GitHub tokens, OAuth secrets, credential helper output containing passwords, or Authorization headers.
- Never force-push, delete branches, reset, or discard work unless the user explicitly asks.
- Prefer updating/reusing an existing PR for the current branch over creating a duplicate.

## Quick Workflow

1. Inspect repository state:
   ```powershell
   git status --short --branch
   git remote -v
   git branch --show-current
   ```
2. If code changed, run fresh verification before commit/PR:
   ```powershell
   .\gradlew.bat build
   git diff --check
   ```
   Adapt the test command to the project. Read the output and exit code.
3. Commit scoped changes:
   ```powershell
   git add <paths>
   git commit -m "<type(scope): summary>"
   ```
4. Push the branch:
   ```powershell
   git push -u origin <branch>
   ```
5. Find or create the PR with `gh`.
6. Return the PR as `[owner/repo#N](https://github.com/owner/repo/pull/N)` plus the key verification evidence.

## Finding GitHub CLI on Windows

If `gh` is not recognized, do not assume it is missing. Resolve it first:

```powershell
$gh = (Get-Command gh -ErrorAction SilentlyContinue).Source
if (-not $gh) {
  $candidates = @(
    "$env:TEMP\gh-portable\bin\gh.exe",
    "C:\Program Files\GitHub CLI\gh.exe",
    "C:\Program Files (x86)\GitHub CLI\gh.exe",
    "$env:LOCALAPPDATA\Programs\GitHub CLI\gh.exe"
  )
  $gh = $candidates | Where-Object { Test-Path $_ } | Select-Object -First 1
}
if (-not $gh) {
  $gh = Get-ChildItem -Path $env:LOCALAPPDATA,$env:TEMP -Recurse -Filter gh.exe -ErrorAction SilentlyContinue |
    Select-Object -First 1 -ExpandProperty FullName
}
if (-not $gh) { throw "GitHub CLI gh.exe was not found" }
& $gh auth status
```

Only install `gh` after this search fails and the user wants installation.

## PR Creation

Check the default base branch and existing PR first:

```powershell
$repo = "<owner>/<repo>"
$branch = git branch --show-current
$base = & $gh repo view $repo --json defaultBranchRef --jq .defaultBranchRef.name
& $gh pr view --repo $repo --head $branch --json number,url,title 2>$null
```

If no PR exists, create one using a PowerShell here-string for the body so quoting does not break:

```powershell
$body = @'
## Summary

<what changed and why>

## What Changed

- <major change>
- <major change>

## Verification

- [x] `<command>`
- [x] `<command>`

## Manual Checklist

- [ ] <human test step>
- [ ] <human test step>

## Notes

<rollback info, artifacts, risks, or follow-up work>

Requested by: @<user>
'@

& $gh pr create --repo $repo --base $base --head $branch --title "<title>" --body $body
```

## Preferred PR Body Style

When the user wants the prettier project style, use detailed sections with emojis:

- `## Summary` or `## 🛫 Summary`
- `## ✨ Что сделано`
- Subsections like `### ⚙️`, `### 🛰️`, `### 🧪`
- `## ✅ Проверка`
- `## 🧍 Чеклист для ручного теста`
- `## 📝 Notes`
- `Requested by: @username`

Keep it specific: mention important files, behavior changes, tests run, built artifacts, rollback points, and manual checks the user should perform.

## Existing PR Updates

If a PR already exists for the branch, do not create another one. Use:

```powershell
& $gh pr edit <number-or-url> --repo $repo --title "<title>" --body $body
```

For follow-up changes, push commits to the same branch and optionally comment:

```powershell
& $gh pr comment <number-or-url> --repo $repo --body "<short update>"
```

## Final Response Pattern

After PR creation or update, answer with:

- The PR link as `[owner/repo#N](url)`.
- The artifact path if a build artifact was produced.
- The exact verification commands that passed.
- Any unresolved manual testing or known risk.

Example:

```markdown
PR создан: [owner/repo#12](https://github.com/owner/repo/pull/12)

Jar: [artifact.jar](<C:/absolute/path/artifact.jar>)

Проверка: `.\gradlew.bat build` прошел, `git diff --check` без ошибок.
```

## Common Mistakes

| Mistake | Fix |
| --- | --- |
| `gh` not found, immediately installing it | Search common Windows paths and portable installs first |
| Creating duplicate PRs | Run `gh pr view --head <branch>` before `gh pr create` |
| Messy PR body due to shell quoting | Use a PowerShell single-quoted here-string |
| Leaking token output | Show only auth status/account/scopes, never full secrets |
| Claiming build passed from memory | Run fresh verification in the current turn |
| Linking raw URL only | Prefer `[owner/repo#N](url)` |
