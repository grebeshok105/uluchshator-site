---
name: rule-of-four
description: "Use when a task is large enough to warrant a 5-block plan (2+ independent concerns, needs investigation + implementation + verification), or when the user explicitly says «по правилу 4» / «по правилу четырёх» / «правило 4» / \"rule of 4\" / \"rule-of-four\". Runs the «правило четырёх» pipeline: 4 scouts → detailed plan-spec into 5 blocks → 4 workers + main takes the heaviest block → user-gated 4-reviewer phase. Small tasks without an explicit user command use dispatching-parallel-agents instead."
---

# Rule of Four (правило четырёх)

Pipeline for large tasks. Symmetric: 4 scouts → 5-block plan → 4 workers (+ main block) → 4 reviewers. Every phase boundary is an explicit sync barrier; state lives in files, not in context.

## Triggers

- **auto** — the task matches the entry threshold below
- **explicit user command** — «по правилу 4», «по правилу четырёх», «правило 4», "rule of 4", "rule-of-four", `/rule-of-four`: load and execute even if the task is below the threshold. Warn about the overhead, then run the pipeline — a user command overrides the entry threshold.

## When to use (entry threshold)

Use ONLY when the task genuinely warrants a plan of 5 independent blocks:

- 2+ independent areas / modules / files
- investigation + implementation + verification are all needed
- clearly more than one or two working turns

Otherwise use `skill://dispatching-parallel-agents` (+ `omp-self-orchestration`) — the plain parallel flow, no pipeline. Applying the rule of four to small tasks is pure overhead: 3 barriers + 12 subagents where 2 would do. Unless the user explicitly commanded the rule of four — then the command wins (see Triggers).

## Skills to load (subagent dispatch)

Loading skills is an explicit step before EVERY dispatch — it is not implied by this skill's text. A description sitting in context is NOT a loaded skill; the model must `read skill://<name>` the body before the workflow it governs. Each phase below names the skill to load BEFORE the batch; this section is the authoritative list:

1. **Bootstrap trio** — if not already loaded this session, load FIRST, in one read batch: `skill://using-superpowers`, `skill://skill-system`, `skill://omp-self-orchestration`.
2. **`skill://dispatching-parallel-agents`** — REQUIRED before the first `tasks[]` batch of the session (Phases 0, 2, 3, 4): agent roles (scout/task/reviewer/tester/…), task prompt shape, dispatch-and-continue doctrine, `tasks[].agent` rule. Do NOT skip it because rule-of-four "already describes dispatch" — this is the mechanics skill; rule-of-four is only the pipeline.
3. **`skill://eval-workflow-orchestration`** — REQUIRED before Phase 3 review flavors 2/3 (adversarial / combo): fan-out + cross-check primitives, try/catch-in-thunks failure safety, per-wave snapshots. Loading it is a hard gate — flavor 2/3 without it is ad-hoc review.
4. **`skill://verification-before-completion`** — before the final verification (Phase 4).
5. **`skill://subagent-driven-development`** — only when executing a written plan through subagents (alternative pipeline).
6. **`skill://fable-method`** — REQUIRED: the pipeline's execution discipline. Phase 1 runs fable Steps 0–3 on the overall task before writing plan-spec (classify the ask, define done, gather evidence, decide); Phase 2 workers run the full fable loop on their blocks (intent gate, recall gate, surgical edits, verify by observation; INTENT/TWINS lines in block reports); Phase 4 final verification follows fable Step 5 (verify by observation, twin check).
7. **`skill://fable-judge`** — REQUIRED before the Phase 4 judge pass (see Phase 4); available as review flavor 4 in Phase 3.
8. **`skill://nodumb`** — when choosing HOW to implement a block (or block 5): facts first, alternatives from different axes, stress-test before the first edit.

Do NOT load manually: `subagent-contract` — it auto-loads in every executor role (scout/task/tester/briefer/sonic); do not repeat its rules in dispatch prompts.

## Artifacts (compaction-proofing)

All pipeline state lives in files, NEVER in context. If auto-compaction fires mid-pipeline, re-read the specs and continue — do not re-dispatch completed work.

- `<repo-root>/.superpowers/rule-of-four/<slug>/plan-spec.md` — the 5-block plan (written by the main model)
- `<repo-root>/.superpowers/rule-of-four/<slug>/progress.md` — one status line per phase: what is dispatched, what settled, what remains
- `<repo-root>/.superpowers/rule-of-four/<slug>/review-spec.md` — consolidated reviewer findings (written by the main model from reviewer reports)
- `<repo-root>/.superpowers/rule-of-four/<slug>/block-N-report.md` — worker N's report (written by the worker)

## Phase 0 — 4 scouts (parallel, one request)

Load `skill://dispatching-parallel-agents` first (if not loaded this session — see Skills to load), then dispatch 4 `agent: "scout"` in ONE `tasks[]` batch. Give each scout its OWN slice, or all four return the same report:

1. **architecture/code** — which modules and files are touched, how they are structured
2. **patterns/conventions** — idioms, styles, existing conventions to follow
3. **risks/constraints** — what can break, environment limits, dependencies
4. **acceptance criteria** — how to verify the result, what "done" means

Barrier: the plan depends on all 4 scout reports — do not write it before all four have settled. But waiting is NOT idling: while scouts run, do useful independent work that does not depend on their results and does not duplicate their slices:

- create the artifacts workspace (`.superpowers/rule-of-four/<slug>/`) and the `progress.md` stub
- verify the environment: build/test commands run, tooling present, git status sane
- re-read the task and its acceptance criteria; check related issues / PRs
- prepare the `plan-spec.md` skeleton (structure only — content comes from scout reports)

## Phase 1 — plan-spec into 5 blocks (written by the MAIN model)

The plan is never delegated — scouts report, workers execute, the main plans. From the 4 scout reports, write `plan-spec.md`:

- exactly 5 blocks; for each block: goal, files, interfaces/contracts with neighboring blocks (exact signatures, formats, names), acceptance criteria, what NOT to touch
- decide cross-block contracts HERE, before dispatch — workers never negotiate interfaces among themselves
- balance blocks by size; block 5 = the heaviest one (the main takes it)

Before writing the plan, run `fable-method` Steps 0–3 on the overall task: classify the ask, define done with its verification, gather evidence (the scout reports ARE the evidence — fable's primary-sources rule), decide. A plan-spec that skips fable's intent gate (code vs check vs spec agreement) reproduces fable failure modes in 5 blocks at once.

### Стандарт спеки

План-спека создаётся по **`skill://writing-plans`** — загрузить ПЕРЕД написанием
плана (Phase 1) и следовать ему: исполняемая спека для zero-context исполнителя,
файловая карта, правка задач (task right-sizing), верификация каждого шага.
Поверх него — специфика rule-of-four: ровно 5 блоков, контракты между блоками
(точные сигнатуры/форматы/имена), acceptance-критерии и баланс по размеру —
решаются в Phase 1 до диспатча (вводная Phase 1).

## Phase 2 — 4 workers + main takes block 5

- load `skill://dispatching-parallel-agents` (if not loaded this session — see Skills to load), then dispatch one `tasks[]` batch: 4 × `agent: "task"`; each worker gets: its block from plan-spec (path to the file), the contracts, a report path (`block-N-report.md`), and the report contract (what was done, changed files, commands with results, risks, unresolved)
- the main IMMEDIATELY starts working on block 5 — dispatch-and-continue, do not sit idle
- worker results arrive on their own (auto-delivery); consume as they settle
- do NOT do a worker's work yourself, do NOT make decisions for delegated blocks
- barrier: integration after all 4 worker reports + block 5 are done

## Phase 3 — review ONLY on the user's command

The main NEVER launches reviewers on its own. After the work of Phase 2 is integrated, the turn MUST end with the review proposal — this is a pipeline step, not politeness:

> правило четырёх: блоки готовы. ревью — каким способом?
> 1. **классические 4 ревьюера** — каждый блок отдельно, P0–P3, plan-spec + контракты;
> 2. **eval-workflow adversarial** — fan-out ревьюеров по блокам + перекрёстная проверка находок + синтез;
> 3. **комбо** — 4 ревьюера по блокам + волна cross-check их находок;
> 4. **fable-judge** — адверсариальная проверка собранного результата: перепроверка заявленных проверок, дифф, ослабленные тесты, самовольные действия; вердикт VERIFIED / VERIFIED WITH CAVEATS / REFUTED.
> запускать?

Until the user explicitly picks a flavor (or declines), do NOT dispatch reviewers. The user picks the flavor — the main never picks it for them. If the user declines, record it in `progress.md` and finish.

Every flavor shares the same contract: findings P0–P3 with `file:line` and justification, consolidated into `review-spec.md`, adjudication by the main afterwards. fable-judge (flavor 4) additionally delivers its own verdict line on top of the P0–P3 findings.

On the user's command:

- **Flavor 1 (classic):** load `skill://dispatching-parallel-agents` (if not loaded this session — see Skills to load), then dispatch one `tasks[]` batch: 4 × `agent: "reviewer"` (read-only); each reviewer gets: `plan-spec.md`, its block (diff or file paths), the contracts, and the findings contract — P0–P3, `file:line`, justification.
- **Flavor 2 (eval-workflow adversarial):** load `skill://eval-workflow-orchestration` FIRST — REQUIRED, not optional: its primitives (`agent`/`parallel`/`pipeline`), failure-safety rules (try/catch inside every thunk, one retry wave for failed nodes, per-wave snapshots to `local://`) and the adversarial pattern are the procedure; without the skill the review degrades into ad-hoc dispatch. Then run the review as an eval workflow: fan-out reviewers (one per block) via `agent(..., {agent: "reviewer", schema: {findings: [{file, line, severity, verdict, justification}]}})`, then a cross-check wave where reviewers verify EACH OTHER's findings (confirm/reject with reason), then one synthesis agent. Output is still P0–P3 findings with `file:line`, consolidated into `review-spec.md`.
- **Flavor 3 (combo):** load BOTH `skill://dispatching-parallel-agents` and `skill://eval-workflow-orchestration` (if not loaded this session — see Skills to load). Wave 1: classic 4 × `agent: "reviewer"` per block (exactly as flavor 1). Wave 2: cross-check — reviewers verify each other's findings via the eval workflow's cross-check wave (try/catch inside thunks, one retry, snapshot to `local://`). Consolidate into `review-spec.md`.
- **Flavor 4 (fable-judge):** load `skill://fable-judge`, run its default "judge the work" mode on the integrated result of Phase 2: collect the claims, diff what actually changed, re-run every claimed verification, hunt weakened checks / false completion / scope creep / unauthorized actions / debris. Verdict: VERIFIED / VERIFIED WITH CAVEATS / REFUTED, plus P0–P3 findings. While the judge runs, the main does NOT touch code.

In every flavor: reviewers return findings in their reports; after all settle, the main consolidates them into `review-spec.md` (all reviewer words in one file); while reviewers run, the main does NOT touch code — adjudication comes next.

## Phase 4 — adjudication and fixes

- read `review-spec.md` in full
- for each finding: confirm or reject with a written reason (append the verdict to `review-spec.md`; a silent discard is forbidden)
- fixes: one fixer batch (or the main itself if small)
- **mandatory fable-judge pass** on the fixed result (its fraud hunt catches weakened checks introduced by the fixes themselves), then load `skill://verification-before-completion` and run final verification (`agent: "tester"` or per that skill)
- final report to the user per fable Step 6: outcome-first, what was done, what was rejected and why, caveats, TWINS/INTENT lines

## Hard rules

1. Entry threshold: the task does not warrant 5 blocks → no pipeline.
2. The main writes the plan; scouts report, workers execute.
3. Reviewers launch ONLY on the user's command (Phase 3), and the user picks the review flavor (classic / eval-workflow / combo) — the main never picks it. Forgetting the proposal = pipeline not finished.
4. State lives in files — compaction must not kill the pipeline.
5. Do not finish the task before adjudicating findings.
6. Do not touch code while reviewers run.
7. The fable discipline is mandatory: Phase 1 runs fable Steps 0–3, Phase 2 workers run the fable loop, Phase 4 ends with a fable-judge pass. Skipping it = pipeline not finished.

## Red flags — stop and check

- 4 scouts without slices → duplicate reports
- blocks without contracts → workers improvising interfaces (a plan bug)
- main idle after dispatching workers → dispatch-and-continue violated
- reviewers launched without the user's command → Phase 3 violated
- review flavor 2/3 dispatched without loading `skill://eval-workflow-orchestration` → ad-hoc review, no failure safety
- findings not consolidated into `review-spec.md` → the review never happened
- Phase 4 finished without the fable-judge pass → verification faked
- worker block reports without INTENT/TWINS lines (where behavior changed / defects fixed) → fable loop skipped

## Related

- `dispatching-parallel-agents` — parallel dispatch mechanics, roles, dispatch-and-continue doctrine
- `omp-self-orchestration` — when the pipeline does NOT apply
- `subagent-driven-development` — alternative pipeline for executing written plans
- `verification-before-completion` — final verification step
- `fable-method` — the execution loop every block runs (Steps 0–3 in Phase 1, full loop in Phase 2, Step 6 reports)
- `fable-judge` — adversarial verification: Phase 3 flavor 4, mandatory Phase 4 pass
- `nodumb` — approach selection inside blocks: facts, alternatives, stress-test
