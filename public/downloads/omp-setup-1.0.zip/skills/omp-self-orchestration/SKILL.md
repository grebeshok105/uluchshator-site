---
name: omp-self-orchestration
description: "Session bootstrap #3 with using-superpowers and skill-system. Use at the start of every main omp session (FIRST ACTION loads this via CLAUDE.md), and whenever doing non-trivial coding — bugfix, feature, multi-file change, issue implementation, qualitygate — or when editing alone without task/scout/tester."
---

# OMP Self-Orchestration

## Overview

**You orchestrate yourself.** The user must never need to say “зови субагентов”.
If the work is non-trivial, **you** load the right skills and **you** dispatch subagents.

**Core principle:** Delegation is the default. Solo multi-file grinding is the exception you must justify.

## When This Applies

- issue/bugfix/feature with 2+ files or 2+ concerns
- “прочитай issue и зафикси”
- qualitygate / tests / explore+edit in one session
- you already did several edits and still have no `task` batch

**When it does NOT apply**
- single-line typo / pure Q&A / one-file rename with no investigation
- you are already a subagent (`task` worker) — then do not re-fan-out unless asked

## Mandatory First Moves (non-trivial tasks)

Before the second exploratory tool batch on a non-trivial task, you MUST:

1. `read skill://dispatching-parallel-agents` (if not already loaded this session)
2. Decide the fan-out (even a small one)
3. Prefer a real `task` batch over solo serial grind

Typical minimum for an issue fix:

| slice | agent | job |
|-------|--------|-----|
| explore codepaths / AC mapping | `scout` | read-only map |
| implement | `task` (or you, if tiny after scout) | edits |
| verify | `tester` | targeted tests / qualitygate |

If slices are independent → **one** `tasks[]` batch, not serial “maybe later”.

## Hard Rules

1. **No user nagging required.** Absence of “запусти субагентов” is not permission to solo.
2. **Soft CLAUDE.md text is not enough** — this skill makes the behavior operational.
3. **Reminder hooks are not completion.** If orchestration-hooks nags you, you must actually `task`, not acknowledge and continue solo.
4. **Advisor ≠ subagent.** `__advisor` does not count as scout/tester/reviewer.
5. **Reading `using-superpowers` alone is not orchestration.**
6. **Dispatch-and-continue: запуск ≠ ожидание.** `task`-батч не блокирует — после запуска продолжай свою независимую работу; результаты приходят сами (auto-delivery). Ждать можно только на явном synchronization barrier: перед интеграцией результата, от которого зависит следующий шаг, перед финальной проверкой или завершением задачи. Не дублируй делегированную работу и не завершай задачу до прихода результатов.

## Decision Gate

Ask once, silently:

> Will this need investigation + edits + verification across more than one area?

- **Yes** → dispatch (scout and/or tester at minimum; implement in parallel only if safe)
- **No** → solo OK; say nothing; proceed

If unsure → **dispatch**. Wrong small scout is cheaper than blind solo.

## Anti-Rationalization

| Excuse | Reality |
|--------|---------|
| “CLAUDE.md already says to delegate” | Then do it. Text ≠ action. |
| “I’ll call subagents after I understand” | Understanding **is** scout’s job. |
| “One agent is faster” | Solo context bloat is slower and worse. |
| “Issue is small” | Multi-file cast path is not small. |
| “Hook will remind me” | Hook now enforces bootstrap/agent — still load skills yourself first. |
| “I loaded using-superpowers” | That only bootstraps skills. Fan-out still required. |
| “User didn’t ask for subagents” | Default is self-orchestration without being asked. |
| “DeepSeek/Grok won’t follow anyway” | Follow the procedure; don’t pre-defeat it. |

## Red Flags — STOP and Fan Out

- 3+ `edit`/`write` and still zero `task` calls
- exploring router + executor + runtimes + tests alone
- planning “phases” in todo without any subagent
- only skill read this session was `using-superpowers`
- qualitygate/tests still untouched while edits pile up
- сидишь в `hub wait` / ждёшь ответ субагента, пока есть своя независимая работа — работай (dispatch-and-continue), sync только на барьере

**All of these mean:** pause solo edits → `read skill://dispatching-parallel-agents` → spawn batch.

## Minimal Compliant Pattern

```text
1) bootstrap trio (using-superpowers, skill-system, omp-self-orchestration)
2) read issue/AC
3) read skill://dispatching-parallel-agents
4) task batch with explicit agent on EVERY item
5) integrate → implement
6) task agent:tester → verify before done
```

### Canonical `task` payload (copy this shape)

```js
task({
  i: "short intent",
  context: "# Goal\n...\n# Constraints\n...",
  tasks: [
    { agent: "scout", name: "Map", task: "# Target\n...\n# Acceptance\n..." },
    { agent: "reviewer", name: "Review", task: "# Target\n...\n# Acceptance\n..." },
    { agent: "tester", name: "Verify", task: "# Target\n...\n# Acceptance\n..." },
  ],
})
```

**Rules:**
- `tasks[].agent` is **REQUIRED** — omit = wrong (default worker ≠ reviewer/scout).
- Prompt text saying "review" does **not** select reviewer — only `agent: "reviewer"`.
- Load `dispatching-parallel-agents` **before** the first `task` call.

## What “Done” Requires

- AC addressed
- verification actually run (not promised)
- if work was multi-area: **at least one real subagent dispatch** happened, or a one-line written reason why solo was mandatory

## Related Skills

- **REQUIRED:** `dispatching-parallel-agents`
- Often: `systematic-debugging`, `verification-before-completion`, `subagent-driven-development`
- Do not dump this into CLAUDE.md — keep orchestration here.
