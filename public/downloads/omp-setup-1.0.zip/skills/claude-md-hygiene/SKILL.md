---
name: claude-md-hygiene
description: Use when editing CLAUDE.md/AGENTS.md, deciding whether something belongs in CLAUDE.md vs a skill vs a reference file, auditing an instruction file for bloat or duplication, or choosing skill frontmatter invocation controls.
---

# CLAUDE.md hygiene

CLAUDE.md is loaded into context **every** session. Expensive real estate, not a warehouse.

## Placement — where does this instruction go?

| Content | Home |
|---|---|
| Fact, rule, preference, pointer | CLAUDE.md |
| Procedure (multi-step, repeated) — or a CLAUDE.md section that grew into one | Skill |
| Instructions you keep re-pasting into chat | Skill |
| Task-specific docs (build, test, DB schema, service architecture) | `agent_docs/` or `.claude/rules/`, indexed by one line in CLAUDE.md |
| Long reference material | The skill's `reference/` subfiles, not the SKILL.md body (keep it < 500 lines) |

Reference subfiles load on demand by name — `reference/finance.md` only loads when the task needs finance. Keep the SKILL.md body a table of contents pointing at them.

## Budget

- Aim for **< 300 lines** total across all CLAUDE.md files. HumanLayer's root CLAUDE.md is < 60.
- Models reliably follow ~150–200 instructions at once; the built-in system prompt already eats ~50. That leaves ~100–150. Past that, adherence degrades **everywhere**, not just for the overflow.
- **No duplication.** If a rule is already in the harness system prompt or another section, drop it. Before adding a rule, check whether the system prompt already states it — duplicates cost budget and buy nothing.
- `@path/to/file.md` imports pull content in only when needed.

## Emphasis

`IMPORTANT:` / `YOU MUST` raise adherence odds — but if everything is marked important, nothing is. A handful per file, maximum.

## Maintenance

- **Living document.** Update from real failures: an undocumented convention surfaced in review, a mistake Claude repeated, something you re-explained twice. Date the learnings.
- **Review periodically.** Ask Claude to flag stale or duplicated rules. A bloated CLAUDE.md degrades results across the board.
- **Version control it** along with `agent_docs/`, so the team shares one agent baseline and changes are reviewable.

## Skill frontmatter — who may invoke

- Default (no key): both the user (`/skill-name`) and Claude (auto, on description match).
- `disable-model-invocation: true` → user only. Use for side-effecting workflows (deploy, commit, send-message) that must never auto-fire.
- `user-invocable: false` → Claude only. Use for background knowledge that isn't a meaningful user action (e.g. `legacy-system-context`).

## Authoring notes

- Claude natively understands the SKILL.md format — no meta-prompt needed.
- Iterate: Claude A authors, Claude B uses it on real work, watch where B struggles, feed back to A. Test on real workflows, not toy scenarios.
- Cut anything Claude already knows. One-liners and bullet lists beat prose.
- Reference MCP tools by fully-qualified name `ServerName:tool_name` to avoid "tool not found".

See also: `writing-skills` for the full skill-authoring workflow and testing.
