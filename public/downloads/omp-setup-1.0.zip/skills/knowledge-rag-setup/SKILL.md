---
name: knowledge-rag-setup
description: Use when настраивать knowledge-rag MCP для нового проекта — создать базу RAG, config.yaml, запись в ~/.omp/agent/mcp.json, RULES.md, запустить индексацию. Также когда просят «настрой RAG», «подключи базу знаний», «проиндексируй документы проекта», или чинить сервер (модель не грузится, handshake-ошибка, документы не индексируются). Не путать с knowledge-mcp (LightRAG).
---

# Настройка knowledge-rag для проекта

## Обзор

**knowledge-rag** ([lyonzin/knowledge-rag](https://github.com/lyonzin/knowledge-rag)) — локальный RAG MCP-сервер: гибридный поиск (семантика + BM25), cross-encoder reranking, 13 инструментов, zero внешних серверов и API-ключей. Установка через `npx knowledge-rag` — автоматически находит Python 3.11+, создаёт venv в `~/.knowledge-rag/venv`, ставит PyPI-пакет.

**Один сервер = одна база** (папка с `config.yaml`, задаётся env `KNOWLEDGE_RAG_DIR`). Каждый проект — отдельная база и отдельный entry в mcp.json.

**Не путать:** `knowledge-mcp` (LightRAG-базы, другой сервер) и learn/память omp (`memory.backend`) — опыт из сессий, RAG не заменяет.

## Когда использовать

- новый проект: создать базу RAG и подключить к omp
- «настрой RAG для проекта X», «подключи базу знаний»
- реконфигурация: смена embedding-модели, путей, документов
- починка: модель не загружается, handshake-ошибка, документы не индексируются

## Шаги

1. **Папка базы:** `D:/RAG/<project>/` + подпапки `data/`, `models_cache/`.
2. **config.yaml** — из `references/config.yaml.template`. Обязательно:
   - `documents_dir` — **абсолютный путь к корню репо проекта** (не шаблонный!)
   - `data_dir` / `models_cache_dir` — абсолютные (относительные зависят от cwd запуска)
   - `collection_name` — уникальное имя
   - `query_expansion_groups` — термины проекта (синонимы, рус/англ)
   - exclude: `.git`, `build`, `run`, `.obsidian`, `node_modules` и т.д.
3. **Запись в `~/.omp/agent/mcp.json`** — сервер `knowledge-rag-<project>`:
   ```json
   "knowledge-rag-<project>": {
     "type": "stdio",
     "command": "npx",
     "args": ["-y", "knowledge-rag@4.6.0"],
     "timeout": 120000,
     "env": { "KNOWLEDGE_RAG_DIR": "D:/RAG/<project>" }
   }
   ```
   **Версию в args ПИНИТЬ (`@4.6.0`)** — см. Ошибки, mcp-спека.
4. **RULES.md** — `references/rules-template.md` → `<repo>/.omp/RULES.md` (создать `.omp/` в репо). Sticky-правило: когда искать, стратегия, приоритет достоверности, что сохранять. Подхватывается только в сессиях из папки проекта.
5. **Перезапуск:** `/mcp reload` → `/mcp list` → `/mcp test knowledge-rag-<project>`.
6. **Первая индексация** — сервер сам индексирует при старте (первый раз может занять минуты: качает embedding-модель ~240МБ). Дождаться завершения: `get_index_stats` (total_documents/total_chunks, `reindex.active: false`).
7. **Верификация:** `search_knowledge` по термину проекта (1-3 слова, hybrid_alpha 0.3), проверить, что результаты релевантны и reranker_score присутствует. Через несколько дней — `evaluate_retrieval` (MRR@5/Recall@5).

## Общие ошибки

| Симптом | Причина | Фикс |
|---|---|---|
| `Model intfloat/multilingual-e5-small is not supported in TextEmbedding` | e5-small нет в fastembed этой версии | заменить на `sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2` + полный rebuild |
| `/mcp test` падает с handshake/initialize-ошибкой | knowledge-rag ≥4.7 использует MCP spec 2026-07-28 (mcp SDK 2.0.0, без initialize-handshake); omp не в списке протестированных клиентов | пин `knowledge-rag@4.6.0` в args (классический handshake) |
| Документы не индексируются | exclude_patterns перекрывает их, или формат вне supported_formats | проверить конфиг, `reindex_documents(force=true)` |
| RULES.md «не работает» | сессия запущена не из папки проекта | запускать omp из репо (или продублировать правило в `~/.omp/agent/RULES.md` глобально) |
| Данные/модели пишутся не туда | относительные пути в config.yaml | только абсолютные |
| GPU-ускорение не помогает | `gpu: true` работает только с NVIDIA/CUDA | на AMD/CPU оставить `gpu: false` — для сотен документов скорости хватает |
| GPU включён, но сервер падает (нет DLL) | onnxruntime-gpu не установлен или нет CUDA/cuDNN | `venv\Scripts\pip install onnxruntime-gpu` + CUDA 12.x/cuDNN 9.x + свежий драйвер NVIDIA; не помогло — верни `gpu: false` |
| После смены embedding-модели старые чанки | коллекция создана другой моделью | сервер сам пересоздаст коллекцию (RECOVERY) либо `reindex_documents(full_rebuild=true)` |

## Модели

- **embedding:** `sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2` — 384 dims, ~50 языков (русский+английский), ONNX-Q ~240МБ. Рекомендация для русскоязычных проектов.
- **reranker:** `Xenova/ms-marco-MiniLM-L-6-v2` — ~25МБ, подтягивается при первом поиске.
- **кэш моделей:** `models_cache_dir` — для нескольких баз указывать **общий** кэш (например `D:/RAG/models_cache`), модели скачаются один раз.
- **GPU:** `gpu: true` работает только на NVIDIA (нужен `onnxruntime-gpu` в venv + CUDA 12.x/cuDNN 9.x + свежий драйвер). На AMD/Intel — CPU. После включения GPU индекс пересоздавать не нужно (модель та же, ускоряется вычисление).
- смена embedding-модели/размерности → полный rebuild индекса.

## Инструменты сервера (13)

`search_knowledge`, `search_similar`, `get_document`, `list_documents`, `list_categories`, `get_index_stats`, `get_reindex_status`, `reindex_documents` (force/full_rebuild), `add_document`, `add_from_url`, `update_document`, `remove_document`, `evaluate_retrieval`.

Watcher следит за файлами проекта сам — реиндекс вручную только при сбоях.
