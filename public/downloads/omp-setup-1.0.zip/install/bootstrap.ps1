﻿# omp-setup 1.0 — bootstrap.ps1
# Предусловия (node/python/git/uv/omp) и запуск плана установки:
#     python install\setup.py --check
#
# Запуск из распакованного архива (рядом с папкой install/):
#     powershell -ExecutionPolicy Bypass -File bootstrap.ps1
#     (или: pwsh -NoProfile -File bootstrap.ps1)
#
# Выходной код: 0 — план готов; 1 — python не найден;
#               иначе — код возврата setup.py --check.

$ErrorActionPreference = 'Stop'

$root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path

Write-Host ''
Write-Host 'omp-setup 1.0 — проверка предусловий'

$pythonOk = $false

foreach ($cmd in @('node', 'python', 'git', 'uv', 'omp')) {
    try {
        Get-Command $cmd -ErrorAction Stop | Out-Null
        $ver = (& $cmd --version 2>&1 | Select-Object -First 1)
        Write-Host ('PASS  {0,-6} {1}' -f $cmd, $ver)
        if ($cmd -eq 'python') { $pythonOk = $true }
    } catch {
        Write-Host ('MISS  {0,-6} не найден в PATH' -f $cmd)
    }
}

if (-not $pythonOk) {
    Write-Host ''
    Write-Host 'ОШИБКА: python не найден. Установите Python 3.11+ (https://www.python.org/downloads/)' -ForegroundColor Red
    Write-Host 'и добавьте его в PATH, затем запустите bootstrap.ps1 снова.'
    exit 1
}

Write-Host ''
Write-Host ('Установщик: python "{0}\install\setup.py" --check --home {1}' -f $root, $env:USERPROFILE)

& python (Join-Path $root 'install\setup.py') --check --home $env:USERPROFILE
$code = $LASTEXITCODE

Write-Host ''
Write-Host 'Подсказка: если план ОК — запусти: python install\setup.py --apply, затем python install\doctor.py'
Write-Host '          doctor.py проверяет установку и завершается с кодом 0 при отсутствии FAIL.'

exit $code