#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# omp-setup 1.0 — установка MCP-сервера camoufox-research на новой машине.
# Пакет и venv НЕ входят в архив переноса — этот скрипт ставит их из репозитория.
#
# Метод установки (повторяет README репозитория, проверено на машине-доноре):
#   1. git clone https://github.com/aidvizhhub/camoufox-research.git  <dir>
#   2. python -m venv <dir>\.venv
#   3. <dir>\.venv\Scripts\python.exe -m pip install .   (из <dir>)
#   4. [опционально] python -m camoufox fetch            (браузер, ~500 МБ, один раз)
#   5. проверка: <dir>\.venv\Scripts\camoufox-research.exe --help
#      → в выводе должно быть «MCP-сервер» (argparse description точки входа).
#
# Работает на Windows (python -m venv + Scripts\*.exe), только stdlib.
# --check ничего не создаёт и не меняет; --apply — реальная установка.
# Кодировка: вывод скрипта UTF-8 (консоль Windows cp1251 переключается на utf-8),
# дочерние процессы запускаются с PYTHONUTF8=1 / PYTHONIOENCODING=utf-8.
import argparse
import os
import shutil
import subprocess
import sys

REPO_URL = "https://github.com/aidvizhhub/camoufox-research.git"
PACKAGE = "camoufox-research"
VENV_DIR_NAME = ".venv"
HELP_MARKER = "MCP-сервер"  # маркер валидности exe в выводе --help

# Таймауты подпроцессов, сек (репозиторий маленький; pip тянет ~100 МБ зависимостей;
# camoufox fetch — ~500 МБ браузер).
TIMEOUT_CLONE = 300
TIMEOUT_VENV = 300
TIMEOUT_PIP = 1800
TIMEOUT_FETCH = 3600
TIMEOUT_CHECK = 120


def _log(msg: str) -> None:
    """Одна строка лога в stdout."""
    print(msg, flush=True)


def _err(msg: str) -> None:
    """Одна строка ошибки в stderr, с префиксом."""
    print(f"ошибка: {msg}", file=sys.stderr, flush=True)


def _venv_dir(target: str) -> str:
    """Каталог venv внутри целевого каталога."""
    return os.path.join(target, VENV_DIR_NAME)


def _venv_python(target: str) -> str:
    """Путь к python.exe venv (Windows: Scripts, иначе bin)."""
    if os.name == "nt":
        return os.path.join(_venv_dir(target), "Scripts", "python.exe")
    return os.path.join(_venv_dir(target), "bin", "python")


def _venv_exe(target: str, name: str) -> str:
    """Путь к exe-консольному скрипту venv (camoufox-research.exe и т.п.)."""
    if os.name == "nt":
        return os.path.join(_venv_dir(target), "Scripts", f"{name}.exe")
    return os.path.join(_venv_dir(target), "bin", name)


def _child_env() -> dict:
    """Окружение дочерних процессов: принудительный UTF-8 (Windows cp1251)."""
    env = dict(os.environ)
    env["PYTHONUTF8"] = "1"
    env["PYTHONIOENCODING"] = "utf-8"
    return env


def _run(cmd, *, timeout, cwd=None, capture: bool = False):
    """Запуск подпроцесса. capture=True → вернуть (code, text), без raise;
    иначе — сквозной вывод, CalledProcessError при ненулевом коде."""
    kwargs = dict(cwd=cwd, env=_child_env(), timeout=timeout)
    if capture:
        proc = subprocess.run(cmd, capture_output=True, **kwargs)
        text = (proc.stdout or b"").decode("utf-8", errors="replace")
        text += (proc.stderr or b"").decode("utf-8", errors="replace")
        return proc.returncode, text
    subprocess.run(cmd, check=True, **kwargs)
    return 0, ""


def _is_git_repo(target: str) -> bool:
    """Целевой каталог — клон репозитория (есть .git)?"""
    return os.path.isdir(os.path.join(target, ".git"))


# ---------------------------------------------------------------------------
# Проверка состояния
# ---------------------------------------------------------------------------

def check_install(target: str, verbose: bool = True) -> bool:
    """Проверка, что пакет установлен в <target>. Ничего не создаёт и не пишет.
    Критерии:
      1) venv существует и в нём есть python.exe;
      2) установлен пакет (import camoufox_research из venv);
      3) exe <package>.exe существует и `--help` содержит «MCP-сервер».
    Возвращает True — установлено (exit 0), False — нет (exit 1)."""
    problems: list[str] = []
    if verbose:
        _log(f"[check] цель: {target}")

    py = _venv_python(target)
    if not os.path.isfile(py):
        problems.append("venv не найден: нет python.exe")
    else:
        if verbose:
            _log(f"[check] venv найден: {_venv_dir(target)}")

        # Пакет импортируется из venv?
        code, text = _run([py, "-c", "import camoufox_research; print('ok')"],
                          timeout=TIMEOUT_CHECK, capture=True)
        if code != 0:
            problems.append("пакет camoufox_research не установлен в venv")
            if verbose and text.strip():
                _log(f"[check] import: {text.strip().splitlines()[-1]}")
        elif verbose:
            _log("[check] пакет импортируется: ok")

        # exe есть и отвечает --help маркером «MCP-сервер»?
        exe = _venv_exe(target, PACKAGE)
        if not os.path.isfile(exe):
            problems.append(f"нет консольного скрипта: {exe}")
        else:
            code, text = _run([exe, "--help"], timeout=TIMEOUT_CHECK, capture=True)
            if code != 0:
                problems.append(f"{exe} --help завершился с кодом {code}")
            elif HELP_MARKER not in text:
                problems.append(f"--help не содержит «{HELP_MARKER}»")
            elif verbose:
                _log(f"[check] {PACKAGE} --help: ok («{HELP_MARKER}» найден)")

    if problems:
        if verbose:
            _log("[check] ВЕРДИКТ: НЕ УСТАНОВЛЕНО")
            for p in problems:
                _err(p)
        return False
    if verbose:
        _log("[check] ВЕРДИКТ: УСТАНОВЛЕНО")
    return True


# ---------------------------------------------------------------------------
# Установка
# ---------------------------------------------------------------------------

def _clone_repo(target: str) -> None:
    """Клонирование репозитория, если каталога ещё нет."""
    if os.path.isdir(target):
        if _is_git_repo(target):
            _log(f"[install] репозиторий уже есть: {target} (использую как есть)")
            return
        if os.listdir(target):
            _err(f"каталог {target} существует и не похож на клон репозитория")
            _err("не трогаю его содержимое — удалите/переименуйте вручную и повторите")
            raise RuntimeError("target существует и не является git-репозиторием")
        # Каталог существует, но пустой — безопасно клонировать в него.
    if shutil.which("git") is None:
        raise RuntimeError(
            "git не найден в PATH — установите Git для Windows "
            "(https://git-scm.com/download/win) и повторите")
    _log(f"[install] git clone {REPO_URL}")
    _run(["git", "clone", "--quiet", REPO_URL, target],
         timeout=TIMEOUT_CLONE)
    if not _is_git_repo(target):
        raise RuntimeError("git clone завершился, но каталог не содержит .git — "
                           "проверьте сеть и права на запись")


def _make_venv(target: str, python: str) -> None:
    """venv в <target>/.venv (повторный запуск переиспользует существующий)."""
    vdir = _venv_dir(target)
    py = _venv_python(target)
    if os.path.isfile(py):
        _log(f"[install] venv уже есть: {vdir} (переиспользую)")
        return
    _log(f"[install] python -m venv {vdir}")
    _run([python, "-m", "venv", vdir], timeout=TIMEOUT_VENV)
    if not os.path.isfile(py):
        raise RuntimeError(f"venv создан, но {py} не найден")


def _pip_install(target: str) -> None:
    """pip install . внутри клона (Python из venv, cwd = каталог репо)."""
    py = _venv_python(target)
    _log(f"[install] pip install . (зависимости: mcp, camoufox, trafilatura…)")
    _run([py, "-m", "pip", "install", "."], cwd=target, timeout=TIMEOUT_PIP)


def _fetch_browser(target: str) -> None:
    """Скачивание анти-детект браузера Camoufox (~500 МБ, один раз)."""
    py = _venv_python(target)
    _log("[install] python -m camoufox fetch (браузер ~500 МБ, один раз…)")
    _run([py, "-m", "camoufox", "fetch"], cwd=target, timeout=TIMEOUT_FETCH)


def install(target: str, python: str, do_fetch: bool) -> None:
    """Полная установка: клон → venv → pip install . → [fetch] → проверка."""
    if os.path.isdir(target):
        _log(f"[install] каталог уже существует: {target}")
    else:
        os.makedirs(target, exist_ok=True)
    _clone_repo(target)
    _make_venv(target, python)
    _pip_install(target)
    if do_fetch:
        _fetch_browser(target)
    # Финальная проверка (см. check_install) — при провале бросаем исключение.
    if not check_install(target, verbose=True):
        raise RuntimeError("финальная проверка не прошла после установки")


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def parse_args(argv=None):
    ap = argparse.ArgumentParser(
        prog="install_camoufox.py",
        description="omp-setup 1.0 — установка MCP-сервера camoufox-research "
                    "(venv + пакет из репозитория). Без флагов — безопасная "
                    "проверка состояния (--check).")
    ap.add_argument(
        "--dir", default=None, metavar="PATH",
        help="каталог установки (по умолчанию ~/.omp/abyss/vendor/"
             "camoufox-research)")
    ap.add_argument(
        "--check", action="store_true",
        help="только проверить, что пакет установлен "
             "(ничего не создаёт и не меняет; exit 0 — установлено)")
    ap.add_argument(
        "--apply", action="store_true",
        help="установить: git clone → python -m venv → pip install . → "
             "финальная проверка exe --help")
    ap.add_argument(
        "--fetch", action="store_true",
        help="после установки скачать браузер Camoufox "
             "(python -m camoufox fetch, ~500 МБ, один раз; нужен интернет)")
    ap.add_argument(
        "--python", default=None, metavar="PATH",
        help="интерпретатор для создания venv "
             "(по умолчанию — python, которым запущен скрипт)")
    args = ap.parse_args(argv)
    target = os.path.abspath(os.path.expanduser(
        args.dir or os.path.join("~", ".omp", "abyss", "vendor",
                                 "camoufox-research")))
    python = args.python or sys.executable
    return args, target, python


def main(argv=None) -> int:
    # Консоль Windows по умолчанию cp1251 — переключаем на UTF-8.
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except Exception:  # noqa: BLE001 — reconfigure опционален
        pass

    args, target, python = parse_args(argv)
    if args.dir:
        _log(f"[omp-setup] camoufox-research, каталог: {target}")

    # Без явного режима — безопасный --check.
    mode = "apply" if args.apply else "check"

    try:
        if mode == "check":
            ok = check_install(target, verbose=True)
            return 0 if ok else 1
        install(target, python, do_fetch=args.fetch)
        _log("[install] ГОТОВО: camoufox-research установлен и проверен")
        py = _venv_python(target)
        exe = _venv_exe(target, PACKAGE)
        _log(f"[install] venv:   {_venv_dir(target)}")
        _log(f"[install] python: {py}")
        _log(f"[install] exe:    {exe}")
        if args.fetch:
            _log("[install] браузер Camoufox скачан (python -m camoufox fetch)")
        return 0
    except subprocess.TimeoutExpired as e:
        _err(f"таймаут: {e} — сервер недоступен или установка слишком долгая?")
        return 1
    except (OSError, RuntimeError, subprocess.CalledProcessError) as e:
        _err(str(e))
        if isinstance(e, subprocess.CalledProcessError):
            _err("нет доступа к сети или репозиторию? Установка требует интернет "
                 "(git clone + pip install + [fetch]); офлайн установка невозможна.")
        _err("установка не завершена (код 1)")
        return 1


if __name__ == "__main__":
    sys.exit(main())