#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
omp-setup 1.0 — doctor.py: постинсталльная проверка.

Проверяет установленный профиль (--home), целостность корня архива (--staging)
и окружение новой машины. Секреты в вывод не попадают: для models.yml печатаются
только имена провайдеров (apiKey никогда не логируется).

Выходной код:
  0 — FAIL нет (установка корректна);
  2 — есть хотя бы один FAIL (проблемы, требующие исправления);
  1 — внутренняя ошибка скрипта.

Запуск:
  python doctor.py [--home DIR] [--staging DIR] [--json]

Скрипт рассчитан на запуск из распакованного архива: рядом ожидаются
CLAUDE.md, skills/, omp/ (проверка --staging), а установленный профиль
лежит в --home.
"""

import argparse
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

VERSION = "1.0"
PACKAGE = "omp-setup"

try:
    import tomllib  # python >= 3.11
except ImportError:  # pragma: no cover — очень старый python
    tomllib = None

try:
    import yaml
except ImportError:
    yaml = None

# Каталоги времени исполнения: не являются «установленными файлами»,
# при сканировании меток подстановки их пропускаем.
RUNTIME_DIRS = {
    "history", "logs", "blobs", "terminal-sessions", "memories", "cache",
    "sessions", "databases", "__pycache__", "node_modules", ".git", ".venv",
    "tmp", "temp", ".cache", "autoupdate", "marketplace-cache", "abyss",
}
# Двоичные/большие форматы — не текст, метки там не ищем.
SKIP_EXTS = {
    ".db", ".db3", ".sqlite", ".sqlite3", ".png", ".jpg", ".jpeg", ".gif",
    ".webp", ".ico", ".bmp", ".tif", ".tiff", ".pdf", ".zip", ".7z", ".rar",
    ".gz", ".xz", ".exe", ".dll", ".pyc", ".pyd", ".jar", ".class", ".bin",
    ".wav", ".mp3", ".mp4", ".woff", ".woff2", ".ttf", ".otf", ".eot", ".dat",
}
MAX_SCAN_BYTES = 2 * 1024 * 1024  # файлы больше — не текст инсталляции
EXEMPT_TOKEN_FILE = Path(".claude") / "skills" / "transferring-omp-setup" / "SKILL.md"
# Документированный литерал: этот файл может честно содержать __USERNAME__/__USERNAME__.


def reconfigure_stdout():
    """Гарантируем UTF-8 в stdout/stderr независимо от кодовой страницы."""
    try:
        for stream in (sys.stdout, sys.stderr):
            if stream is not None and hasattr(stream, "reconfigure"):
                stream.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass


def run_check(fn):
    """Выполняет проверку, нормализует статус, ловит исключения."""
    try:
        status, detail = fn()
    except Exception as exc:  # noqa: BLE001 — проверка не должна ронять doctor
        return "FAIL", "ошибка проверки: {}: {}".format(type(exc).__name__, exc)
    status = str(status).upper()
    if status not in ("PASS", "WARN", "FAIL"):
        return "FAIL", "некорректный статус {!r}: {}".format(status, detail)
    return status, str(detail)


def count_skill_dirs(root):
    """Число непосредственных подпапок с SKILL.md."""
    if not root.is_dir():
        return -1
    return sum(1 for c in root.iterdir() if c.is_dir() and (c / "SKILL.md").is_file())


def count_files(root, suffix, recursive=False):
    """Число файлов с заданным суффиксом; -1 если папки нет."""
    if not root.is_dir():
        return -1
    if recursive:
        return sum(1 for p in root.rglob("*" + suffix) if p.is_file())
    return sum(1 for p in root.iterdir() if p.is_file() and p.name.endswith(suffix))


def provider_names(data):
    """Имена провайдеров из models.yml. Значения (apiKey) не читаются и не выводятся."""
    def names_from_list(items):
        out = []
        for item in items:
            if isinstance(item, dict):
                n = item.get("name")
                if isinstance(n, str) and n:
                    out.append(n)
        return out

    if isinstance(data, dict):
        pv = data.get("providers")
        if isinstance(pv, list):
            names = names_from_list(pv)
        else:
            names = [k for k in data if isinstance(k, str) and not k.startswith("_")]
    elif isinstance(data, list):
        names = names_from_list(data)
    else:
        names = []
    return ", ".join(names) if names else "(структура не распознана)"


def run_tool(name, arg):
    """Запускает '<name> <arg>' один раз. Возвращает (найден ли, первая строка вывода)."""
    exe = shutil.which(name)
    if not exe:
        return False, ""
    try:
        r = subprocess.run([exe, arg], capture_output=True, timeout=30)
    except Exception as exc:
        return True, "(не запускается: {}: {})".format(type(exc).__name__, exc)
    out = (r.stdout + r.stderr).decode("utf-8", "replace").strip().splitlines()
    first = out[0].strip()[:80] if out else ""
    return True, first or "(exit {})".format(r.returncode)


def scan_tokens(home, token):
    """Ищет байтовую метку в установленных файлах ~/.claude и ~/.omp.

    Возвращает список относительных путей файлов с меткой (до 20).
    """
    if not home.is_dir():
        return None  # профиль не установлен
    exempt = home / EXEMPT_TOKEN_FILE
    hits = []
    for root in (home / ".claude", home / ".omp"):
        if not root.is_dir():
            continue
        for dirpath, dirnames, filenames in os.walk(root):
            dirnames[:] = [d for d in dirnames if d not in RUNTIME_DIRS]
            for fname in filenames:
                fp = Path(dirpath) / fname
                if fp == exempt:
                    continue
                if fname.startswith(".changes-seen-") or fname == "last-changelog-version":
                    continue
                if fp.suffix.lower() in SKIP_EXTS:
                    continue
                try:
                    if fp.stat().st_size > MAX_SCAN_BYTES:
                        continue
                    data = fp.read_bytes()
                except OSError:
                    continue
                if token in data:
                    hits.append(str(fp.relative_to(home)))
                    if len(hits) >= 20:
                        return hits
    return hits


def build_checks(home, staging):
    """Собирает список проверок: (id, название, функция -> (статус, детали))."""
    checks = []

    def add(cid, name, fn):
        checks.append((cid, name, fn))

    # --- 0. Архив (staging) ------------------------------------------------
    def ch_staging():
        if not staging.is_dir():
            return "FAIL", "корень staging не найден: " + str(staging)
        missing = [n for n in ("CLAUDE.md", "skills", "omp", "install")
                   if not (staging / n).exists()]
        if missing:
            return "FAIL", "отсутствует: " + ", ".join(missing)
        return "PASS", "CLAUDE.md, skills/, omp/, install/ на месте"
    add("0.1", "Архив (staging) — корень полный", ch_staging)

    # --- 1. Файлы на месте --------------------------------------------------
    def ch_exists(rel, label):
        def fn():
            p = home / rel
            if p.exists():
                return "PASS", "найден"
            return "FAIL", "не найден: " + str(p)
        return fn

    add("1.1", "~/.claude/CLAUDE.md", ch_exists(Path(".claude") / "CLAUDE.md", "~/.claude/CLAUDE.md"))
    add("1.2", "~/.claude/skills (папки со SKILL.md)", ch_exists(Path(".claude") / "skills", "~/.claude/skills"))
    add("1.3", "~/.claude/jujutsu-skills", ch_exists(Path(".claude") / "jujutsu-skills", "~/.claude/jujutsu-skills"))
    add("1.4", "~/.omp/agent/config.yml", ch_exists(Path(".omp") / "agent" / "config.yml", "~/.omp/agent/config.yml"))
    add("1.5", "~/.omp/agent/models.yml", ch_exists(Path(".omp") / "agent" / "models.yml", "~/.omp/agent/models.yml"))
    add("1.6", "~/.omp/agent/mcp.json", ch_exists(Path(".omp") / "agent" / "mcp.json", "~/.omp/agent/mcp.json"))
    add("1.7", "~/.omp/agent/lsp.json", ch_exists(Path(".omp") / "agent" / "lsp.json", "~/.omp/agent/lsp.json"))
    add("1.8", "~/.omp/agent/APPEND_SYSTEM.md", ch_exists(Path(".omp") / "agent" / "APPEND_SYSTEM.md", "~/.omp/agent/APPEND_SYSTEM.md"))

    def ch_skills():
        root = home / ".claude" / "skills"
        if not root.is_dir():
            return "FAIL", "папка не найдена: " + str(root)
        n = count_skill_dirs(root)
        return ("PASS" if n >= 50 else "FAIL"), "папок со SKILL.md: {} (мин. 50)".format(n)
    add("1.9", "~/.claude/skills — число скиллов", ch_skills)

    def ch_jujutsu():
        root = home / ".claude" / "jujutsu-skills"
        if not root.is_dir():
            return "FAIL", "папка не найдена: " + str(root)
        n = sum(1 for c in root.iterdir() if c.is_dir())
        return ("PASS" if 1 <= n <= 4 else "FAIL"), \
            "папок: {} (ожидалось 1-4; донор: 1 — остальные удалены, можно восстановить из 0.7 omp.zip)".format(n)
    add("1.10", "~/.claude/jujutsu-skills — число папок", ch_jujutsu)

    def ch_hooks():
        root = home / ".omp" / "agent" / "hooks" / "pre"
        if not root.is_dir():
            return "FAIL", "папка не найдена: " + str(root)
        n = count_files(root, ".js")
        return ("PASS" if n >= 4 else "FAIL"), "js-хуков: {} (мин. 4)".format(n)
    add("1.11", "~/.omp/agent/hooks/pre — js-хуки", ch_hooks)

    def ch_legacy_blockers():
        root = home / ".omp" / "agent" / "hooks" / "pre"
        banned = [f for f in ("danger-commands.js", "module-limits.js")
                  if (root / f).is_file()]
        if banned:
            return "WARN", \
                "в pre остались 0.7-хуки: {} — на доноре они в .disabled " \
                "(отключены намеренно); перенеси их в hooks\\.disabled".format(
                    ", ".join(banned))
        return "PASS", "0.7-блокеры не найдены (донорский режим)"
    add("1.11b", "hooks/pre — 0.7-блокеры (danger/module-limits)", ch_legacy_blockers)

    def ch_agents():
        root = home / ".omp" / "agent" / "agents"
        n = count_files(root, ".md")
        return ("PASS" if n >= 9 else "FAIL"), "md-ролей: {} (мин. 9)".format(n)
    add("1.12", "~/.omp/agent/agents — роли", ch_agents)

    def ch_themes():
        root = home / ".omp" / "agent" / "themes"
        n = count_files(root, ".json")
        return ("PASS" if n >= 2 else "FAIL"), "json-тем: {} (мин. 2)".format(n)
    add("1.13", "~/.omp/agent/themes — темы", ch_themes)

    def ch_omp_skills():
        root = home / ".omp" / "agent" / "skills"
        if not root.is_dir():
            return "FAIL", "папка не найдена: " + str(root)
        n = count_skill_dirs(root)
        return ("PASS" if n >= 40 else "FAIL"), "папок со SKILL.md: {} (мин. 40)".format(n)
    add("1.14", "~/.omp/agent/skills — скиллы агента", ch_omp_skills)

    def ch_db_tools():
        root = home / ".omp" / "agent" / "db-tools"
        n = count_files(root, ".py")
        return ("PASS" if n >= 13 else "FAIL"), "py-файлов: {} (мин. 13; донор: 14)".format(n)
    add("1.15", "~/.omp/agent/db-tools — инструменты", ch_db_tools)

    def ch_canon():
        root = home / ".omp" / "agent" / "docs" / "canon"
        n = count_files(root, ".md", recursive=True)
        return ("PASS" if n >= 25 else "FAIL"), "md-доков: {} (мин. 25)".format(n)
    add("1.16", "~/.omp/agent/docs/canon — канон", ch_canon)

    def ch_managed():
        root = home / ".omp" / "agent" / "managed-skills"
        if not root.is_dir():
            return "FAIL", "папка не найдена: " + str(root)
        n = count_skill_dirs(root)
        return ("PASS" if n >= 3 else "FAIL"), "папок со SKILL.md: {} (мин. 3)".format(n)
    add("1.17", "~/.omp/agent/managed-skills", ch_managed)

    # --- 2. Валидность конфигов --------------------------------------------
    def ch_json_file(rel, label, show_providers=False):
        def fn():
            p = home / rel
            if not p.is_file():
                return "FAIL", "файл не найден"
            try:
                data = json.loads(p.read_bytes())
            except Exception as exc:
                return "FAIL", "не парсится: {}".format(type(exc).__name__)
            if show_providers:
                return "PASS", "JSON валиден, провайдеры: " + provider_names(data)
            return "PASS", "JSON валиден"
        return fn

    add("2.1", "mcp.json — валидность", ch_json_file(Path(".omp") / "agent" / "mcp.json", "mcp.json"))
    add("2.2", "lsp.json — валидность", ch_json_file(Path(".omp") / "agent" / "lsp.json", "lsp.json"))

    def ch_themes_json():
        root = home / ".omp" / "agent" / "themes"
        if not root.is_dir():
            return "FAIL", "папка themes не найдена"
        files = sorted(root.glob("*.json"))
        if not files:
            return "FAIL", "json-тем нет"
        bad = []
        for f in files:
            try:
                json.loads(f.read_bytes())
            except Exception as exc:
                bad.append("{}: {}".format(f.name, type(exc).__name__))
        if bad:
            return "FAIL", "не парсится: " + "; ".join(bad[:3])
        return "PASS", "файлов валидны: {}".format(len(files))
    add("2.3", "themes/*.json — валидность", ch_themes_json)

    def ch_yaml_file(rel, label, show_providers=False):
        def fn():
            p = home / rel
            if not p.is_file():
                return "FAIL", "файл не найден"
            if yaml is None:
                return "WARN", "yaml-модуль не установлен — пропущено"
            try:
                data = yaml.safe_load(p.read_bytes())
            except Exception as exc:
                return "FAIL", "не парсится: {}".format(type(exc).__name__)
            if show_providers:
                return "PASS", "YAML валиден, провайдеры: " + provider_names(data)
            return "PASS", "YAML валиден"
        return fn

    add("2.4", "config.yml — валидность",
        ch_yaml_file(Path(".omp") / "agent" / "config.yml", "config.yml"))
    add("2.5", "models.yml — валидность (секреты не выводятся)",
        ch_yaml_file(Path(".omp") / "agent" / "models.yml", "models.yml", show_providers=True))

    def ch_toml():
        root = home / ".omp" / "agent"
        if not root.is_dir():
            return "FAIL", "папка agent не найдена"
        files = sorted(root.glob("*.toml"))
        if not files:
            return "PASS", "*.toml нет — проверять нечего"
        if tomllib is None:
            return "WARN", "tomllib недоступен (python < 3.11) — пропущено"
        bad = []
        for f in files:
            try:
                f.read_bytes()
                tomllib.loads(f.read_text(encoding="utf-8"))
            except Exception as exc:
                bad.append("{}: {}".format(f.name, type(exc).__name__))
        if bad:
            return "FAIL", "не парсится: " + "; ".join(bad[:3])
        return "PASS", "файлов валидны: {}".format(len(files))
    add("2.6", "*.toml в ~/.omp/agent — валидность", ch_toml)

    # --- 3. node --check для хуков ------------------------------------------
    def ch_node_checks():
        root = home / ".omp" / "agent" / "hooks" / "pre"
        if not root.is_dir():
            return "FAIL", "папка hooks/pre не найдена"
        files = sorted(root.glob("*.js"))
        if not files:
            return "FAIL", "js-хуков нет"
        exe = shutil.which("node")
        if not exe:
            return "WARN", "node не найден в PATH — проверка пропущена ({} файлов)".format(len(files))
        bad = []
        for f in files:
            try:
                r = subprocess.run([exe, "--check", str(f)], capture_output=True, timeout=30)
            except Exception as exc:
                bad.append("{}: не запускается ({})".format(f.name, type(exc).__name__))
                continue
            if r.returncode != 0:
                msg = (r.stderr or r.stdout or b"").decode("utf-8", "replace").strip().splitlines()
                bad.append("{}: {}".format(f.name, msg[0][:100] if msg else "exit " + str(r.returncode)))
        if bad:
            return "FAIL", "; ".join(bad[:3]) + (" …" if len(bad) > 3 else "")
        return "PASS", "проверено файлов: {}".format(len(files))
    add("3.1", "node --check hooks/pre/*.js", ch_node_checks)

    # --- 4. Метки подстановки ------------------------------------------------
    def ch_token(token, label, warn_only):
        def fn():
            hits = scan_tokens(home, token)
            if hits is None:
                return "FAIL", "профиль не установлен — сканирование невозможно"
            if hits:
                shown = ", ".join(hits[:5])
                more = " (+{} ещё)".format(len(hits) - 5) if len(hits) > 5 else ""
                status = "WARN" if warn_only else "FAIL"
                noun = "файле" if len(hits) == 1 else "файлах"
                return status, "найдено в {} {}: {}{}".format(len(hits), noun, shown, more)
            return "PASS", "не найден"
        return fn

    add("4.1", "__USERNAME__ в установленных файлах",
        ch_token(b"__USERNAME__", "__USERNAME__", warn_only=False))
    add("4.2", "__USERNAME__ в установленных файлах",
        ch_token(b"__USERNAME__", "__USERNAME__", warn_only=True))

    # --- 5. Каталоги данных (WARN — настраиваются по INSTALL.md) ------------
    data_items = [
        ("RAG\\jujutsu\\config.yaml", Path("D:/RAG/jujutsu/config.yaml"), True),
        ("D:\\WorkFlow\\Jujutsu Minecraft", Path("D:/WorkFlow/Jujutsu Minecraft"), False),
        ("D:\\WorkFlow\\BlockBench 3d models\\3d models vault",
         Path("D:/WorkFlow/BlockBench 3d models/3d models vault"), False),
        ("D:\\WorkFlow\\jujutsu-minecraft", Path("D:/WorkFlow/jujutsu-minecraft"), False),
        ("D:\\WorkFlow\\Knowledge", Path("D:/WorkFlow/Knowledge"), False),
        ("D:\\RAG\\general", Path("D:/RAG/general"), False),
    ]
    for i, (label, p, is_file) in enumerate(data_items, 1):
        def ch_data(p=p, is_file=is_file):
            ok = p.is_file() if is_file else p.is_dir()
            if ok:
                return "PASS", "найден"
            return "WARN", "не найден (создаётся по INSTALL.md)"
        add("5.{}".format(i), "Данные: " + label, ch_data)

    # --- 6. Окружение ---------------------------------------------------------
    for i, (tool, arg) in enumerate(
            [("omp", "--version"), ("node", "--version"), ("python", "--version"),
             ("git", "--version"), ("uv", "--version")], 1):
        def ch_tool(tool=tool, arg=arg):
            found, first = run_tool(tool, arg)
            if not found:
                return "WARN", "не найден в PATH"
            return "PASS", first or "(версия не выведена)"
        add("6.{}".format(i), "Окружение: {}".format(tool), ch_tool)

    def ch_mc_token():
        token = os.environ.get("MC_MCP_TOKEN", "")
        if token:
            return "PASS", "задан (длина {} символов)".format(len(token))
        mcp = home / ".omp" / "agent" / "mcp.json"
        if mcp.is_file():
            try:
                text = mcp.read_bytes()
            except OSError:
                text = b""
            if b"mc-world" in text:
                return "WARN", "MC_MCP_TOKEN пуст, а в mcp.json есть mc-world"
        return "PASS", "не требуется (mc-world не настроен)"
    add("6.6", "Окружение: MC_MCP_TOKEN", ch_mc_token)

    return checks


def truncate(text, width):
    text = str(text)
    return text if len(text) <= width else text[: width - 1] + "…"


def main(argv=None):
    parser = argparse.ArgumentParser(
        prog="doctor.py",
        description="omp-setup 1.0 — постинсталльная проверка профиля и окружения.")
    parser.add_argument(
        "--home", default=os.environ.get("USERPROFILE") or str(Path.home()),
        metavar="DIR", help="целевой профиль (default: %(default)s)")
    parser.add_argument(
        "--staging", default=str(Path(__file__).resolve().parent.parent),
        metavar="DIR", help="корень распакованного архива "
                            "(default: папка, содержащая install/)")
    parser.add_argument("--json", action="store_true",
                        help="дополнительно вывести JSON-отчёт")
    args = parser.parse_args(argv)

    home = Path(args.home)
    staging = Path(args.staging)

    results = []  # (id, name, status, detail)
    for cid, name, fn in build_checks(home, staging):
        status, detail = run_check(fn)
        results.append((cid, name, status, detail))

    # Таблица (всегда)
    print()
    print("{} {} — постинсталльная проверка".format(PACKAGE, VERSION))
    print("home:     {}".format(home))
    print("staging:  {}".format(staging))
    print()
    for cid, name, status, detail in results:
        print("{:<5} {:<56} {:<5} {}".format(
            cid, truncate(name, 56), status, truncate(detail, 100)))
    print()

    n_pass = sum(1 for _, _, s, _ in results if s == "PASS")
    n_warn = sum(1 for _, _, s, _ in results if s == "WARN")
    n_fail = sum(1 for _, _, s, _ in results if s == "FAIL")
    print("Итог: PASS {}, WARN {}, FAIL {}".format(n_pass, n_warn, n_fail))
    if n_fail:
        print("Вердикт: ЕСТЬ ПРОБЛЕМЫ — исправьте FAIL и запустите doctor.py снова.")
    else:
        print("Вердикт: OK — установка выглядит корректной.")

    exit_code = 2 if n_fail else 0

    if args.json:
        print()
        print(json.dumps({
            "tool": "doctor",
            "package": PACKAGE,
            "version": VERSION,
            "home": str(home),
            "staging": str(staging),
            "checks": [
                {"id": cid, "name": name, "status": status, "detail": detail}
                for cid, name, status, detail in results],
            "summary": {"pass": n_pass, "warn": n_warn, "fail": n_fail},
            "exit_code": exit_code,
        }, ensure_ascii=False, indent=2))

    return exit_code


if __name__ == "__main__":
    reconfigure_stdout()
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        sys.exit(130)
    except SystemExit:
        raise
    except Exception as exc:  # noqa: BLE001 — внутренняя ошибка => exit 1
        print("ВНУТРЕННЯЯ ОШИБКА: {}: {}".format(type(exc).__name__, exc), file=sys.stderr)
        sys.exit(1)