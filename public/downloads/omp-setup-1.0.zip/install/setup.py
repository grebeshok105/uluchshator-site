#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
omp-setup 1.0 — главный установщик Oh My Pi для новой Windows-машины.

Раскладывает содержимое распакованного архива (staging) по профилю
пользователя:
  CLAUDE.md, CLAUDE.neutral.md, skills/, jujutsu-skills/  -> <home>\\.claude\\
  omp/<файлы и каталоги>                                  -> <home>\\.omp\\agent\\
                                                           (marketplaces.json -> <home>\\.omp\\)

Ключевые механики:
  * подстановка __USERNAME__ -> имя пользователя выполняется байтово
    (read_bytes/write_bytes) ПОФАЙЛОВО при копировании: исходный архив не
    изменяется, line endings не портятся; исключения — литералы SUBST_EXCLUDE;
  * существующие файлы перед заменой копируются в бэкап
    <home>\\omp-setup-backup-<ГГГГММДД>\\ (относительная структура сохраняется);
  * extensions/tokentracker-notify.ts НЕ перезаписывается, если в существующем
    файле есть маркер '// @tokentracker-managed-omp-extension';
  * секреты (apiKey в models.yml) в отчёты не выводятся — только имена файлов;
  * верификация: каждый целевой файл существует и не пуст, JSON/TOML/YAML
    разбираются, hooks/*.js проверяются через node --check (если node есть),
    счётчики папок со SKILL.md и ролей сверяются с ожиданиями.

Режимы:
  --check   план + проверка источников и счётчиков; ничего не меняет; exit 0/1
  --apply   выполнить установку (по умолчанию, если не задан --check)
"""

from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import sys
import tomllib
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path

VERSION = "omp-setup 1.0"

# ---------------------------------------------------------------------------
# Раскладка: (архивный путь, целевой путь относительно профиля <home>).
# Каталоги копируются рекурсивно; файлы — по одному; имена не меняются.
# ---------------------------------------------------------------------------
MAP: list[tuple[str, str]] = [
    ("CLAUDE.md",             ".claude/CLAUDE.md"),
    ("CLAUDE.neutral.md",     ".claude/CLAUDE.neutral.md"),
    ("skills",                ".claude/skills"),
    ("jujutsu-skills",        ".claude/jujutsu-skills"),
    ("omp/config.yml",        ".omp/agent/config.yml"),
    ("omp/models.yml",        ".omp/agent/models.yml"),
    ("omp/mcp.json",          ".omp/agent/mcp.json"),
    ("omp/lsp.json",          ".omp/agent/lsp.json"),
    ("omp/APPEND_SYSTEM.md",  ".omp/agent/APPEND_SYSTEM.md"),
    ("omp/VERSION",           ".omp/agent/VERSION"),
    ("omp/changes-1.0.md",    ".omp/agent/changes-1.0.md"),
    ("omp/WATCHDOG.yml",      ".omp/agent/WATCHDOG.yml"),
    ("omp/WATCHDOG.md",       ".omp/agent/WATCHDOG.md"),
    ("omp/marketplaces.json", ".omp/marketplaces.json"),
    ("omp/hooks",             ".omp/agent/hooks"),
    ("omp/agents",            ".omp/agent/agents"),
    ("omp/managed-skills",    ".omp/agent/managed-skills"),
    ("omp/extensions",        ".omp/agent/extensions"),
    ("omp/themes",            ".omp/agent/themes"),
    ("omp/skills",            ".omp/agent/skills"),
    ("omp/db-tools",          ".omp/agent/db-tools"),
    ("omp/docs/canon",        ".omp/agent/docs/canon"),
    ("omp/scripts",           ".omp/agent/scripts"),
    ("omp/watchdog",          ".omp/agent/watchdog"),
]

# Фрагменты имён, исключаемые при рекурсивном копировании (папки и файлы).
EXCLUDE_FRAGMENTS = ("__pycache__", "node_modules", ".git", ".venv")

# Литералы документации — в них подстановка __USERNAME__ НЕ выполняется.
SUBST_EXCLUDE = ("INSTALL.md", "skills/transferring-omp-setup/SKILL.md")

# Файл расширения с защитой от перезаписи: маркер в существующем файле.
TOKEN_REL = "omp/extensions/tokentracker-notify.ts"
TOKEN_MARKER = b"// @tokentracker-managed-omp-extension"

# Счётчики верификации:
# (метка, архивный путь, целевой путь, минимум, максимум (None = без), способ)
# способ: "skill_dirs" — подпапки с SKILL.md; "js_files"/"md_files" — по расширению.
COUNTER_SPECS: list[tuple[str, str, str, int, int | None, str]] = [
    ("skills (SKILL.md-папки)", "skills",             ".claude/skills",           51, 55,   "skill_dirs"),
    ("jujutsu-skills",          "jujutsu-skills",     ".claude/jujutsu-skills",    1,  4,   "skill_dirs"),
    ("agent/skills",            "omp/skills",         ".omp/agent/skills",        42, 46,   "skill_dirs"),
    ("managed-skills",          "omp/managed-skills", ".omp/agent/managed-skills", 3, None, "skill_dirs"),
    ("hooks/pre (*.js)",        "omp/hooks/pre",      ".omp/agent/hooks/pre",      4,  4,   "js_files"),
    ("agents (*.md)",           "omp/agents",         ".omp/agent/agents",         9,  9,   "md_files"),
]

SUBST_NEEDLE = b"__USERNAME__"


@dataclass
class PlanEntry:
    """Один файл раскладки."""

    archive_rel: str      # posix-путь внутри архива (для исключений и отчёта)
    src: Path             # путь в staging
    dst: Path             # целевой путь в профиле
    missing: bool = False  # путь отсутствует в архиве


@dataclass
class Stats:
    """Счётчики выполнения apply."""

    copied: int = 0
    replaced: int = 0
    backed_up: int = 0
    skipped: int = 0
    errors: int = 0
    backup_errors: int = 0


# ---------------------------------------------------------------------------
# Этап 1: план
# ---------------------------------------------------------------------------

def build_plan(staging: Path, home: Path) -> list[PlanEntry]:
    """Собирает список файлов, которые будут разложены из staging в home."""
    entries: list[PlanEntry] = []
    for src_rel, dst_rel in MAP:
        src = staging / src_rel
        if src.is_dir():
            for dirpath, dirnames, filenames in os.walk(src):
                dirnames[:] = sorted(d for d in dirnames if d not in EXCLUDE_FRAGMENTS)
                filenames = sorted(f for f in filenames if f not in EXCLUDE_FRAGMENTS)
                for fn in filenames:
                    fsrc = Path(dirpath) / fn
                    sub = fsrc.relative_to(src)
                    entries.append(
                        PlanEntry(fsrc.relative_to(staging).as_posix(), fsrc, home / dst_rel / sub)
                    )
        elif src.is_file():
            entries.append(PlanEntry(src_rel, src, home / dst_rel))
        else:
            entries.append(PlanEntry(src_rel, src, home / dst_rel, missing=True))
    entries.sort(key=lambda e: e.archive_rel)
    return entries


# ---------------------------------------------------------------------------
# Этап 2: подстановка, бэкап, копирование
# ---------------------------------------------------------------------------

def substituted(data: bytes, archive_rel: str, username: str) -> bytes:
    """Байтовая подстановка __USERNAME__ -> имя пользователя (кроме литералов)."""
    if archive_rel in SUBST_EXCLUDE:
        return data
    return data.replace(SUBST_NEEDLE, username.encode("utf-8"))


def _has_token_marker(path: Path) -> bool:
    try:
        return TOKEN_MARKER in path.read_bytes()
    except OSError:
        return False


def _fresh_backup_dir(home: Path) -> Path:
    """<home>\\omp-setup-backup-<ГГГГММДД>; при повторе за день — суффикс -2, -3..."""
    base = home / f"omp-setup-backup-{datetime.now():%Y%m%d}"
    candidate, n = base, 2
    while candidate.exists():
        candidate = Path(f"{base}-{n}")
        n += 1
    return candidate


def _backup_one(path: Path, backup_dir: Path, home: Path) -> tuple[bool, str]:
    """Копирует существующий целевой файл в бэкап, сохраняя относительную структуру."""
    try:
        rel = path.relative_to(home).as_posix()
        target = backup_dir / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, target)
        return True, ""
    except OSError as exc:
        return False, str(exc)


def do_backup_pass(
    present: list[PlanEntry], home: Path, skip_backup: bool, stats: Stats, failures: list[str]
) -> tuple[Path | None, dict[str, str]]:
    """Бэкап существующих файлов + tokentracker-гард.

    Возвращает (каталог бэкапа или None, guarded: archive_rel -> причина пропуска).
    guarded заполняется для: файла с маркером tokentracker и файла, чей бэкап
    не удался (такой файл не заменяется — старая версия не должна пропасть).
    """
    guarded: dict[str, str] = {}
    backup_dir: Path | None = None
    for e in present:
        if not e.dst.exists():
            continue
        if e.archive_rel == TOKEN_REL and _has_token_marker(e.dst):
            guarded[e.archive_rel] = "маркер tokentracker"
            stats.skipped += 1
            continue
        if skip_backup:
            continue
        if backup_dir is None:
            backup_dir = _fresh_backup_dir(home)
        ok, msg = _backup_one(e.dst, backup_dir, home)
        if ok:
            stats.backed_up += 1
        else:
            guarded[e.archive_rel] = f"бэкап не удался: {msg}"
            stats.backup_errors += 1
            failures.append(f"{e.archive_rel}: бэкап не удался — файл НЕ заменён ({msg})")
    return backup_dir, guarded


def do_copy_pass(
    present: list[PlanEntry], username: str, guarded: dict[str, str], stats: Stats
) -> tuple[set[str], set[str]]:
    """Копирование каждого файла раскладки с пофайловой подстановкой.

    Возвращает (failed: archive_rel с ошибкой копирования, replaced: archive_rel,
    где на месте цели уже был файл до копирования).
    """
    failed: set[str] = set()
    replaced: set[str] = set()
    for e in present:
        if e.archive_rel in guarded:
            continue  # маркер или ошибка бэкапа — уже учтено
        existed = e.dst.exists()
        try:
            data = substituted(e.src.read_bytes(), e.archive_rel, username)
            e.dst.parent.mkdir(parents=True, exist_ok=True)
            e.dst.write_bytes(data)
        except OSError as exc:
            stats.errors += 1
            failed.add(e.archive_rel)
            continue
        stats.copied += 1
        if existed:
            stats.replaced += 1
            replaced.add(e.archive_rel)
    return failed, replaced


# ---------------------------------------------------------------------------
# Этап 3: верификация
# ---------------------------------------------------------------------------

def validate_one(path: Path, archive_rel: str) -> tuple[str | None, str, str]:
    """Возвращает (тип проверки, статус PASS/FAIL/SKIP, примечание)."""
    ext = path.suffix.lower()
    if ext == ".json":
        try:
            json.loads(path.read_bytes().decode("utf-8-sig"))
            return "json", "PASS", ""
        except Exception as exc:
            return "json", "FAIL", f"json: {exc}"
    if ext == ".toml":
        try:
            tomllib.loads(path.read_bytes().decode("utf-8-sig"))
            return "toml", "PASS", ""
        except Exception as exc:
            return "toml", "FAIL", f"toml: {exc}"
    if ext in (".yml", ".yaml"):
        try:
            import yaml  # опционально: если не установлен — проверка пропускается
        except ImportError:
            return "yaml", "SKIP", "yaml не установлен — проверка пропущена"
        try:
            yaml.safe_load(path.read_bytes().decode("utf-8-sig"))
            return "yaml", "PASS", ""
        except Exception as exc:
            return "yaml", "FAIL", f"yaml: {exc}"
    if ext == ".js" and archive_rel.startswith("omp/hooks/"):
        try:
            proc = subprocess.run(
                ["node", "--check", str(path)], capture_output=True, timeout=60
            )
        except FileNotFoundError:
            return "js", "SKIP", "node не найден в PATH — проверка пропущена"
        except (OSError, subprocess.TimeoutExpired) as exc:
            return "js", "FAIL", f"node: {exc}"
        if proc.returncode == 0:
            return "js", "PASS", ""
        err = (proc.stderr or proc.stdout).decode("utf-8", "replace").strip()
        last = err.splitlines()[-1] if err else "node --check: ошибка"
        if "Unexpected token 'export'" in err or '"type": "module"' in err:
            # Ближайший package.json (например, в каталоге распаковки C:\tmp)
            # принуждает парсить .js как CJS; по месту установки (C:\Users\<U>)
            # package.json нет — detect-module парсит ESM-микс корректно.
            return "js", "SKIP", \
                "ESM-синтаксис: парсинг зависит от ближайшего package.json — " \
                "окончательная проверка в apply-режиме по месту установки"
        return "js", "FAIL", last
    return None, "PASS", ""


def verify_files(items: list[tuple[Path, str]]) -> tuple[list[str], int]:
    """Проверка файлов: существует, не пуст, валиден по формату.
    Возвращает (строки сводки, число FAIL)."""
    lines: list[str] = []
    failures = 0
    agg: dict[str, list[int]] = {"json": [0, 0, 0], "toml": [0, 0, 0], "yaml": [0, 0, 0], "js": [0, 0, 0]}
    skip_notes: dict[str, str] = {}
    total = exist_ok = nonempty = 0
    fail_rows: list[str] = []
    for path, rel in items:
        total += 1
        try:
            size = path.stat().st_size
        except OSError as exc:
            fail_rows.append(f"  FAIL  {rel}: недоступен ({exc})")
            failures += 1
            continue
        exist_ok += 1
        if size == 0:
            fail_rows.append(f"  FAIL  {rel}: файл пуст")
            failures += 1
            continue
        nonempty += 1
        kind, status, note = validate_one(path, rel)
        if kind is None:
            continue
        idx = {"PASS": 0, "FAIL": 1, "SKIP": 2}[status]
        agg[kind][idx] += 1
        if status == "FAIL":
            fail_rows.append(f"  FAIL  {rel}: {note}")
            failures += 1
        elif status == "SKIP":
            skip_notes[kind] = note
    lines.append(f"  всего: {total}; существует: {exist_ok}; непустых: {nonempty}")
    for kind, label in (
        ("json", "json"),
        ("toml", "toml"),
        ("yaml", "yaml"),
        ("js", "hooks js (node --check)"),
    ):
        passed, failed, skipped = agg[kind]
        if passed + failed + skipped == 0:
            continue
        if failed:
            lines.append(f"  {label}: {passed}/{passed + failed + skipped} PASS, {failed} FAIL")
        elif skipped:
            lines.append(f"  {label}: {passed}/{passed + skipped} PASS, {skipped} SKIP ({skip_notes.get(kind, '')})")
        else:
            lines.append(f"  {label}: {passed}/{passed} PASS")
    lines.extend(fail_rows)
    return lines, failures


def _count_skill_dirs(root: Path) -> int:
    """Число подпапок, содержащих SKILL.md."""
    if not root.is_dir():
        return 0
    return sum(1 for d in root.iterdir() if d.is_dir() and (d / "SKILL.md").is_file())


def _count_files(root: Path, ext: str) -> int:
    if not root.is_dir():
        return 0
    return sum(1 for f in root.iterdir() if f.is_file() and f.suffix.lower() == ext)


def _counter_value(path: Path, method: str) -> int:
    if method == "skill_dirs":
        return _count_skill_dirs(path)
    if method == "js_files":
        return _count_files(path, ".js")
    return _count_files(path, ".md")


def verify_counters(base: Path, paths: dict[str, Path]) -> tuple[list[str], int]:
    """Сверка счётчиков по ожиданиям COUNTER_SPECS. Возвращает (строки, число FAIL)."""
    lines: list[str] = []
    failures = 0
    for label, _staging_rel, _home_rel, lo, hi, method in COUNTER_SPECS:
        path = paths[label]
        val = _counter_value(path, method)
        expected = f">={lo}" if hi is None else (str(lo) if lo == hi else f"{lo}-{hi}")
        ok = val >= lo and (hi is None or val <= hi)
        status = "PASS" if ok else "FAIL"
        lines.append(f"  {label:<26} {val:>4}   (ожид. {expected:>6})   {status}")
        if not ok:
            failures += 1
            lines.append(f"      →  путь: {base / path.relative_to(base)}")
            lines.append(f"      →  ожидалось {expected}, найдено {val}")
    return lines, failures


# ---------------------------------------------------------------------------
# Отчёт
# ---------------------------------------------------------------------------

def format_file_rows(rows: list[tuple[str, str, str, str]]) -> list[str]:
    """rows: (статус, архивный путь, целевой путь, примечание)."""
    width = min(max((len(r[1]) for r in rows), default=0), 60)
    out: list[str] = []
    for status, rel, dst, note in rows:
        line = f"  [{status:<4}] {rel:<{width}}  ->  {dst}"
        if note:
            line += f"   ({note})"
        out.append(line)
    return out


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def parse_args(argv: list[str] | None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        prog="setup.py",
        description=(
            "omp-setup 1.0 — главный установщик Oh My Pi для новой Windows-машины: "
            "раскладка распакованного архива в профиль пользователя."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "Раскладка:\n"
            "  CLAUDE.md, CLAUDE.neutral.md, skills/, jujutsu-skills/  ->  <home>\\.claude\\\n"
            "  omp/...                                                  ->  <home>\\.omp\\agent\\\n"
            "  omp/marketplaces.json                                    ->  <home>\\.omp\\\n"
            "Механики:\n"
            "  * подстановка __USERNAME__ -> имя пользователя (<home>-имя или %USERNAME%)\n"
            "    выполняется байтово при копировании; архив не изменяется;\n"
            "    исключения: INSTALL.md, skills/transferring-omp-setup/SKILL.md;\n"
            "  * существующие файлы перед заменой копируются в бэкап\n"
            "    <home>\\omp-setup-backup-<ГГГГММДД>\\;\n"
            "  * extensions/tokentracker-notify.ts не перезаписывается при наличии маркера\n"
            "    '// @tokentracker-managed-omp-extension';\n"
            "  * верификация: наличие/непустота, json/toml/yaml-разбор, node --check\n"
            "    для hooks/*.js, счётчики skills (53±2), jujutsu-skills (1-4; донор: 1),\n"
            "    agent/skills (44±2), managed-skills (>=3), hooks/pre (4), agents (9).\n"
            "Выход: 0 — все обязательные проверки PASS; 1 — есть FAIL."
        ),
    )
    parser.add_argument(
        "--staging", metavar="DIR", default=None,
        help="корень распакованного архива (по умолчанию: папка, содержащая install/setup.py)",
    )
    parser.add_argument(
        "--home", metavar="DIR", default=None,
        help="целевой профиль пользователя (по умолчанию: C:\\Users\\<USERNAME>)",
    )
    parser.add_argument(
        "--check", action="store_true",
        help="только план + проверка: ничего не копировать и не менять (exit 0/1)",
    )
    parser.add_argument(
        "--apply", action="store_true",
        help="выполнить установку (режим по умолчанию, если не задан --check)",
    )
    parser.add_argument(
        "--skip-backup", action="store_true",
        help="не создавать бэкап существующих файлов",
    )
    return parser.parse_args(argv)


def resolve_staging(arg: str | None) -> Path:
    if arg:
        return Path(os.path.expandvars(arg)).expanduser()
    here = Path(__file__).resolve()
    candidate = here.parent.parent  # папка, содержащая install/setup.py
    if (candidate / "CLAUDE.md").is_file() or (candidate / "skills").is_dir():
        return candidate
    return here.parent  # фоллбэк: каталог самого скрипта


# ---------------------------------------------------------------------------
# main
# ---------------------------------------------------------------------------

def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv)
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

    staging = resolve_staging(args.staging)
    home = Path(os.path.expandvars(args.home)).expanduser().resolve()
    username = home.name or os.environ.get("USERNAME") or "user"
    mode = "check" if args.check else "apply"

    lines: list[str] = []
    add = lines.append
    failures: list[str] = []
    failed: set[str] = set()  # archive_rel с ошибками копирования (apply)

    add("=" * 74)
    add(f" {VERSION} — установка конфигурации Oh My Pi на новый компьютер")
    add("=" * 74)
    add(f"Дата:        {datetime.now():%Y-%m-%d %H:%M:%S}")
    add(f"Режим:       {'PLAN (--check): ничего не меняется' if mode == 'check' else 'INSTALL (--apply)'}")
    add(f"Staging:     {staging}")
    add(f"Профиль:     {home}")
    add(f"Подстановка: __USERNAME__ -> {username}")
    add(f"Исключения:  {', '.join(SUBST_EXCLUDE)}")
    add("")

    # ---- план -------------------------------------------------------------
    if not staging.is_dir():
        plan: list[PlanEntry] = []
    else:
        plan = build_plan(staging, home)
    present = [e for e in plan if not e.missing]
    missing = [e for e in plan if e.missing]

    add("[ФАЙЛЫ — ПЛАН]" if mode == "check" else "[ФАЙЛЫ — УСТАНОВКА]")
    if not staging.is_dir():
        add("  staging отсутствует — план пуст (0 файлов).")
    elif not present:
        add("  в архиве нет ни одного файла раскладки — план пуст (0 файлов).")
    else:
        if mode == "check":
            rows = [
                (("=" if e.dst.exists() else "+"), e.archive_rel, str(e.dst),
                 ("заменит существующий" if e.dst.exists() else "новый"))
                for e in present
            ] + [("!", e.archive_rel, str(e.dst), "нет в архиве — пропуск") for e in missing]
            add(f"  План: {len(present)} файлов; заменят существующие: "
                f"{sum(1 for e in present if e.dst.exists())}; нет в архиве: {len(missing)}")
            add("")
            add("\n".join(format_file_rows(rows)))
        else:
            stats = Stats()
            backup_dir, guarded = do_backup_pass(present, home, args.skip_backup, stats, failures)
            failed, replaced = do_copy_pass(present, username, guarded, stats)
            rows = []
            for e in plan:
                if e.missing:
                    rows.append(("!", e.archive_rel, str(e.dst), "нет в архиве — пропуск"))
                elif e.archive_rel in guarded:
                    rows.append(("-", e.archive_rel, str(e.dst), f"не перезаписан ({guarded[e.archive_rel]})"))
                elif e.archive_rel in failed:
                    rows.append(("E", e.archive_rel, str(e.dst), "ошибка копирования"))
                else:
                    rows.append(("+", e.archive_rel, str(e.dst),
                                 "заменён" if e.archive_rel in replaced else "новый"))
            add(f"  Скопировано: {stats.copied}; заменено существующих: {stats.replaced}; "
                f"пропущено (маркер): {stats.skipped}; ошибок копирования: {stats.errors}")
            if stats.backed_up:
                add(f"  Бэкап: {stats.backed_up} файлов -> {backup_dir}")
            elif backup_dir is None and not args.skip_backup and stats.backup_errors == 0:
                add("  Бэкап не требуется (существующих файлов не было).")
            if stats.backup_errors:
                add(f"  Ошибок бэкапа: {stats.backup_errors} (см. FAIL ниже)")
            add("")
            add("\n".join(format_file_rows(rows)))
    add("")

    # ---- верификация файлов ------------------------------------------------
    add("[ПРОВЕРКА ФАЙЛОВ]")
    n_file_fail = 0
    if not present:
        add("  проверять нечего — PASS (пусто).")
    else:
        items = [(e.src, e.archive_rel) for e in present] if mode == "check" else \
                [(e.dst, e.archive_rel) for e in present if not e.missing]
        check_lines, n_file_fail = verify_files(items)
        add("\n".join(check_lines))
    add("")

    # ---- счётчики -----------------------------------------------------------
    add("[СЧЁТЧИКИ]")
    n_counter_fail = 0
    if not present:
        add(f"  {'staging пуст' if mode == 'check' else 'профиль пуст'} — счётчики не вычисляются (PASS).")
    else:
        base = staging if mode == "check" else home
        paths: dict[str, Path] = {}
        for label, staging_rel, home_rel, _lo, _hi, _method in COUNTER_SPECS:
            paths[label] = base / (staging_rel if mode == "check" else home_rel)
        counter_lines, n_counter_fail = verify_counters(base, paths)
        add(f"  источник: {'staging (план)' if mode == 'check' else 'профиль (установлено)'}")
        add("\n".join(counter_lines))
        if n_counter_fail:
            add(f"  FAIL: {n_counter_fail} счётчик(а) вне ожидаемого диапазона")
    add("")

    # ---- итог ---------------------------------------------------------------
    # ошибки: копирование (failed) + бэкап (failures) + проверка файлов + счётчики
    total_fail = len(failed) + len(failures) + n_file_fail + n_counter_fail
    if total_fail == 0:
        add("ИТОГ: PASS — 0 ошибок")
        rc = 0
    else:
        add(f"ИТОГ: FAIL — {total_fail} ошибок")
        rc = 1

    if mode == "apply":
        report_path = home / "omp-setup-install-report.txt"
        try:
            home.mkdir(parents=True, exist_ok=True)
            report_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
            add("")
            add(f"Отчёт сохранён: {report_path}")
        except OSError as exc:
            add(f"  Ошибка сохранения отчёта: {exc}")
            rc = 1

    print("\n".join(lines))
    return rc


if __name__ == "__main__":
    sys.exit(main())