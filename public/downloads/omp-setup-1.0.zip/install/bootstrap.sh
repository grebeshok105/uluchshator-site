#!/usr/bin/env bash
# omp-setup 1.0 — bootstrap.sh
# Предусловия (node/python/git/uv/omp) и запуск плана установки:
#     python install/setup.py --check
#
# Запуск из распакованного архива (рядом с папкой install/):
#     bash bootstrap.sh        (или: sh bootstrap.sh)
#
# Выходной код: 0 — план готов; 1 — python не найден;
#               иначе — код возврата setup.py --check.
#
# Bash-версия: python3 предпочтительнее, python — запасной вариант;
# для поиска бинарей используются POSIX-проверки command -v.

set -u

self="${BASH_SOURCE[0]:-$0}"
root="$(cd "$(dirname "$self")/.." && pwd)"
home="${HOME:-${USERPROFILE:-}}"

echo ''
echo 'omp-setup 1.0 — проверка предусловий'

python_cmd=""
for c in python3 python; do
    if command -v "$c" >/dev/null 2>&1; then
        python_cmd="$c"
        printf 'PASS  %-6s %s\n' "$c" "$("$c" --version 2>/dev/null | head -n 1)"
        break
    fi
done

if [ -z "$python_cmd" ]; then
    printf 'MISS  python  не найден в PATH (ни python3, ни python)\n'
    echo 'ОШИБКА: python не найден. Установите Python 3.11+ и добавьте его в PATH.' >&2
    echo 'Затем запустите bootstrap.sh снова.' >&2
    exit 1
fi

for c in node git uv omp; do
    if command -v "$c" >/dev/null 2>&1; then
        printf 'PASS  %-6s %s\n' "$c" "$("$c" --version 2>/dev/null | head -n 1)"
    else
        printf 'MISS  %-6s не найден в PATH\n' "$c"
    fi
done

echo ''
echo "Установщик: python \"$root/install/setup.py\" --check --home \"$home\""

"$python_cmd" "$root/install/setup.py" --check --home "$home"
code=$?

echo ''
echo 'Подсказка: если план ОК — запусти: python install/setup.py --apply, затем python install/doctor.py'
echo '          doctor.py проверяет установку и завершается с кодом 0 при отсутствии FAIL.'

exit "$code"