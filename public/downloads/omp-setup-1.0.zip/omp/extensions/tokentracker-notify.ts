// @tokentracker-managed-omp-extension
// TokenTracker notify bridge for oh-my-pi (omp).
// Passive session scanning still works without this file; the extension only
// makes local dashboard refresh near-real-time after each agent turn.
// Managed by TokenTracker init/uninstall — do not hand-edit the marker line.

const { spawn } = require("node:child_process");
const fs = require("node:fs");
const os = require("node:os");
const path = require("node:path");

const SOURCE = "omp";
const MIN_INTERVAL_MS = 12_000;
const MANAGED_NOTIFY = "C:\\Users\\__USERNAME__\\.tokentracker\\bin\\notify.cjs";

let lastSpawnAt = 0;
let pendingTimer = null;
let warnedMissing = false;

function resolveNotifyPath() {
  const candidates = [];
  if (process.env.TOKENTRACKER_NOTIFY) candidates.push(process.env.TOKENTRACKER_NOTIFY);
  if (MANAGED_NOTIFY) candidates.push(MANAGED_NOTIFY);
  candidates.push(path.join(os.homedir(), ".tokentracker", "bin", "notify.cjs"));
  for (const candidate of candidates) {
    try {
      if (candidate && fs.existsSync(candidate)) return candidate;
    } catch (_) {}
  }
  return null;
}

function spawnNotify() {
  const notifyPath = resolveNotifyPath();
  if (!notifyPath) {
    if (!warnedMissing) {
      warnedMissing = true;
      console.warn(
        "[tokentracker-notify] notify.cjs not found; expected ~/.tokentracker/bin/notify.cjs",
      );
    }
    return;
  }

  const now = Date.now();
  if (now - lastSpawnAt < MIN_INTERVAL_MS) {
    if (pendingTimer == null) {
      const wait = Math.max(MIN_INTERVAL_MS - (now - lastSpawnAt), 50);
      pendingTimer = setTimeout(() => {
        pendingTimer = null;
        spawnNotify();
      }, wait);
      if (typeof pendingTimer.unref === "function") pendingTimer.unref();
    }
    return;
  }
  lastSpawnAt = now;
  if (pendingTimer != null) {
    clearTimeout(pendingTimer);
    pendingTimer = null;
  }

  try {
    const child = spawn(process.execPath, [notifyPath, "--source=" + SOURCE], {
      detached: true,
      stdio: "ignore",
      env: process.env,
    });
    child.unref();
  } catch (err) {
    if (!warnedMissing) {
      warnedMissing = true;
      console.warn(
        "[tokentracker-notify] failed to spawn notify:",
        err && err.message ? err.message : String(err),
      );
    }
  }
}

export default function (pi) {
  pi.on("turn_end", () => {
    spawnNotify();
  });

  pi.on("agent_end", () => {
    spawnNotify();
  });

  pi.on("session_shutdown", () => {
    lastSpawnAt = 0;
    if (pendingTimer != null) {
      clearTimeout(pendingTimer);
      pendingTimer = null;
    }
    spawnNotify();
  });
}
