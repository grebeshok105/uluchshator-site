---
name: fabric-mcp-agent-bridge
description: "Use when wiring agent/MCP control into a Fabric Minecraft mod: porting the upstream minecraft-java-fabric-mcp-server, adding a dev-only companion tool mod via the ToolProvider seam, autonomous world entry (quickPlay), release-jar isolation, and the known 1.21.x traps (Jackson parent-first, SSE hold-open, closed category map)."
---

# Fabric MCP Agent Bridge

Proven end-to-end on jujutsu-minecraft (MC 1.21.8, Loom 1.17.17, issue #43; PRs #62/#63). Live reference: worktree `D:/WorkFlow/Jujutsu Minecraft/.worktrees/mcp-port-spike`, upstream fork `D:/WorkFlow/mcp-spike-scratch/upstream` (branch `mc-1.21.8-target`).

## Architecture (3 pieces, zero upstream edits for your mod)

1. **Upstream MCP server mod**: `chapmanjw/minecraft-java-fabric-mcp-server` — HTTP/SSE JSON-RPC on `127.0.0.1:8765` (server tools, bearer auth) + `8766` (client tools incl. `view_capture`; NO provider seam — fixed list). ~105 vanilla tools: summon/give/teleport/setblock/query/screenshot.
2. **Dev-only companion mod** in your repo (separate source set, e.g. `src/mcpdev`): a Fabric mod with two entrypoints — `main` → bridge class holding `MinecraftServer` via SERVER_STARTING/STOPPED (upstream adapter exposes NO public server accessor), and `mcp-tools` → `ToolProvider` implementation returning tool classes AND `domainCategories()` mapping your domain prefix (e.g. `jujutsu` → SERVER). **The category map is CLOSED: an undeclared domain hard-rejects every tool.**
3. **Gradle gating**: companion dormant without `-PmcpUpstreamJar=<jar>` (compileOnly + onlyIf); run knob `-PmcpSpike` adds upstream jar as `modLocalRuntime` + companion as `localRuntime`. Release-jar audit task scans the production jar for forbidden prefixes (`com/chapmanjw/`, `io/modelcontextprotocol/`, your companion package, `mcp-tools` entrypoint in fabric.mod.json) — red-prove it.

## Tool authoring (upstream idioms)

- Tool = stateless class `extends BaseTool` + `@McpTool(name = "domain_verb", description, readOnly)`; schema via `Schemas.object().required(...)` DSL; args via `reader(arguments)`.
- **Validation on the HTTP thread, game access inside `onMainThread(context, fn)`** — it blocks on `submitBlocking(server::execute)` and REWRAPS every inner exception into `TOOL_HANDLER_ERROR`, so `TOOL_INPUT_INVALID`/`SERVER_NOT_RUNNING` must be thrown in `execute()` BEFORE the hop (check the bridge's volatile server field there).
- Players addressed by UUID only (`getPlayerList().getPlayer(uuid)`). Dev clients are offline-mode: UUID = md5 name-UUID of `OfflinePlayer:<name>` (uuid v3 shape).
- Derive enum-name lists in schemas/errors from `Enum.values()`, never hand-list.
- Invoke gameplay through the mod's real production entry (the method its network receiver calls), never a parallel path; expose small public wipe/query accessors on existing runtime classes for fixture reset (never new packages — the audit bans them).
- Fixture-reset tools: fixed step order, each step catches `Throwable` and records per-step outcome; never touch selection/inventory; map any teardown-reason enums to no-cooldown.

## Autonomous world entry (no human hands)

- Vanilla CLI: `--quickPlaySingleplayer <saves-folder-name>` on the Loom `client` run config (`loom.runs.named('client') { programArgs ... }`). Folder name = identifier; **a missing world is NOT created** (DisconnectedScreen) — pre-seed by copying any existing save folder.
- Pre-seed `run/options.txt`: `pauseOnLostFocus:false` (else every unfocused screenshot shows the pause menu; gate is a raw Options field read in GameRenderer), `tutorialStep:none`.
- Make an idempotent gradle task doing both, wired `runClient dependsOn` it, inside the same property gate.
- MCP server binds on world load → readiness = TCP 8765 + log line `listening at http://127.0.0.1:8765`.

## Known traps (each cost real debugging)

1. **MC 1.21.x ships Jackson 2.13 parent-first** (Knot classloader): a newer bundled Jackson is shadowed for `com.fasterxml.*` — `JsonNode.properties()` (2.14+) crashes at runtime while scalars work. Use `fields()`-era APIs or shade with renamed packages.
2. **SSE hold-open**: HTTP sinks that close the stream after first flush cause reconnect storms; the exchange must stay open on a dedicated thread with heartbeats, bounded by a semaphore cap (503 on excess), slots released on disconnect.
3. Closed category map (above) — declare `domainCategories()`.
4. `tools/list` skips: version/module constraints in `@McpTool` silently skip tools — check the registration log count.
5. Windows/MSYS `curl -d` to these endpoints can send empty bodies — use python urllib for probes.
6. npm-shim CLIs (omp etc.) fail under bash on Windows (`batch file arguments are invalid`) — run `bun <global npm dir>/node_modules/<pkg>/dist/cli.js` directly.

## Verification ladder

1. Unit gate (your normal test suite) for production-side accessors.
2. Companion compile proof: `jar<Companion> -PmcpUpstreamJar=...` (your gate likely never compiles the dev source set — say so honestly).
3. Live proof, zero manual input: launch → auto-world → `tools/list` count → select/invoke/observe/reset protocol → `view_capture` (verify the PNG yourself) → clean shutdown, ports released.
4. Red-prove the release-jar audit (inject a fake forbidden entry → audit must fail).
