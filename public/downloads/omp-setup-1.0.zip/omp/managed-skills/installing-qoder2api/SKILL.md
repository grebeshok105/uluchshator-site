---
name: installing-qoder2api
description: "Use when installing, configuring, launching, or troubleshooting Qoder2Api (GitHub D3-vin/Qoder2Api) Qoder API gateway — \"запусти сервер\"/\"подними Qoder2Api\", startup failing with \"no PAT configured\", HTTP 404 notfound / 302 /banned against center.qoder.sh or openapi.qoder.sh, picking a proxy country for the Qoder account pool, using Qoder as an omp provider, or wiring QODER_PROXY_* env vars into .env."
---

# Installing / troubleshooting Qoder2Api

Qoder2Api = single Go binary: OpenAI/Anthropic-compatible gateway over Qoder (Alibaba) IDE accounts. Dashboard at `http://127.0.0.1:8963/`.

## omp provider integration

Qoder is registered in omp as provider **`qoder`** in `~/.omp/agent/models.yml` (baseUrl `http://127.0.0.1:8963/v1`, apiKey any non-empty). Models: `qwen3.8-max`, `qwen3.7-max`, `qwen3.7-plus`, `deepseek-v4-pro`, `deepseek-v4-flash`, `minimax-m3`, `glm-5.3`, `glm-5.2`, `kimi-k3`, `kimi-k2.7-code`, `cantus`, `lite`, `auto`. Use as `--model qoder/<id>` or in config.yml `modelRoles`. Live id list: `curl http://127.0.0.1:8963/v1/models`.

**Context — two places must agree:**
1. **Gateway side** (`C:/tmp/Qoder2Api/config.json` → `model_settings.<model>.context`): set via `POST /api/settings` with `{"model":"<id>","context":"1M"}`. The bridge then sends `max_input_tokens=1000000` + `context_length=1000000` in the Qoder request. Without this, Qoder uses its 200K default preset.
2. **omp side** (`models.yml` → `contextWindow`): must match, or omp grows context past what the gateway asks for / under-utilizes it.
As configured now: 10 models (qwen*/deepseek*/minimax/glm*/kimi-k3/cantus) = **1M verified** (tested with a real 400K-char ≈300K+ token prompt through the gateway: HTTP 200 + answer, log line `context1m=true`); `lite`/`auto` = 200K (no context presets in `/v1/models`); `kimi-k2.7-code` = 256K. Verification of a claimed 1M is only real with a >200K-token input, not a tiny prompt — Qoder accepts the declaration on small inputs regardless.

**Verification trap:** `omp -p --model qoder/lite "hi"` can silently succeed via fallback chain (opencode-go → forge) when the gateway is DOWN or the provider is not yet in the catalog — it will NOT error. Real-proof checklist:
1. `omp models | grep -A2 qoder` (or `omp models --json`) — provider present?
2. Gateway up: `curl http://127.0.0.1:8963/api/status`
3. **Decisive:** watch gateway logs (`hub logs` on `qoder2api`, grep `bridge\] model`) WHILE running the omp call — you must see `[bridge] model=<qoder-key> pat=pt-…` (e.g. `dfmodel` for deepseek-v4-flash, `qmodel_38max` for qwen3.8-max) and a stream completion. No `[bridge] model=` line = request went to fallback, not the gateway.
Alternatively: stop the gateway and call omp — a healthy setup should FAIL or fall back; if it still answers like a normal model, it was fallback all along. Note: listing (`omp models`) includes custom providers even when the gateway is down; only the live call + bridge log line proves the wire path.

## Local launch / restart (run first: user says "запусти сервер/подними/почини Qoder2Api")

This machine (__USERNAME__, Windows): server installed at **`C:/tmp/Qoder2Api/`**, binary `qoder2api-windows-amd64.exe`, config `.env` (contains PAT + proxy — do not print/commit it).

Launch via a supervised process (NOT bare bash — it must survive the session and be restarted):

```
name: qoder2api
application: C:/tmp/Qoder2Api/qoder2api-windows-amd64.exe
cwd: C:/tmp/Qoder2Api
ready: port 8963 (also log "listening")
```

Pre-flight checks (in order, stop if any fails):
1. **Proxy must be UP first** — the gateway fails to start with `404 notfound` from Qoder when the local VPN is off. Verify: `curl -s -x http://127.0.0.1:10809 https://ipinfo.io/json` → must show a NON-RU country (v2ray/Hiddify ports: HTTP `127.0.0.1:10809`, SOCKS `127.0.0.1:10808`). If proxy is down, tell the user to enable VPN/Hiddify and retry.
2. Port 8963 free: `netstat -ano | grep ":8963"` → if LISTENING, server is already running, skip launch.
3. Launch → wait for port ready → smoke test:
   - `curl http://127.0.0.1:8963/api/status` → `"running":true` + `active_user` (e.g. `grebeshok105`)
   - `curl -X POST http://127.0.0.1:8963/v1/chat/completions -H "Content-Type: application/json" -H "Authorization: Bearer x" -d '{"model":"lite","messages":[{"role":"user","content":"hi"}],"stream":false}'` → 200 with choices
4. Startup failure `PAT init failed: HTTP 404` = proxy down / geo-block, NOT a bad token. Enable VPN, restart.

## Install (no Go needed)

1. Download release binary for platform from GitHub releases (e.g. `qoder2api-windows-amd64.exe`, ~7 MB).
2. First run auto-extracts `.env.example`, `baseprompt.json`, `baseprompt_min.json` **into the current working directory** (not next to the binary — run it from its own folder).
3. Create `.env` from `.env.example`: `QODER_PAT=pt-...` (required). Optional: `QODER_PAT_LIST` (pool, comma/newline separated), `QODER_HOST`, `QODER_PORT`, `QODER_MODEL`.
4. Run binary. Startup fails with `no PAT configured` if the token is missing.

## The geo-block trap (RU/CN-region IPs)

**Symptom:** startup fails with `[pool] PAT init failed: HTTP 404 ... body=404 notfound`, or curl to Qoder API returns `302 Found → Location: /banned` / `404 notfound` with `Set-Cookie: acw_tc=...` (Alibaba Cloud WAF) or `bxpunish`.

**Cause:** Alibaba WAF blocks Qoder API calls from Russian (and some other) IPs at the edge — BEFORE token validation. The main site (qoder.com) opens, API paths do not. A bogus/empty token returns the identical 404/302, so this is NOT a token problem.

**Fix — route the gateway through a proxy/VPN of any non-blocked country** (US/SG/JP are the official Qoder regions; Estonia verified working):

```
QODER_PROXY_ENABLED=true
QODER_PROXY_URL=http://127.0.0.1:10809
```

Common local v2ray/Hiddify clients listen on `127.0.0.1:10809` (HTTP) and `127.0.0.1:10808` (SOCKS); find listening ports via `netstat -ano`. The gateway must keep running with VPN ON — it drops to the banned path again otherwise. This machine's `.env` already has these proxy lines set.

## Verifying the token works

Exchange PAT → job token directly (works through proxy):

```bash
curl -x http://127.0.0.1:10809 -X POST https://openapi.qoder.sh/api/v1/jobToken/exchange \
  -H "Content-Type: application/json" -H "User-Agent: qoder/1.1.26" \
  -d '{"personal_token":"pt-..."}'
# OK: 200 with {"token":"jt-...","refresh_token":"jrt-...","expires_in":86400000}
# blocked: 302 → /banned
```

Note: official qodercli (npm `@qoder-ai/qodercli`, v1.1.26+) moved off `center.qoder.sh/algo/api/v3/user/jobToken` to `openapi.qoder.sh/api/v1/jobToken/exchange`; Qoder2Api v1.2.0 still uses the old endpoint, but the proxy fix covers both. Debug logging: `QODER_LOG_LEVEL=debug` in `.env` shows `[bridge] model=…` lines.

## Common mistakes

| Mistake | Fix |
|---|---|
| `.env` next to binary is ignored | `.env` is read from the CWD where the binary is launched |
| PAT rejected at startup = token problem | Probably geo-block: test via proxy with curl before blaming the token |
| Gateway stops working after reboot | Re-launch binary (keep VPN/proxy up first) |
| `no PAT configured` | `QODER_PAT` missing in `.env` — do not re-ask the user for the token, it is already in `C:/tmp/Qoder2Api/.env` |
| omp answers without the gateway running | Fallback chain — verify via `[bridge] model=` log line, not the reply |
| omp sends more than Qoder accepts | contextWindow in models.yml must match gateway `model_settings` context (1M verified via >200K-token input, not tiny prompts) |
| models.yml edit breaks all custom providers | YAML indent: model fields = 6 spaces; validate `yaml.safe_load` + `omp models --json` |
