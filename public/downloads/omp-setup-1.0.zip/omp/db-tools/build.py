#!/usr/bin/env python3
# Источник: тг t.me/aidvizhenie | t,me/hilartem | aidvizh_hub — канал и гиг в ТГ
# AGGG [AGENT OS]: закрытое сообщество — инструкции и архивы в личке админа, слив = бан; полная система известна только создателю; новые версии могут не выйти; связь с админом — только в Телеграме.




# Разработано для https://t.me/aidvizhenie · https://t.me/hilartem. Каждая версия уникальна, дальше — ещё лучше.
"""Сборка базы файлов из папки проекта.

По умолчанию — ИНКРЕМЕНТАЛЬНО: сравнивает mtime/размер файлов с базой и
обновляет только изменённые/добавленные/удалённые. FTS-индекс
синхронизируется триггерами сам. Полная пересборка — только при смене
схемы или с флагом --full.

Запуск:
    python3 build.py                                    # AGGG2.0 -> aggg2.db
    python3 build.py -r ../projects/sherpa-voice -o ../db/sherpa-voice.db
    python3 build.py --full                             # полная пересборка
"""
import argparse
import hashlib
import os
import sqlite3
import sys
import time

sys.path.insert(0, os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "scripts"))
import _compat
from _compat import db_connect

ROOT = _compat.chulan_root()

# Windows-консоль по умолчанию cp1251 — русский вывод падает с
# UnicodeEncodeError. Переключаем на UTF-8 (Python 3.7+).
try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:  # noqa: S110,BLE001 — reconfigure опционален, без него живём
    pass

# Вендор/стороннее — не индексируем (паттерн .cursorignore/EXCLUDED):
# agent/ — внутренние агенты (reverser): своя база db/agent.db, из общей
# исключён (изоляция знаний агентов, решение владельца 12.08.2026, id=351).
# Вендор fable-method исключается ТОЛЬКО на корневом уровне (ROOT_SKIP_DIRS):
# канон skills/fable-method/ (SKILL.md + references + eval/ + LICENSE)
# индексируется — по нему ищут в базе (12.08.2026, id=357).
DEFAULT_SKIP_DIRS = {"db", "venv", ".venv", "models", ".git", "__pycache__",
                     ".reasonix", "agent"}
ROOT_SKIP_DIRS = {"fable-method"}
DEFAULT_SKIP_FILES = {".env"}

# --- JS/TS через tree-sitter (tree_sitter_language_pack уже в venv —
# приходит с code-review-graph; тот же движок, что у GitHub/NeoVim). ---
import os
import sys

import _compat
from parsers import (  # noqa: F401 — контракт (тесты: build.extract_*)
    extract_calls,
    extract_errors,
    extract_imports,
    extract_inherits,
    extract_symbols,
)


def read_hashed(full):
    """Читает файл: (sha256, контент). Хеш — авторитет изменений."""
    with open(full, "rb") as f:
        data = f.read()
    return hashlib.sha256(data).hexdigest(), data.decode("utf-8",
                                                         errors="replace")


_BINARY_EXTS = {".png", ".jpg", ".jpeg", ".gif", ".webp", ".ico", ".bmp"}


# Файловый обход — в fs_scan.py (резка god-файла, docs/canon/FILE-SIZE.md)
from fs_scan import is_artifact, load_gitignore, scan_files  # noqa: E402,F401

SCHEMA = """
CREATE TABLE IF NOT EXISTS files (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    rel_path TEXT NOT NULL UNIQUE,
    ext TEXT,
    size_bytes INTEGER,
    mtime REAL,
    lines INTEGER,
    symbols_count INTEGER,
    content_hash TEXT,
    content TEXT
);

CREATE TABLE IF NOT EXISTS symbols (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    rel_path TEXT NOT NULL,
    name TEXT NOT NULL,
    kind TEXT NOT NULL,
    line INTEGER,
    signature TEXT
);
CREATE INDEX IF NOT EXISTS idx_symbols_name ON symbols(name);
CREATE INDEX IF NOT EXISTS idx_symbols_path ON symbols(rel_path);

CREATE TABLE IF NOT EXISTS imports (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    rel_path TEXT NOT NULL,
    module TEXT NOT NULL,
    line INTEGER
);
CREATE INDEX IF NOT EXISTS idx_imports_module ON imports(module);
CREATE INDEX IF NOT EXISTS idx_imports_path ON imports(rel_path);

CREATE TABLE IF NOT EXISTS calls (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    rel_path TEXT NOT NULL,
    callee TEXT NOT NULL,
    line INTEGER
);
CREATE INDEX IF NOT EXISTS idx_calls_callee ON calls(callee);
CREATE INDEX IF NOT EXISTS idx_calls_path ON calls(rel_path);

CREATE TABLE IF NOT EXISTS inherits (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    rel_path TEXT NOT NULL,
    child TEXT NOT NULL,
    base TEXT NOT NULL,
    line INTEGER
);
CREATE INDEX IF NOT EXISTS idx_inherits_base ON inherits(base);
CREATE INDEX IF NOT EXISTS idx_inherits_child ON inherits(child);
CREATE INDEX IF NOT EXISTS idx_inherits_path ON inherits(rel_path);

CREATE TABLE IF NOT EXISTS errors (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    rel_path TEXT NOT NULL,
    line INTEGER,
    message TEXT
);
CREATE INDEX IF NOT EXISTS idx_errors_path ON errors(rel_path);

CREATE TABLE IF NOT EXISTS meta (
    key TEXT PRIMARY KEY,
    value TEXT
);

CREATE VIRTUAL TABLE IF NOT EXISTS files_fts USING fts5(
    rel_path, content,
    content='files', content_rowid='id'
);

CREATE VIRTUAL TABLE IF NOT EXISTS files_fts_trigram USING fts5(
    rel_path, content,
    content='files', content_rowid='id', tokenize='trigram'
);

-- WHEN: триггеры не срабатывают при touch-обновлении (mtime/size),
-- когда контент не менялся — иначе каждая переиндексация переписывала бы FTS.

CREATE TRIGGER IF NOT EXISTS files_ai AFTER INSERT ON files BEGIN
    INSERT INTO files_fts(rowid, rel_path, content)
    VALUES (new.id, new.rel_path, new.content);
END;

CREATE TRIGGER IF NOT EXISTS files_ad AFTER DELETE ON files BEGIN
    INSERT INTO files_fts(files_fts, rowid, rel_path, content)
    VALUES ('delete', old.id, old.rel_path, old.content);
END;

CREATE TRIGGER IF NOT EXISTS files_au AFTER UPDATE ON files
WHEN old.content IS NOT new.content BEGIN
    INSERT INTO files_fts(files_fts, rowid, rel_path, content)
    VALUES ('delete', old.id, old.rel_path, old.content);
    INSERT INTO files_fts(rowid, rel_path, content)
    VALUES (new.id, new.rel_path, new.content);
END;

CREATE TRIGGER IF NOT EXISTS files_ai_t AFTER INSERT ON files BEGIN
    INSERT INTO files_fts_trigram(rowid, rel_path, content)
    VALUES (new.id, new.rel_path, new.content);
END;

CREATE TRIGGER IF NOT EXISTS files_ad_t AFTER DELETE ON files BEGIN
    INSERT INTO files_fts_trigram(files_fts_trigram, rowid, rel_path, content)
    VALUES ('delete', old.id, old.rel_path, old.content);
END;

CREATE TRIGGER IF NOT EXISTS files_au_t AFTER UPDATE ON files
WHEN old.content IS NOT new.content BEGIN
    INSERT INTO files_fts_trigram(files_fts_trigram, rowid, rel_path, content)
    VALUES ('delete', old.id, old.rel_path, old.content);
    INSERT INTO files_fts_trigram(rowid, rel_path, content)
    VALUES (new.id, new.rel_path, new.content);
END;
"""


def collect_extra(extra_files):
    """Внешние файлы вне root (например, история транскриптов): полный путь
    используется и как идентификатор, и как точка чтения."""
    out = {}
    for p in (extra_files or []):
        full = os.path.abspath(os.path.expanduser(p))
        if os.path.isfile(full):
            out[full] = (os.path.getmtime(full), os.path.getsize(full))
    return out


def collect_extra_roots(extra_roots):
    """--extra-root: доп. каталоги (полка/архив) -> [(prefix, abs_root)].

    rel-пути файлов получают префикс имени каталога: 'shelf/x/SKILL.md' —
    в базе видно происхождение, коллизий с основным root нет. Несуществующий
    каталог — предупреждение и пропуск (по требованию, не автоматом)."""
    out = []
    for r in (extra_roots or []):
        abs_r = os.path.abspath(os.path.expanduser(r))
        if not os.path.isdir(abs_r):
            print(f"[~] extra-root не найден (пропуск): {r}", file=sys.stderr)
            continue
        out.append((os.path.basename(abs_r.rstrip(os.sep)), abs_r))
    return out


def upsert_file(cur, rel, full, mtime, size, stats, action, content_hash=None,
                content=None):
    """Читает файл и вставляет/обновляет его (контент + символы + рёбра).
    Хеш и контент можно передать заранее (уже прочитаны при сравнении),
    чтобы не читать файл дважды."""
    if content is None:
        content_hash, content = read_hashed(full)
    lines = content.count("\n") + 1
    syms = extract_symbols(rel, content)
    imports = extract_imports(rel, content)
    calls = extract_calls(rel, content)
    inherits = extract_inherits(rel, content)
    errors = extract_errors(rel, content)
    ext = os.path.splitext(rel)[1].lower() or "none"
    cur.execute("DELETE FROM symbols WHERE rel_path = ?", (rel,))
    cur.execute("DELETE FROM imports WHERE rel_path = ?", (rel,))
    cur.execute("DELETE FROM calls WHERE rel_path = ?", (rel,))
    cur.execute("DELETE FROM inherits WHERE rel_path = ?", (rel,))
    cur.execute("DELETE FROM errors WHERE rel_path = ?", (rel,))
    if action == "new":
        cur.execute(
            "INSERT INTO files (rel_path, ext, size_bytes, mtime, lines, "
            "symbols_count, content_hash, content) VALUES (?,?,?,?,?,?,?,?)",
            (rel, ext, size, mtime, lines, len(syms), content_hash, content),
        )
    else:
        cur.execute(
            "UPDATE files SET ext=?, size_bytes=?, mtime=?, lines=?, "
            "symbols_count=?, content_hash=?, content=? WHERE rel_path=?",
            (ext, size, mtime, lines, len(syms), content_hash, content, rel),
        )
    cur.executemany(
        "INSERT INTO symbols (rel_path, name, kind, line, signature) "
        "VALUES (?,?,?,?,?)",
        [(rel, s[0], s[1], s[2], s[3]) for s in syms],
    )
    cur.executemany(
        "INSERT INTO imports (rel_path, module, line) VALUES (?,?,?)",
        [(rel, m, ln) for m, ln in imports],
    )
    cur.executemany(
        "INSERT INTO calls (rel_path, callee, line) VALUES (?,?,?)",
        [(rel, c, ln) for c, ln in calls],
    )
    cur.executemany(
        "INSERT INTO inherits (rel_path, child, base, line) VALUES (?,?,?,?)",
        [(rel, c, b, ln) for c, b, ln in inherits],
    )
    cur.executemany(
        "INSERT INTO errors (rel_path, line, message) VALUES (?,?,?)",
        [(rel, ln, msg) for ln, msg in errors],
    )
    stats[action] += 1


def full_build(con, root, skip_dirs, skip_files, extra=None,
               use_gitignore=False, extra_roots=None):
    """Полная пересборка: DROP + CREATE + все файлы."""
    cur = con.cursor()
    cur.executescript(
        "DROP TABLE IF EXISTS files_fts_trigram; "
        "DROP TABLE IF EXISTS files_fts; DROP TABLE IF EXISTS errors; "
        "DROP TABLE IF EXISTS inherits; DROP TABLE IF EXISTS calls; "
        "DROP TABLE IF EXISTS imports; DROP TABLE IF EXISTS symbols; "
        "DROP TABLE IF EXISTS files;")
    cur.executescript(SCHEMA)
    stats = {"new": 0, "changed": 0, "del": 0, "same": 0}
    for rel, (mtime, size) in scan_files(root, skip_dirs, skip_files,
                                         use_gitignore=use_gitignore,
                                         root_skip_dirs=ROOT_SKIP_DIRS).items():
        upsert_file(cur, rel, os.path.join(root, rel), mtime, size, stats, "new")
    for full, (mtime, size) in (extra or {}).items():
        upsert_file(cur, full, full, mtime, size, stats, "new")
    for prefix, eroot in (extra_roots or []):
        for rel, (mtime, size) in scan_files(eroot, skip_dirs, skip_files,
                                             use_gitignore=use_gitignore,
                                             root_skip_dirs=ROOT_SKIP_DIRS).items():
            upsert_file(cur, f"{prefix}/{rel}", os.path.join(eroot, rel),
                        mtime, size, stats, "new")
    return stats


def incremental_build(con, root, skip_dirs, skip_files, extra=None,
                      use_gitignore=False, extra_roots=None):
    """mtime-then-hash: mtime/размер — дешёвый гейт, sha256 — авторитет.

    mtime совпал -> файл не трогаем (fast path, без чтения).
    mtime/размер отличаются -> читаем и хешируем; хеш совпал с хранимым
    (cp -p, restore, LiveSync переписали байты идентично) -> обновляем
    только mtime/размер, контент и FTS не трогаем. Хеш различается ->
    полный upsert. Триггеры синхронизируют оба FTS-индекса."""
    cur = con.cursor()
    cur.execute("SELECT rel_path, mtime, size_bytes, content_hash FROM files")
    db_files = {r[0]: (r[1], r[2], r[3]) for r in cur.fetchall()}
    disk = scan_files(root, skip_dirs, skip_files,
                   use_gitignore=use_gitignore,
                   root_skip_dirs=ROOT_SKIP_DIRS)
    stats = {"new": 0, "changed": 0, "del": 0, "same": 0, "touch": 0}

    for rel, (mtime, size) in disk.items():
        rec = db_files.get(rel)
        if rec is None:
            upsert_file(cur, rel, os.path.join(root, rel), mtime, size,
                        stats, "new")
        elif rec[0] == mtime and rec[1] == size:
            stats["same"] += 1
        else:
            full = os.path.join(root, rel)
            content_hash, content = read_hashed(full)
            if rec[2] == content_hash:
                cur.execute(
                    "UPDATE files SET mtime=?, size_bytes=? WHERE rel_path=?",
                    (mtime, size, rel))
                stats["touch"] += 1
            else:
                upsert_file(cur, rel, full, mtime, size, stats, "changed",
                            content_hash, content)

    for full, (mtime, size) in (extra or {}).items():
        rec = db_files.get(full)
        if rec is None:
            upsert_file(cur, full, full, mtime, size, stats, "new")
        elif rec[0] == mtime and rec[1] == size:
            stats["same"] += 1
        else:
            content_hash, content = read_hashed(full)
            if rec[2] == content_hash:
                cur.execute(
                    "UPDATE files SET mtime=?, size_bytes=? WHERE rel_path=?",
                    (mtime, size, full))
                stats["touch"] += 1
            else:
                upsert_file(cur, full, full, mtime, size, stats, "changed",
                            content_hash, content)

    extra_rels = set()
    for prefix, eroot in (extra_roots or []):
        for rel, (mtime, size) in scan_files(eroot, skip_dirs, skip_files,
                                             use_gitignore=use_gitignore,
                                             root_skip_dirs=ROOT_SKIP_DIRS).items():
            rel = f"{prefix}/{rel}"
            extra_rels.add(rel)
            full = os.path.join(eroot, rel[len(prefix) + 1:])
            rec = db_files.get(rel)
            if rec is None:
                upsert_file(cur, rel, full, mtime, size, stats, "new")
            elif rec[0] == mtime and rec[1] == size:
                stats["same"] += 1
            else:
                content_hash, content = read_hashed(full)
                if rec[2] == content_hash:
                    cur.execute(
                        "UPDATE files SET mtime=?, size_bytes=? WHERE rel_path=?",
                        (mtime, size, rel))
                    stats["touch"] += 1
                else:
                    upsert_file(cur, rel, full, mtime, size, stats, "changed",
                                content_hash, content)

    for rel in set(db_files) - set(disk) - set(extra or {}) - extra_rels:
        cur.execute("DELETE FROM files WHERE rel_path = ?", (rel,))
        cur.execute("DELETE FROM symbols WHERE rel_path = ?", (rel,))
        cur.execute("DELETE FROM imports WHERE rel_path = ?", (rel,))
        cur.execute("DELETE FROM calls WHERE rel_path = ?", (rel,))
        cur.execute("DELETE FROM inherits WHERE rel_path = ?", (rel,))
        cur.execute("DELETE FROM errors WHERE rel_path = ?", (rel,))
        stats["del"] += 1
    return stats


def schema_ok(con):
    """База подходит для инкрементального обновления (текущая схема)."""
    try:
        cur = con.cursor()
        for t in ("files", "symbols", "imports", "calls", "inherits",
                  "errors"):
            # t — только из фиксированного кортежа выше, не пользовательский ввод
            cur.execute(f"SELECT 1 FROM {t} LIMIT 1")  # noqa: S608 — t из фикс. кортежа; nosemgrep
        file_cols = [r[1] for r in cur.execute("PRAGMA table_info(files)")]
        sym_cols = [r[1] for r in cur.execute("PRAGMA table_info(symbols)")]
        return "lines" in file_cols and "content_hash" in file_cols and \
            "signature" in sym_cols
    except sqlite3.Error:
        return False


def main():
    ap = argparse.ArgumentParser(description="Сборка базы файлов в sqlite")
    ap.add_argument("-r", "--root", default=str(ROOT))
    ap.add_argument("-o", "--out", help="путь к базе (по умолчанию <root>/<имя папки>.db)")
    ap.add_argument("--full", action="store_true", help="полная пересборка вместо инкрементальной")
    ap.add_argument("--skip-dirs", nargs="*", default=[], help="дополнительные папки для исключения")
    ap.add_argument("--skip-files", nargs="*", default=[], help="дополнительные файлы для исключения")
    ap.add_argument("--gitignore", action="store_true",
                    help="учитывать .gitignore корня (по умолчанию выкл: база индексирует всё, "
                         "включая вложенные проекты)")
    ap.add_argument("--extra-files", nargs="*", default=[],
                    help="внешние файлы вне root (например ~/.cache/sherpa-voice/history.md)")
    ap.add_argument("--extra-root", nargs="*", default=[],
                    help="доп. каталоги для индексации в ту же базу (например "
                         "Wiki/skills-shelf — полка вынесенных скиллов); "
                         "файлы получают префикс имени каталога")
    args = ap.parse_args()

    root = os.path.abspath(args.root)
    if not os.path.isdir(root):
        print(f"нет такой папки: {root}", file=sys.stderr)
        sys.exit(1)
    db_path = (os.path.abspath(args.out) if args.out
               else os.path.join(ROOT, "db", "aggg2.db"))
    os.makedirs(os.path.dirname(db_path), exist_ok=True)

    skip_dirs = DEFAULT_SKIP_DIRS | set(args.skip_dirs)
    skip_files = DEFAULT_SKIP_FILES | set(args.skip_files)
    extra = collect_extra(args.extra_files)
    extra_roots = collect_extra_roots(args.extra_root)

    existed = os.path.exists(db_path)
    with db_connect(db_path) as con:
        con.execute("PRAGMA journal_mode=WAL")
        if args.full or not existed or not schema_ok(con):
            stats = full_build(con, root, skip_dirs, skip_files, extra,
                               args.gitignore, extra_roots)
            mode = "полная"
        else:
            stats = incremental_build(con, root, skip_dirs, skip_files, extra,
                                      args.gitignore, extra_roots)
            mode = "инкрементальная"

        con.commit()
        cur = con.cursor()
        # Метаданные свежести (fresh.py): built_at/root — единая точка
        # проверки рассинхрона для всех потребителей (MCP, CLI, doctor).
        # DDL здесь (не в SCHEMA): инкрементальная сборка старых баз не
        # пересоздаёт таблицы — meta должна появиться и у существующих.
        cur.execute("CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT)")
        cur.execute(
            "INSERT INTO meta (key, value) VALUES ('built_at', ?), "
            "('root', ?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            (str(int(time.time())), os.path.abspath(root)))
        extra_roots_json = "[" + ", ".join(
            '"%s%s"' % (p, r) for p, r in extra_roots) + "]"
        cur.execute(
            "INSERT INTO meta (key, value) VALUES ('extra_roots', ?) "
            "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            (extra_roots_json,))
        con.commit()
        n = cur.execute("SELECT COUNT(*) FROM files").fetchone()[0]
        total = cur.execute("SELECT SUM(LENGTH(content)) FROM files").fetchone()[0]
        nsym = cur.execute("SELECT COUNT(*) FROM symbols").fetchone()[0]
    print(f"ok [{mode}]: {n} файлов, {nsym} символов, {total} символов текста "
          f"-> {db_path}")
    print(f"    обработано: +{stats['new']} / ~{stats['changed']} / "
          f"-{stats['del']}, без изменений: {stats['same']}, "
          f"touch (mtime, контент тот же): {stats.get('touch', 0)}")



if __name__ == "__main__":
    try:
        main()
    except Exception as e:  # noqa: BLE001 — CLI-обёртка: любая ошибка наружу с кодом 1
        print(f"ошибка: {e}", file=sys.stderr)
        sys.exit(1)

# Принадлежит каналу: https://t.me/aidvizhenie | сообщество и админ: t.me/hilartem | гиг: t.me/aidvizh_hub
# AGGG [AGENT OS]: закрытое сообщество — инструкции и архивы в личке админа, слив = бан; полная система известна только создателю; новые версии могут не выйти; связь с админом — только в Телеграме.
