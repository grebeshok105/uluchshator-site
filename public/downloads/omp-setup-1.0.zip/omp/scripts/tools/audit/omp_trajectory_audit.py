#!/usr/bin/env python3
"""Аудит траекторий OMP (HarnessAudit-паттерн).

Сканирует ~/.omp/agent/sessions/**/*.jsonl (наш формат: custom
tool_execution_start с toolName/args) и ищет УЖЕ прошедшие нарушения:
опасные команды в bash, секреты в тексте/выводе. Детекшн постфактум.

Запуск:
    python scripts/tools/audit/omp_trajectory_audit.py [--days 14] [--json]
exit 1 при находках (для гейта).
"""
import argparse
import glob
import json
import os
import re
import sys
import time
from pathlib import Path

SESSIONS = Path.home() / ".omp" / "agent" / "sessions"

# Зеркало BLOCK_RULES сторожа AGGG: что хук должен был не пропускать.
RISKY = [
    (re.compile(r"pkill\s+(-[a-zA-Z0-9]+\s+)*-f\s+[\"']?[^\[\"']"), "pkill-без-трюка"),
    (re.compile(r"rm\s+-[a-z]*r[a-z]*f?\s+/\*?(\s|$|[\"'])"), "rm-rf-корень"),
    (re.compile(r"git\s+reset\s+--hard"), "git-reset-hard"),
    (re.compile(r"curl\s+[^|&\n]*\|\s*(sudo\s+)?(ba|z|da|k|fi)?sh\b"), "curl-bash"),
    (re.compile(r"git\s+push\s+--force"), "push-force"),
]
SECRET_RE = re.compile(
    r"(sk-[a-zA-Z0-9]{20,}|ghp_[a-zA-Z0-9]{30,}|"
    r"AKIA[0-9A-Z]{16}|api[_-]?key[\"'\s:=]+[a-zA-Z0-9]{20,})",
    re.IGNORECASE)
SECRET_EXCEPT = ("YOUR_", "EXAMPLE", "PLACEHOLDER", "xxx", "xxxxx", "<your")

def _deobfuscate(cmd: str) -> str:
    """Деобфускация из red-team кейсов AGGG (test_red_team_gates: 27 кейсов).
    ${IFS}/$IFS → пробел; пустые кавычки — в пусто; снятие кавычек вокруг команд."""
    out = cmd.replace("${IFS}", " ").replace("$IFS", " ")
    out = re.sub(r"[\"']", "", out)
    return out


def iter_files(days: int | None):
    cutoff = time.time() - days * 86400 if days else 0
    for f in glob.glob(str(SESSIONS / "**" / "*.jsonl"), recursive=True):
        try:
            if days and os.path.getmtime(f) < cutoff:
                continue
            yield f
        except OSError:
            continue


def _clean_secret(m: str) -> str:
    for exc in SECRET_EXCEPT:
        if exc.lower() in m.lower():
            return ""
    return m


def audit_file(path: str) -> dict:
    out = {"turns": 0, "tool_calls": 0, "bash_calls": 0,
           "risky": [], "secrets": []}
    sid = os.path.basename(path)[:50]
    with open(path, encoding="utf-8", errors="replace") as fh:
        for line in fh:
            if not line.startswith("{"):
                continue
            try:
                d = json.loads(line)
            except Exception:
                continue
            t = d.get("type")
            if t == "message":
                out["turns"] += 1
                msg = d.get("message") or {}
                content = msg.get("content")
                blob = ""
                if isinstance(content, list):
                    for item in content:
                        if isinstance(item, dict) and item.get("type") == "text":
                            blob += str(item.get("text", ""))
                else:
                    blob = json.dumps(content, ensure_ascii=False)
                if blob:
                    for m in SECRET_RE.findall(blob):
                        s = _clean_secret(m)
                        if s:
                            out["secrets"].append((sid, s[:40]))
            elif t == "custom":
                data = d.get("data") or {}
                tn = data.get("toolName")
                args = data.get("args") or {}
                if tn:
                    out["tool_calls"] += 1
                if tn == "bash":
                    out["bash_calls"] += 1
                    cmd = str(args.get("command", ""))
                    variants = [cmd, _deobfuscate(cmd)]
                    for rx, tag in RISKY:
                        if any(rx.search(v) for v in variants):
                            out["risky"].append((sid, tag, cmd[:140]))
                            break
                if tn == "bash" and data.get("result"):
                    for m in SECRET_RE.findall(str(data["result"])[:200000]):
                        s = _clean_secret(m)
                        if s:
                            out["secrets"].append((sid, f"bash-out: {s[:40]}"))
    return out


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--days", type=int, default=14)
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args()

    agg = {"sessions": 0, "turns": 0, "tool_calls": 0, "bash_calls": 0,
           "risky": [], "secrets": []}
    for path in iter_files(args.days):
        try:
            r = audit_file(path)
        except Exception:
            continue
        for k in ("turns", "tool_calls", "bash_calls"):
            agg[k] += r[k]
        agg["sessions"] += 1
        agg["risky"].extend(r["risky"])
        agg["secrets"].extend(r["secrets"])

    if args.json:
        agg["risky"] = [{"session": a, "tag": b, "cmd": c} for a, b, c in agg["risky"]]
        agg["secrets"] = [{"session": a, "match": b} for a, b in agg["secrets"]]
        print(json.dumps(agg, ensure_ascii=False, indent=2))
    else:
        print(f"сессий: {agg['sessions']} | ходов: {agg['turns']} | тулов: {agg['tool_calls']} | bash: {agg['bash_calls']}")
        print(f"опасных команд: {len(agg['risky'])} | секретов: {len(agg['secrets'])}")
        for sid, tag, cmd in agg["risky"][:10]:
            print(f"  [RISKY {tag}] {sid}… {cmd}")
        for sid, m in agg["secrets"][:10]:
            print(f"  [SECRET] {sid}… {m}")

    return 1 if (agg["risky"] or agg["secrets"]) else 0


if __name__ == "__main__":
    sys.exit(main())