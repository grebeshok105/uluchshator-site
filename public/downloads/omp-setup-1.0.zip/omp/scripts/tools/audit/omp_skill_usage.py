#!/usr/bin/env python3
"""Скилл-метрики OMP: какие скиллы реально загружались.

Источник: транскрипты ~/.omp/agent/sessions/**/*.jsonl (события custom
tool_execution_start с toolName='read' и args.path='skill://<имя>').
Аналог их skill_usage.py (opencode.db) под наш формат.

Запуск:
    python scripts/tools/audit/omp_skill_usage.py [--days 30] [--json] [--root ~/.omp/agent/skills]
"""
import argparse
import glob
import json
import os
import sys
import time
from pathlib import Path

SESSIONS = Path.home() / ".omp" / "agent" / "sessions"
SKILLS_ROOT = Path.home() / ".omp" / "agent" / "skills"


def iter_files(days: int | None):
    cutoff = time.time() - days * 86400 if days else 0
    for f in glob.glob(str(SESSIONS / "**" / "*.jsonl"), recursive=True):
        try:
            if days and os.path.getmtime(f) < cutoff:
                continue
            yield f
        except OSError:
            continue


def scan(files) -> dict:
    """skill -> {loads, sessions:set}."""
    usage = {}
    for path in files:
        sid = os.path.basename(path).rsplit(".", 1)[0]
        try:
            fh = open(path, encoding="utf-8", errors="replace")
        except OSError:
            continue
        with fh:
            for line in fh:
                if not line.startswith("{"):
                    continue
                try:
                    d = json.loads(line)
                except Exception:
                    continue
                if d.get("type") != "custom":
                    continue
                data = d.get("data") or {}
                if data.get("toolName") != "read":
                    continue
                p = str((data.get("args") or {}).get("path", ""))
                if not p.startswith("skill://"):
                    continue
                name = p[len("skill://"):].split(":")[0].split("/")[0]
                u = usage.setdefault(name, {"loads": 0, "sessions": set()})
                u["loads"] += 1
                u["sessions"].add(sid)
    return usage


def installed_skills(root: Path) -> list[str]:
    if not root.is_dir():
        return []
    return sorted(d.name for d in root.iterdir()
                  if d.is_dir() and (d / "SKILL.md").is_file())


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--days", type=int, default=30)
    ap.add_argument("--json", action="store_true")
    ap.add_argument("--root", default=str(SKILLS_ROOT))
    args = ap.parse_args()

    usage = scan(iter_files(args.days))
    installed = installed_skills(Path(args.root))
    loaded = sorted(usage.items(), key=lambda kv: -kv[1]["loads"])
    dead = [s for s in installed if s not in usage]

    if args.json:
        print(json.dumps({
            "installed": len(installed), "loaded": len(loaded),
            "usage": {k: {"loads": v["loads"], "sessions": len(v["sessions"])}
                      for k, v in loaded},
            "never_loaded": dead,
        }, ensure_ascii=False, indent=2))
        return 0

    print(f"скиллов в каталоге: {len(installed)} | загружалось: {len(loaded)} | период: {args.days} дн.")
    if loaded:
        print("\nтоп загрузок:")
        for name, v in loaded[:15]:
            print(f"  {name:34s} {v['loads']:4d} раз, {len(v['sessions']):3d} сессий")
    print("\nНИ РАЗУ не загружались:")
    print("  " + ", ".join(dead) if dead else "  (все загружались)")
    return 0


if __name__ == "__main__":
    sys.exit(main())