#!/usr/bin/env python3
"""Кандидаты в findings из сессий OMP (аналог их extract_findings, упрощённый).

Ищет в последних сессиях финальные сообщения ассистента с маркерами
решений/итогов и печатает готовые команды findings add. Решение о записи
принимает агент/владелец — скрипт только подсвечивает.

Запуск:
    python scripts/tools/audit/omp_findings_candidates.py [--days 7] [--min-len 200]
"""
import argparse
import glob
import json
import os
import re
import sys
import time
from pathlib import Path

SESSIONS = Path.home() / ".omp" / "agent" / "sessions"
MARKERS = re.compile(
    r"(итог|решение|вывод|сделано|принял|выбрал|решил|причина|фикс|"
    r"проблема|грабля|урок|не работает|оказалось|проверено|итого)",
    re.IGNORECASE)


def iter_files(days: int | None):
    cutoff = time.time() - days * 86400 if days else 0
    for f in glob.glob(str(SESSIONS / "**" / "*.jsonl"), recursive=True):
        try:
            if days and os.path.getmtime(f) < cutoff:
                continue
            yield f
        except OSError:
            continue


def _text_of(content) -> str:
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        return "\n".join(
            str(it.get("text", "")) for it in content
            if isinstance(it, dict) and it.get("type") == "text")
    return ""


def extract_candidates(path: str, min_len: int) -> list[dict]:
    last_text = ""
    last_ts = ""
    with open(path, encoding="utf-8", errors="replace") as fh:
        for line in fh:
            if not line.startswith("{"):
                continue
            try:
                d = json.loads(line)
            except Exception:
                continue
            if d.get("type") != "message":
                continue
            msg = d.get("message") or {}
            if msg.get("role") != "assistant":
                continue
            txt = _text_of(msg.get("content"))
            if txt:
                last_text = txt
                last_ts = str(d.get("timestamp", ""))
    if len(last_text) >= min_len and MARKERS.search(last_text):
        return [{"title": last_text[:160].replace("\n", " "),
                 "fragment": last_text[-600:], "ts": last_ts}]
    return []


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--days", type=int, default=7)
    ap.add_argument("--min-len", type=int, default=200)
    args = ap.parse_args()

    found = []
    for path in iter_files(args.days):
        try:
            found.extend(extract_candidates(path, args.min_len))
        except Exception:
            continue

    print(f"сессий-кандидатов c итоговым решением: {len(found)} (за {args.days} дн.)\n")
    for i, c in enumerate(found, 1):
        print(f"[{i}] {c['ts'][:16]}  {c['title'][:120]}")
        print(f"    хвост: …{c['fragment'][-260:]}…")
        print()
    if found:
        print("готовые команды (тема — начало заголовка; текст — заголовок целиком):")
        for c in found[:5]:
            topic = c["title"].split(".")[0][:80].strip()
            cmd = f'python ~/.omp/agent/db-tools/findings.py add "{topic}" --text "{c["title"][:220]}"'
            print(cmd)
    return 0


if __name__ == "__main__":
    sys.exit(main())