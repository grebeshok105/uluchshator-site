#!/usr/bin/env python3
"""lint_gate — жёсткий гейт приёмки работы (перед сдачей: агент/субагент).

Проверяет:
1) frontmatter всех top-level SKILL.md (yaml-валидность, name, description);
2) lint_skills (спека Agent Skills), если доступен;
3) лимиты строк для SKILL.md (мягкий 300 / жёсткий 500 — как канон AGGG);
   вложенные пакеты-не-скиллы (web-research-pack и т.п.) не считаются.

Любая ошибка (не предупреждение) -> exit 1: сдача результата блокируется.

Запуск:
    python scripts/tools/audit/lint_gate.py [--root ~/.omp/agent]
"""
import argparse
import os
import subprocess
import sys
from pathlib import Path

try:
    import yaml
except ImportError:
    yaml = None

HARD_LINES = 500
SOFT_LINES = 300


def check_frontmatter(path: Path) -> list[str]:
    errs = []
    try:
        s = path.read_text(encoding="utf-8")
    except Exception as e:
        return [f"не читается: {e}"]
    if not s.startswith("---"):
        return ["нет frontmatter (--- в начале)"]
    try:
        end = s.index("\n---", 4)
    except ValueError:
        return ["нет закрывающего ---"]
    fm = s[4:end]
    if yaml is None:
        return ["pyyaml не установлен — проверка frontmatter невозможна"]
    try:
        data = yaml.safe_load(fm)
    except Exception as e:
        return [f"yaml: {str(e)[:100]}"]
    if not isinstance(data, dict):
        return ["frontmatter не mapping"]
    if "name" not in data:
        errs.append("нет name")
    if "description" not in data:
        errs.append("нет description")
    return errs


def check_sizes(skills_root: Path) -> list[str]:
    errs, warns = [], []
    for d in sorted(skills_root.iterdir()):
        if not d.is_dir():
            continue
        sk = d / "SKILL.md"
        if not sk.is_file():
            continue  # пакет-не-скилл (web-research-pack и т.п.)
        n = sum(1 for _ in sk.open(encoding="utf-8", errors="replace"))
        if n > HARD_LINES:
            errs.append(f"{sk.relative_to(skills_root)}: {n} строк (> hard {HARD_LINES})")
        elif n > SOFT_LINES:
            warns.append(f"{sk.relative_to(skills_root)}: {n} строк (> soft {SOFT_LINES})")
    return errs, warns


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--root", default=str(Path.home() / ".omp" / "agent"))
    args = ap.parse_args()

    root = Path(args.root)
    skills_root = root / "skills"
    errors, warnings = [], []

    if skills_root.is_dir():
        for d in sorted(skills_root.iterdir()):
            sk = d / "SKILL.md"
            if sk.is_file():
                for e in check_frontmatter(sk):
                    errors.append(f"{sk.relative_to(root)}: {e}")
        e, w = check_sizes(skills_root)
        errors.extend(e)
        warnings.extend(w)

    lint = root / "scripts" / "tools" / "skills" / "lint_skills.py"
    if lint.is_file():
        try:
            r = subprocess.run([sys.executable, str(lint), str(root)],
                               capture_output=True, text=True, timeout=120)
            if r.returncode != 0:
                out = r.stdout or r.stderr
                real = [ln.strip()[:120] for ln in out.splitlines()
                        if "✗" in ln and "web-research-pack" not in ln]
                if real:
                    errors.append(f"lint_skills: {real[:4]}")
                else:
                    warnings.append("lint_skills: ошибок нет, кроме baseline web-research-pack")
        except Exception as ex:
            warnings.append(f"lint_skills не выполнился: {ex}")

    for w in warnings:
        print(f"  ⚠ {w}")
    if errors:
        print("ГЕЙТ НЕ ПРОЙДЕН:")
        for e in errors:
            print(f"  ✗ {e}")
        return 1
    print(f"ГЕЙТ ПРОЙДЕН: скиллов проверено, ошибок 0 (предупреждений: {len(warnings)})")
    return 0


if __name__ == "__main__":
    sys.exit(main())