// ~/.omp/agent/hooks/pre/orchestration-hooks.js
// SAFE minimal hub — NO nudge storms, NO skill spam, NO analyze loops.
// - SPAWN/DONE/MCP log + metrics + status
// - auto-fill tasks[].agent when omitted (review/scout/tester keywords)
// - quality contract on weak task briefs
// - optional one-shot DISPLAY notice on heavy solo edits (does NOT kick LLM)
const fs = require("node:fs");
const path = require("node:path");

const HOME = process.env.HOME || process.env.USERPROFILE || ".";
const LOG_DIR = path.join(HOME, ".omp", "agent", "logs");
const LOG_FILE = path.join(LOG_DIR, "orchestration.log");
const METRICS_FILE = path.join(LOG_DIR, "orchestration-metrics.json");

const CONTRACT_SUFFIX =
  "\n\n(контракт: укажи точный scope — какие файлы трогать и что считается готовым; верни отчёт: что сделал, изменённые файлы, команды с результатами, риски, нерешённое; проверь результат перед отчётом)";

const QUALITY_MARKERS = [
  "файл", "путь", "src", "test", "tests", ".ts", ".py", ".js", ".java", ".json", ".yml", ".md",
  "исправь", "почини", "создай", "напиши", "добавь", "удали", "переименуй", "замени", "прочитай",
  "найди", "проверь", "проанализируй", "запусти", "собери", "рефактори",
  "#", ":", "/", "\\", "skill://",
];

function log(line) {
  try {
    fs.mkdirSync(LOG_DIR, { recursive: true });
    fs.appendFileSync(LOG_FILE, `${new Date().toISOString()} ${line}\n`, "utf8");
  } catch {}
}

function saveMetrics() {
  try {
    fs.mkdirSync(LOG_DIR, { recursive: true });
    fs.writeFileSync(METRICS_FILE, JSON.stringify(metrics, null, 2), "utf8");
  } catch {}
}

function summarizeTasks(tasks) {
  if (!Array.isArray(tasks) || tasks.length === 0) return "no-tasks";
  const counts = {};
  for (const t of tasks) {
    const r = (t && t.agent) || "default";
    counts[r] = (counts[r] || 0) + 1;
  }
  return `${tasks.length} agent(s) [${Object.entries(counts)
    .map(([r, n]) => `${r}x${n}`)
    .join(", ")}]`;
}

function isWeakTask(text) {
  if (typeof text !== "string") return true;
  const t = text.trim();
  if (t.length < 60) return true;
  if (t.length > 400) return false;
  const lower = t.toLowerCase();
  return !QUALITY_MARKERS.some((m) => lower.includes(m.toLowerCase()));
}

function inferAgent(taskText, nameHint) {
  const t = `${nameHint || ""}\n${taskText || ""}`.toLowerCase();
  if (/security\s*review|security-reviewer|аудит безопас|уязвим/.test(t)) {
    return "security-reviewer";
  }
  if (/\breview(er)?\b|ревью|code review|проанализир|analyze|audit\b/.test(t)) {
    return "reviewer";
  }
  if (/\bscout\b|развед|explore|map (the )?code|структур|survey/.test(t)) {
    return "scout";
  }
  if (/\btester\b|qualitygate|run tests|прогон тест|регресс/.test(t)) {
    return "tester";
  }
  if (/\bbriefer\b|сжми отчёт|summarize reports/.test(t)) return "briefer";
  if (/\blibrarian\b/.test(t)) return "librarian";
  if (/\bdesigner\b|ui\/ux|вёрстк/.test(t)) return "designer";
  if (/\bsonic\b|mass replace/.test(t)) return "sonic";
  return null;
}

/** Visible notice only — NEVER followUp/steer (that restarts the agent). */
function showNotice(pi, ctx, key, text) {
  if (!ctx || !ctx.hasUI) return false;
  if (shownOnce[key]) return false;
  shownOnce[key] = true;
  try {
    if (ctx.ui && typeof ctx.ui.setStatus === "function") {
      ctx.ui.setStatus("hook", `hook: ${key}`);
    }
  } catch {}
  try {
    pi.sendMessage({
      customType: "orchestration-hook",
      content: `[HOOK:${key}]\n${text}`,
      display: true,
      details: { key, source: "orchestration-hooks", kickAgent: false },
    });
    log(`NOTICE ${key}`);
    return true;
  } catch (err) {
    log(`NOTICE ERR ${key} ${err && err.message}`);
    return false;
  }
}

const metrics = {
  byRole: {},
  batches: 0,
  subagents: 0,
  mcpCalls: 0,
  delegateReminders: 0,
  reviewReminders: 0,
  qualityAmendments: 0,
  agentInferences: 0,
  startedAt: Date.now(),
};

const pending = new Map();
const shownOnce = Object.create(null);
let soloEdits = 0;
let delegateReminded = false;
let reviewReminded = false;

export default function (pi) {
  pi.on("tool_call", async (event, ctx) => {
    try {
      const name = event.toolName;
      const input = event.input || {};

      if (name === "task") {
        const tasksIn = Array.isArray(input.tasks) ? input.tasks : [];
        let tasks = tasksIn.map((t) =>
          t && typeof t === "object" ? { ...t } : t,
        );

        let inferred = 0;
        tasks = tasks.map((t, idx) => {
          if (!t || typeof t !== "object") return t;
          if (t.agent && String(t.agent).trim()) return t;
          const agent = inferAgent(t.task || t.prompt || "", t.name || "");
          if (agent) {
            inferred++;
            log(`AGENT  infer#${idx} -> ${agent}`);
            return { ...t, agent };
          }
          return t;
        });
        if (inferred) metrics.agentInferences += inferred;

        const desc = summarizeTasks(tasks);
        pending.set(event.toolCallId, { kind: "task", desc, at: Date.now() });
        metrics.batches++;
        metrics.subagents += tasks.length;
        for (const t of tasks) {
          const r = (t && t.agent) || "default";
          metrics.byRole[r] = (metrics.byRole[r] || 0) + 1;
        }
        soloEdits = 0;
        delegateReminded = false;
        reviewReminded = false;
        log(`SPAWN  ${desc}`);
        if (ctx && ctx.hasUI) {
          try {
            ctx.ui.setStatus("orchestration", `⧗ ${desc}`);
          } catch {}
        }

        let amended = 0;
        const revisedTasks = tasks.map((t) => {
          if (!t || typeof t !== "object") return t;
          if (isWeakTask(t.task)) {
            amended++;
            return { ...t, task: String(t.task || "") + CONTRACT_SUFFIX };
          }
          return t;
        });
        if (amended) metrics.qualityAmendments += amended;

        if (inferred || amended) {
          log(`AMEND  agents+${inferred} quality+${amended} ${desc}`);
          return { input: { ...input, tasks: revisedTasks } };
        }
      } else if (typeof name === "string" && name.startsWith("mcp__")) {
        pending.set(event.toolCallId, {
          kind: "mcp",
          desc: name,
          at: Date.now(),
        });
        metrics.mcpCalls++;
        log(`MCP    ${name}`);
      }
    } catch (err) {
      log(`tool_call ERR ${err.message}`);
    }
  });

  pi.on("tool_result", async (event, ctx) => {
    try {
      const name = event.toolName;
      const p = pending.get(event.toolCallId);

      if (name === "task") {
        pending.delete(event.toolCallId);
        log(`DONE   ${(p && p.desc) || "task"}`);
        if (ctx && ctx.hasUI) {
          try {
            ctx.ui.setStatus("orchestration", "");
          } catch {}
        }
      } else if (typeof name === "string" && name.startsWith("mcp__")) {
        pending.delete(event.toolCallId);
        log(`MCPDONE ${(p && p.desc) || name}`);
      } else if ((name === "write" || name === "edit") && ctx && ctx.hasUI) {
        const pth = String(
          (event.input && (event.input.path || event.input.file_path)) || "",
        );
        if (/^xd:\/\//i.test(pth) || /node_modules/i.test(pth)) return;

        soloEdits++;
        // High threshold; DISPLAY ONLY — never followUp.
        if (soloEdits >= 20 && !delegateReminded) {
          delegateReminded = true;
          metrics.delegateReminders++;
          showNotice(
            pi,
            ctx,
            "solo-delegate",
            "Много solo edit без task. (информационно; агента не пинаю.)",
          );
        }
        if (soloEdits >= 30 && !reviewReminded) {
          reviewReminded = true;
          metrics.reviewReminders++;
          showNotice(
            pi,
            ctx,
            "solo-reviewer",
            'Перед финалом можно task с agent:"reviewer". (информационно.)',
          );
        }
      }
    } catch (err) {
      log(`tool_result ERR ${err.message}`);
    }
  });

  pi.on("turn_end", async () => {
    try {
      globalThis.__ompOrchestration = {
        pending: [...pending.values()].map((p) => ({
          kind: p.kind,
          desc: p.desc,
          sinceMs: Date.now() - p.at,
        })),
        metrics: { ...metrics },
      };
    } catch {}
  });

  pi.on("agent_end", async () => {
    try {
      saveMetrics();
    } catch {}
  });

  pi.on("session_shutdown", async (event, ctx) => {
    try {
      saveMetrics();
      if (!ctx || !ctx.hasUI) return;
      log(`SESSION END ${JSON.stringify(metrics)}`);
    } catch {}
  });
}
