// ~/.omp/agent/hooks/pre/first-run-changes.js
// Показывает «что изменилось» на ПЕРВОМ запуске omp после установки архива.
// - маркер ~/.omp/agent/.changes-seen-<ver> создаётся ПОСЛЕ успешного sendMessage
// - маркер есть → молчим; файла изменений нет → молчим (и маркер не пишем)
// - display-сообщение (kickAgent: false) — агента не будит, токены не тратит
// - версия в имени маркера: новая версия архива = новый маркер = показ снова
const fs = require("node:fs");
const path = require("node:path");

const HOME = process.env.HOME || process.env.USERPROFILE || ".";
const AGENT_DIR = path.join(HOME, ".omp", "agent");
const VERSION = "0.7";
const MARKER = path.join(AGENT_DIR, `.changes-seen-${VERSION}`);
const CHANGES_FILE = path.join(AGENT_DIR, `changes-${VERSION}.md`);

export default function (pi) {
  pi.on("session_start", (_event, ctx) => {
    try {
      if (!ctx || !ctx.hasUI) return; // headless/print-режим — не мешаем
      if (fs.existsSync(MARKER)) return;
      if (!fs.existsSync(CHANGES_FILE)) return;
      const text = fs.readFileSync(CHANGES_FILE, "utf8").trim();
      if (!text) return;
      pi.sendMessage({
        customType: "first-run-changes",
        content: text,
        display: true,
        details: { key: `changes-${VERSION}`, source: "first-run-changes", kickAgent: false },
      });
      fs.writeFileSync(MARKER, new Date().toISOString(), "utf8");
    } catch (err) {
      // тихо: хук не должен ронять сессию; маркер не пишем — показ повторится
    }
  });
}
