// ~/.omp/agent/hooks/pre/qa-gate.js
// QA-детекшн (режим «журнал + nudge», БЕЗ блокировок — решение владельца 24.08.2026).
// Порт AGGG-механики stop_qa_gate / session_end_gate на OMP-события:
//   - tool_result: состояния code_changed (write/edit) и tests_run (bash-тесты);
//   - nudge модели 1 раз за сессию: «правился код, тесты не запускались»;
//   - session_shutdown: запись в qa-sessions.jsonl с флагом qa_gap.
// OMP 0.7 поддерживает session_stop (stop_hook_active) и decision block —
// детерминированный блок здесь НЕ используется (см. решение владельца).
const fs = require("node:fs");
const path = require("node:path");

const HOME = process.env.HOME || process.env.USERPROFILE || ".";
const LOG_DIR = path.join(HOME, ".omp", "agent", "logs");
const JOURNAL = path.join(LOG_DIR, "qa-sessions.jsonl");

const TEST_MARKERS = [
  "pytest", "unittest", "run_tests", "npm test", "bun test", "deno test",
  "cargo test", "go test", "dotnet test", "node --test", "vitest", "jest",
];

function log(line) {
  try {
    fs.mkdirSync(LOG_DIR, { recursive: true });
    fs.appendFileSync(
      path.join(LOG_DIR, "qa-gate.log"),
      `${new Date().toISOString()} ${line}\n`,
      "utf8",
    );
  } catch {}
}

function isCodeWrite(name, input) {
  if (name !== "write" && name !== "edit" && name !== "apply_patch") return false;
  const pth = String((input && (input.path || input.file_path)) || "");
  if (/^xd:\/\//i.test(pth) || /node_modules/i.test(pth)) return false;
  return true;
}

function isTestRun(name, input) {
  if (name !== "bash") return false;
  const cmd = String((input && input.command) || "");
  return TEST_MARKERS.some((m) => cmd.toLowerCase().includes(m));
}

export default function (pi) {
  const state = { codeChanged: false, testsRun: false, nudged: false };

  pi.on("tool_result", async (event, ctx) => {
    try {
      const { toolName, input } = event;
      if (isCodeWrite(toolName, input)) {
        state.codeChanged = true;
        if (!state.testsRun && !state.nudged) {
          state.nudged = true;
          pi.sendMessage({
            customType: "qa-gate",
            content:
              "QA-детекшн: в сессии правился код, тесты (пока) не запускались. " +
              "Если правка меняет поведение — прогони тесты перед «готово».",
            display: false,
            attribution: "agent",
          });
          log("NUDGE sent (code_changed, no tests)");
        }
      } else if (isTestRun(toolName, input)) {
        state.testsRun = true;
      }
    } catch (err) {
      log(`tool_result ERR ${err && err.message}`);
    }
  });

  pi.on("session_shutdown", async (event, ctx) => {
    try {
      let sessionFile = "-";
      try {
        const sm = ctx && ctx.sessionManager;
        if (sm && typeof sm.getSessionFile === "function") {
          sessionFile = sm.getSessionFile() || "-";
        }
      } catch {}
      const entry = {
        ts: new Date().toISOString(),
        session_file: sessionFile,
        code_changed: state.codeChanged,
        tests_run: state.testsRun,
        qa_gap: state.codeChanged && !state.testsRun,
      };
      fs.mkdirSync(LOG_DIR, { recursive: true });
      fs.appendFileSync(JOURNAL, JSON.stringify(entry) + "\n", "utf8");
      log(`SESSION END ${JSON.stringify(entry)}`);
    } catch (err) {
      log(`session_shutdown ERR ${err && err.message}`);
    }
  });
}