// ~/.omp/agent/hooks/pre/danger-commands.js
// Защита от опасных команд: rm -rf по корню/системным путям, format, diskpart, стирание дисков.
// С UI — спрашивает подтверждение; без UI — блокирует.
// Чистки внутри проекта или /tmp НЕ блокируются: триггер только на
// корень (/), системные каталоги (/etc /usr /var /home /bin /boot /lib /root /srv /opt),
// голую домашнюю (~) и корень диска Windows (c:\).

export function isDangerousCommand(cmd) {
  // нормализуем: нижний регистр, схлопнуть пробелы для проверки
  const norm = String(cmd ?? "").toLowerCase().replace(/\s+/g, " ").trim();
  const destructure = /(^|&&|\|\||;|\|)\s*([^&|;]+)/g;
  let m;
  while ((m = destructure.exec(norm)) !== null) {
    const part = m[2].trim();
    if (
      // rm -rf: корень/системные пути/голая домашняя/корень диска
      /^rm\s+(-[a-z]*r[a-z]*f[a-z]*|-[a-z]*f[a-z]*r[a-z]*)\s+(\/$|\/\s|\/\*|~(\s|$)|\/(etc|usr|var|home|bin|boot|lib|root|srv|opt)\b|c:\s*\\)/.test(part) ||
      // Windows: del/rd по корню диска
      /^(del|erase|rd|rmdir)(\s+\/[sqf]+)+\s+[a-z]:\s*\\/.test(part) ||
      // форматирование и разметка дисков
      /^(format|diskpart|fdisk|mkfs\.)/.test(part) ||
      // PowerShell-стирание по корню
      /^remove-item.*-recurse.*(-force\s+)?[a-z]:\s*\\/.test(part) ||
      /^clear-(content|recyclebin)\b/.test(part)
    ) {
      return part;
    }
  }
  return null;
}

export default function (pi) {
  pi.on("tool_call", async (event, ctx) => {
    if (event.toolName !== "bash") return;
    const cmd = String(event.input.command ?? "");
    const dangerous = isDangerousCommand(cmd);
    if (!dangerous) return;

    const reason = `опасная команда: ${dangerous}`;
    if (!ctx || !ctx.hasUI) return { block: true, reason };
    const ok = await ctx.ui.confirm("Подтверди опасную команду", `Выполнить: ${cmd}`);
    if (!ok) return { block: true, reason: "пользователь отклонил: " + dangerous };
  });
}
