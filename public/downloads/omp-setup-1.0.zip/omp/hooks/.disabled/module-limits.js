// ~/.omp/agent/hooks/pre/module-limits.js
// Лимиты размера файлов, которые пишет агент (write-тул): двухступенчатая защита.
// 1) > 500 строк — предупреждение (файл растёт, подумай о декомпозиции).
// 2) > 1000 строк — блок (без UI) / подтверждение (с UI): файл обязан быть разбит на модули.
// Выход из лимита: первая строка файла с маркером «@large-file-approved» (явное решение).
// Исключения: данные и сгенерированное (.json, .lock*, .min.js/.min.css, .snap, фикстуры data/).
// edit-тул не блокируется: это патч, итоговый размер из него не виден — правило для edit живёт в промпте.

export const MAX_WARN_LINES = 500;
export const MAX_BLOCK_LINES = 1000;
export const LARGE_FILE_MARKER = "@large-file-approved";

// расширения, которые лимит не трогает (данные, артефакты, сгенерированное)
const EXEMPT_EXTENSIONS = new Set([
  ".json", ".jsonc", ".lock", ".lockb", ".snap", ".min.js", ".min.css",
  ".png", ".jpg", ".jpeg", ".gif", ".webp", ".ico", ".woff", ".woff2", ".ttf",
]);

export function isExemptPath(path) {
  const p = String(path ?? "").toLowerCase();
  if (p.includes("data/") || p.includes("fixtures/") || p.includes("__snapshots__")) return true;
  const ext = p.slice(p.lastIndexOf("."));
  return EXEMPT_EXTENSIONS.has(ext);
}

// Возвращает { lines, exempt, marked, status: "ok" | "warn" | "block" } для тестов и для хука.
export function checkFileSize(path, content) {
  const text = String(content ?? "");
  const firstLine = text.split("\n", 1)[0] ?? "";
  const exempt = isExemptPath(path);
  const marked = firstLine.includes(LARGE_FILE_MARKER);
  const lines = text.split("\n").length;
  let status = "ok";
  if (!exempt && !marked) {
    if (lines > MAX_BLOCK_LINES) status = "block";
    else if (lines > MAX_WARN_LINES) status = "warn";
  }
  return { lines, exempt, marked, status };
}

export default function (pi) {
  pi.on("tool_call", async (event, ctx) => {
    if (event.toolName !== "write") return;
    const path = String(event.input.path ?? "");
    const content = String(event.input.content ?? "");
    const { lines, exempt, marked, status } = checkFileSize(path, content);
    if (status === "ok") return;

    if (status === "warn") {
      if (ctx && ctx.hasUI && ctx.ui.notify) {
        ctx.ui.notify(`большой файл: ${path} — ${lines} строк; подумай о декомпозиции`);
      }
      return;
    }

    // status === "block"
    const reason = `файл слишком большой: ${path} (${lines} строк, лимит ${MAX_BLOCK_LINES}). Разбей на модули или добавь «${LARGE_FILE_MARKER}» первой строкой как явное исключение`;
    if (!ctx || !ctx.hasUI) return { block: true, reason };
    const ok = await ctx.ui.confirm("Файл больше лимита", `Записать: ${path} (${lines} строк)?`);
    if (!ok) return { block: true, reason: "пользователь отклонил: " + reason };
  });
}
