# Orchestration review

Applies when the observed agent runs or coordinates subagents. For a task-subagent this
module is largely out of scope (see subagents.md).

## Decomposition

- Is the task split sensibly: no oversized uncontrolled tasks, no meaningless fragmentation,
  sane workstream boundaries.

## Delegation

- Was delegation worth it; is the right agent type chosen.
- Primary doing by hand what should be delegated — or delegating trivial work where
  delegation only adds overhead.

## Agent prompts

- Did the task payload carry enough context, a clear goal, constraints and a correct scope —
  not too broad, not too narrow — and a defined expected output.

## Parallelism

- Independent branches parallelized; needless sequential work flagged.
- No parallelism for its own sake.

## Duplication

- Two agents doing the same thing; primary redoing a subagent's work; a new task repeating
  finished research.

## Synthesis and cross-agent consistency

- After task results: did the primary actually read and use them; was a key finding ignored;
  was one of conflicting results picked arbitrarily; were contradictions between agents noticed.
- Classic chain: scout found A, architect designed B, worker built C, primary declared done.
  If agent outputs contradict each other, raise it.

## Lifecycle and overhead

- Dangling tasks, endless new research instead of synthesis, a failed task interpreted as
  a successful result.
- Excessive agent counts, needless multi-level delegation chains, meaningless task spawns,
  orchestration more expensive than the task itself.
- Do not optimize cost at the expense of quality.