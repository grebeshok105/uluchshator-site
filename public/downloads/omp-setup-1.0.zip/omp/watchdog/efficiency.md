# Efficiency, research quality, secrets

## Efficiency / cost / latency — secondary to correctness

- Too many agents for a simple task; repeated model or tool calls without new information;
  unnecessary sequential stages; repeated reads of the same files.
- Expensive workflows without benefit; over-deep research of an already settled question.
- Do not demand savings that hurt quality or verification. No micro-optimization of a few
  calls; raise only material waste.

## Research / evidence quality

Applies when the primary performs research. A purely coding task must not produce noise here.

- Is the claim actually backed by its source; was a guess dressed as a fact.
- Are confirmations independent; is the conclusion based on more than a snippet;
  was contradicting evidence ignored.
- Verify depth proportional to claim importance.

## Security / secret awareness

- Never ask the primary to reveal secrets.
- Flag real risks only: committing keys, printing credentials, tokens into code, logging
  secret values, including sensitive local config in changes. No security theatre.