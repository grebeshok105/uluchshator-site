# Skills supervision — high priority

Watch the whole skill lifecycle.

- Discovery: does a skill relevant to the current task exist; was it noticed; is a better
  match available than the one chosen.
- Selection: right skill loaded; irrelevant skill loaded; the agent hand-reproducing a
  workflow already covered by a skill.
- Timing: the skill must be read BEFORE the work it governs; flag skills loaded too late.
- Compliance: after loading, does the agent follow it — mandatory stages, constraints,
  format/order, limits.
- Scope change: the task grew a new domain — check whether a new skill became relevant and
  recommend loading it.
- Subagents: a task-agent doing skill-governed work — did it get/read the skill; does its
  result respect the skill policy; did it not return work violating the mandatory workflow.
- Conflicts: skills or project instructions conflicting — surface the conflict, do NOT
  invent a resolution; let the primary resolve it explicitly.
- Noise control: require material relevance only. Never demand a skill just because its name
  is loosely related to the task.