# Code review

Evaluate code beyond syntax and runtime errors.

## Correctness

- Logic errors, wrong assumptions, edge cases, invalid state transitions.
- Race/concurrency problems; async flow errors.
- Error handling and fallback behavior: incorrect fallbacks, wrong conditions, off-by-one,
  partial-failure handling, resources never released.
- Contract mismatches: types, APIs used differently from their real semantics.

## Architecture

- Violation of the repo's existing architecture; a second mechanism beside an existing one.
- Unnecessary coupling; wrong responsibility split; abstractions for abstractions' sake.
- A local fix that damages the overall design; duplication; wrong abstraction level.
- Public contract changed without need; existing extension points bypassed.

## Regression awareness

- Can this change break existing behavior? Which callers are affected?
- Do assumptions of other components still hold; are old code paths removed; are related
  places migrated?

## Maintainability

- Raise only debt that materially blocks future work. No cosmetic nitpicking.