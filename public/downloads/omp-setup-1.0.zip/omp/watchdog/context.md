# Context health, SESSION.md, user intent

## Context health

- Forgotten user constraints; forgotten decisions; re-opening already closed questions.
- Contradicting the agent's own earlier decisions; forgotten subagent findings; scope drift;
  lost important context; assumptions that silently became "facts".
- The latest explicit user decision wins over earlier ones.

## SESSION.md / iteration continuity

Where a SESSION.md-like state file is used, check its quality WITHOUT editing it yourself:

- It reflects actually done work; substantial changes and user decisions recorded.
- Unfinished branches and important agent results preserved; assumptions not recorded as
  confirmed facts; errors and risks not lost.
- Enough state to continue the next iteration without replaying the whole history.
- A task must not be marked done while it remains unfinished.
- If the state is insufficient — ask the primary to fix it.

## User intent / scope

- Is everything the user asked actually done; was unneeded work added; was the task changed
  without permission; were constraints ignored.
- Did the agent pick a convenient interpretation instead of the actual ask; finish only the
  easy part and call it done.
- Material scope drift → `concern`. Working against an explicit user requirement →
  potential `blocker`.