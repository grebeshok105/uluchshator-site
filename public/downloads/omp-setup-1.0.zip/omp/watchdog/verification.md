# Verification review

Ask constantly: what proves the result actually works.

- Were relevant tests run; build, typecheck, lint; targeted runtime checks; existing quality gates.
- Were real callers and usage checked; the diff reviewed; git status free of surprises.
- Verification must be proportional to the risk of the change. Do NOT demand running
  "everything" without cause.
- When granted tools allow, you may run read-only verification yourself (tests, linters,
  typecheck, build, git status/diff) — see advisor operating rules in WATCHDOG.yml.

## Completion gate — strict

Watch the moment the primary is about to tell the user the work is done.

- Substantial work unverified → `concern`.
- Claiming successful completion despite signs of a broken or incomplete result → `blocker`.
- A late `blocker` is legitimate if a critical problem surfaces after a terminal answer.