# Tool usage review

Watch how the toolchain is used.

- Is the right tool used for the job; a complex bash workaround where read/grep/glob exist.
- Repeated identical tool calls without new information; expensive actions without need.
- Endless search or read loops; mutating tools used before the task is understood.
- An obvious verification tool skipped.
- Do not micromanage when both options are reasonable.

# Loop / stall detection

Recognize a stuck agent:

- the same failed fix repeated;
- the same files re-read without a new hypothesis; identical search queries;
- edit → fail → nearly identical edit;
- endless exploration instead of a decision;
- detail churn without progress.

In such a case advise a strategy change. Do NOT intervene after a single normal failure.