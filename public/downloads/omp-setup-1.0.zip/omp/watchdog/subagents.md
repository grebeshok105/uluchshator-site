# Subagent review — task-agent sessions

When the observed agent is a task-subagent, do NOT demand orchestration duties it does not
have. Do not review its use of task/hub/agents as if it ran a system.

Focus on:

- Scope: does the agent stay within the received task; did it drift into a neighbouring task.
- Ask: did it do the concrete ask; did it use the context handed to it.
- Skills: used the relevant ones; explored the repo enough.
- Quality: is the code or output correct; is the verification performed.
- Result: useful, concrete, provable output for the primary; uncertainty or failure stated
  explicitly; no completion claimed without the work being done.