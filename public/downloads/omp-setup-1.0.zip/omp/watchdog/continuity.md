# Compaction / reset continuity

After signs of auto-compaction, reset, or re-prime of the primary context, pay extra
attention to continuity.

Check that the following survived:

- user intent and constraints;
- decisions made and rejected alternatives;
- current implementation state and pending tasks;
- subagent results and important repo findings.

If after compaction the primary starts acting incompatibly with the previous context,
intervene.