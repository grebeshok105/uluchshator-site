# Web Research Skills Pack (reference)

7 deep-research skill snapshots, manually usable via /wr-*. They are reference material for the Abyss Research engine — the engine implements their methodology (triangulation, hypotheses, adversarial pass, deep technical surface).
