---
name: abyss-research
description: "Use when the user wants an exhaustive, autonomous deep-web research run — /abyss-research <topic>, 'проведи максимально глубокое исследование', 'deep research', 'abyss research' — on any question where completeness, source diversity, contradiction hunting and obscure sources matter more than speed. Manually invoked; always maximum-depth; never auto-triggers on ordinary questions."
---

# ABYSS Research — автономное исчерпывающее исследование веба

Ручной режим максимальной глубины. Обычный флоу OMP не трогает; этот скилл срабатывает только по явному запросу (`/abyss-research <вопрос>` или эквивалент).

## Что делает система

Движок `~/.omp/abyss/` (Node, без зависимостей, SQLite-хранилище) выполняет волновое исследование:
- волна 0: директор строит research map (ветки, приоритеты, сущности, языки);
- волна 1: дифференцированные охотники (primary-source, community, code/technical, negative/criticism, historical, latest/current, comparison, long-tail) генерируют и исполняют разные запросы;
- волна 2: триаж → чтение лучших источников (fetch → camoufox-браузер эскалация) → извлечение evidence-пакетов;
- волна 3: охотник за противоречиями атакует консенсус; прослеживание происхождения (near-dup кластеризация → lineages);
- волна 4: аудит покрытия (coverage matrix);
- волна 5+: мутатор запросов точечно закрывает пробелы (+ adaptive extra reads при открытых critical-дырах), пока не наступит сатурация (информационный прирост, не счёт источников);
- финал: заморозка evidence → claim-level provenance (важные claims получают вердикты independent / same_lineage / uncertain по родословной, не по числу URL) → синтез → аудит цитирований → отчёт.

## Инвокация (исполни это как агент)

1. Возьми вопрос пользователя дословно. Если нужен язык/ограничения — передай.
2. Запусти движок (долгий прогон — в фоне):
   ```bash
   cd ~/.omp/abyss && node bin/cli.mjs run-bg "<вопрос>"
   ```
   Или синхронно с ожиданием (до 1 часа): `node bin/cli.mjs run "<вопрос>"`.
   Быстрый вариант (только по явной просьбе пользователя, ~3-6 мин, урезанные волны/лимиты): `node bin/cli.mjs run "<вопрос>" --fast`.
3. Мониторь прогресс: `node bin/cli.mjs status <runId>` / `wait <runId>` (печатает события волн).
4. Когда статус `completed|incomplete|failed` — покажи пользователю отчёт:
   `node bin/cli.mjs show <runId>` (report.md + audit.json).
5. Коротко доложи: статус, достигнута ли сатурация, ключевые цифры (queries / sources read / claims / lineages), остаточные нерешённости из отчёта.

## Правила

- Это режим максимальной глубины: не предлагай «упрощённый» вариант, не спрашивай про глубину.
- Результат — отчёт движка (он сам синтезирует и аудитирует цитаты). Не переписывай отчёт «своими словами» поверх — только суммаризируй для чата и укажи путь к полному отчёту.
- Не подставляй в промпты движка секреты/ключи — движок сам берёт их из env.
- Если прогон упал: `doctor` → `list` → сообщи причину; предложи resume.
- Если вопрос — обычный быстрый вопрос (не подразумевает глубины) — НЕ запускай движок, отвечай нормально.

## Данные

- БД: `~/.omp/abyss/data/abyss.db`; отчёты: `~/.omp/abyss/data/runs/<runId>/report.md`, `audit.json`, `report.json`;
- `audit.json` — `{status: clean|issues_found|incomplete|timeout|failed, findings: [...]}`;
  провал/таймаут аудита никогда не маскируется под «0 находок»;
- конфиг: `~/.omp/abyss/config.json` (провайдеры, модели, лимиты, сатурация);
- команды CLI: `run | run-bg | resume | wait | status | list | show | doctor | setup`.