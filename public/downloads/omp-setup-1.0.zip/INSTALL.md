# INSTALL.md — omp-setup 1.0 (промпт для агента-установщика)

Этот файл — готовая инструкция переноса конфигурации **Oh My Pi (omp) 1.0** на новый Windows-компьютер.
Скопируй его содержимое целиком в чат агента на новой машине и запусти. В архиве — **скрипты установки**
(`install/`), они делают раскладку и проверки автоматически; агент выполняет ручные шаги (софт, данные, шрифты)
и в конце собирает чек-лист с ЖИВЫМ выводом.

**ВАЖНО перед началом:** распакуй архив в отдельную папку (например `C:\Users\<имя>\omp-setup-1.0`)
и открой omp/терминал **в этой папке**. Не отправляй zip в чат — агент не прочитает его.

**ЭТОТ АРХИВ СОДЕРЖИТ ЖИВЫЕ API-КЛЮЧИ** (провайдеры forge, opencode-go, a6api — в `omp/models.yml`).
Не выкладывай в публичный доступ, не коммить в публичный git. Приватный репозиторий — допустим.

---

Ты выполняешь перенос готовой конфигурации Oh My Pi 1.0. Выполняй шаги строго по порядку.

## ПРАВИЛА — прочитай до начала

1. **Уже установлено — НЕ трогай.** Любой софт, который уже стоит и работает (scoop, JDK, jdtls, rust-analyzer, node, npm-пакеты, шрифты, tokentracker), — НЕ переустанавливай и НЕ обновляй. Шаг установки — только если софта нет.
2. **Заменяются только конфиги из этого архива, и только после бэкапа** (Шаг 1). Чего нет в архиве — не трогается.
3. **ОБЯЗАТЕЛЬНЫЕ шаги: 1 (бэкап), 3 (скрипты setup+doctor), 6 (скрипт camoufox), 7 (LSP), 8 (RAG), 9 (MCP), 12 (Nerd Font).** Установка НЕ завершена, пока в отчёте нет ЖИВОГО вывода проверок Шага 14. Пропустить нельзя; «готово» без вывода команд нельзя.
4. **Ничего не удаляй** из существующей системы без явного согласия пользователя (кроме перечисленного в Шаге 1.3).
5. Не хватает прав/файла/диска — не импровизируй молча: доделай остальное и явно напиши, что пропущено и почему.

## Шаг 0. Предусловия

1. Убедись, что установлен Oh My Pi (omp) — если нет, установи его первым.
2. `echo %USERNAME%` (или `whoami`). Пусть `U` = это имя.
3. Проверь окружение: `node --version`, `python --version`, `git --version`, `uv --version`. Чего нет — сообщи (python обязателен для скриптов установки; node обязателен для omp).
4. Рекурсивно по ВСЕМ файлам папки установки замени `__USERNAME__` на `U`. **ИСКЛЮЧЕНИЯ — НЕ трогать:** `INSTALL.md` и `skills/transferring-omp-setup/SKILL.md` (там `__USERNAME__`/`KOMP1` — литералы документации; замена сломает скилл и инструкцию). Надёжнее сделать скриптом: `python -c` однострочник по всем файлам (байтово), либо доверить это `install/setup.py` (Шаг 3 — он делает замену сам; тогда вручную НЕ нужно).
5. Убедись, что есть запись в `C:\Users\U\`.

**Пояснение:** скиллы и CLAUDE.md ставятся в `C:\Users\U\.claude\` — стандартные пути, откуда omp читает правила и скиллы. Claude Code для этого НЕ нужен и НЕ устанавливается.

## Шаг 1. Бэкап и замена старых конфигов

1. Создай `C:\Users\U\omp-setup-backup-<ГГГГММДД>\`.
2. Если существуют, скопируй в неё (сохраняя структуру): `C:\Users\U\.claude\CLAUDE.md`, `C:\Users\U\.claude\skills\`, `C:\Users\U\.claude\jujutsu-skills\`; из `C:\Users\U\.omp\agent\`: `config.yml`, `models.yml`, `mcp.json`, `lsp.json`, `APPEND_SYSTEM.md`, `VERSION`, `hooks\`, `agents\`, `managed-skills\`, `extensions\`, `themes\`, `skills\`, `db-tools\`, `docs\canon\`, `scripts\`, `watchdog\`, `WATCHDOG.yml`, `WATCHDOG.md`; `C:\Users\U\.omp\marketplaces.json`.
3. Проверь, что бэкап скопировался (сравни число файлов), и ТОЛЬКО ПОСЛЕ этого удали старые версии ровно этих файлов/папок — и больше ничего.
4. НЕ удаляй: `~/.claude.json`, `~/.claude/settings.json`, `~/.omp/agent/*.db*`, sessions/memories/logs/history/blobs, проекты и файлы пользователя.
5. Запомни путь бэкапа — укажешь его в отчёте.

## Шаг 2. Раскладка скриптом — setup.py --check

1. Из папки установки запусти: `python install\setup.py --check --home C:\Users\U` — скрипт покажет план: что куда ляжет, сколько файлов, чего не хватает. Покажи живой вывод в отчёте.
2. Если план выглядит верно: `python install\setup.py --apply --home C:\Users\U`. Скрипт сам:
   - подставит `__USERNAME__` → `U` при копировании (кроме литералов INSTALL.md и transferring-omp-setup);
   - сделает бэкап существующих целевых файлов в `<U>\omp-setup-backup-<дата>\` (если Шаг 1 не делал — дубль безопасен);
   - разложит всё по манифесту (CLAUDE.md, skills/, jujutsu-skills/, omp/*);
   - проверит: json/toml/yaml валидность, `node --check` хуков, счётчики папок (ожидания ниже), отсутствие `__USERNAME__` в установленном (кроме литерала);
   - напишет отчёт `C:\Users\U\omp-setup-install-report.txt`.
3. Содержимое отчёта — в ответ. Код выхода 0 = раскладка и базовые проверки прошли.
4. ВАЖНО: `setup.py` НЕ перезаписывает `extensions\tokentracker-notify.ts`, если там маркер `// @tokentracker-managed-omp-extension` (файл управляется трекером).

## Шаг 3. CLAUDE.md

1. Проверь, что `C:\Users\U\.claude\CLAUDE.md` = из архива (UTF-8, ~30 КБ; читается целиком — первая строка «## FIRST ACTION OF EVERY SESSION»).
2. `CLAUDE.neutral.md` НЕ копируется — это запасное «нейтральное» поведение (см. конец INSTALL).

## Шаг 4. Скиллы — счёт

Скрипт это уже проверил; задокументируй в отчёте итог:

| Каталог | Ожидание |
|---|---|
| `C:\Users\U\.claude\skills` | **53 папки** (в каждой SKILL.md) + `SKILLS_INDEX.md` + `skill_registry.json` (53 записи) |
| `C:\Users\U\.claude\jujutsu-skills` | **1** (add-vessel). Остальные 3 (gametest-authoring, mcp-lane-launch, vessel-smoke-runner) удалены на машине-доноре; при желании восстановить из файла `0.7 omp.zip` → `jujutsu-skills/` |
| `C:\Users\U\.omp\agent\managed-skills` | **3** (eval-workflow-orchestration, fabric-mcp-agent-bridge, installing-qoder2api) |
| `C:\Users\U\.omp\agent\skills` | **44 папки** (43 со SKILL.md — импорт AGGG: battle-test, web-research-camoufox, fable-loop, task-cycle, … + abyss-research; `web-research-pack` — пакет без собственного SKILL.md) |

Суммарно: 53 + 1 + 3 + 44 = **101 скилл**.

## Шаг 5. Конфиги omp — проверка (скрипт разложил)

1. `config.yml` — роли моделей: `default: opencode-go/deepseek-v4-pro:max`; `task/smol/slow/advisor: opencode-go/deepseek-v4-flash:max`; `vision: opencode-go/minimax-m3:high`; `symbolPreset: nerd`; `theme.dark: gojo`; `advisor.enabled: true`; `skills.customDirectories` → `C:/Users/U/.claude/jujutsu-skills` (путь с U после подстановки). `disabledProviders` НЕ включать обратно.
2. `models.yml` — живые ключи провайдеров (forge, opencode-go, a6api) + byesu (локальный сервер исходной машины — на новом компе не ответит, это норма; не удаляй). Резервные цепочки (retry.fallbackChains) не отключать.
3. `mcp.json` — 12 серверов (список и их требования — Шаг 9).
4. `APPEND_SYSTEM.md` — инженерное ядро + ядро AGGG (строка «## Ядро AGGG — core.txt» присутствует).
5. `VERSION` = `3.0`; `changes-1.0.md` приложится (хук first-run-changes покажет при старте).
6. `WATCHDOG.yml` + `WATCHDOG.md` + `watchdog\*.md` (11 файлов) — advisory-подсистема, активна автоматически.

## Шаг 6. MCP-сервер camoufox — ОБЯЗАТЕЛЬНЫЙ (venv в архив не входит)

1. Запусти: `python install\install_camoufox.py --apply` (ставит в `~/.omp/abyss/vendor/camoufox-research` по методу, описанному в README репозитория — venv + зависимости).
2. Проверка: `python install\install_camoufox.py --check` — PASS. Сервер прописан в mcp.json (`camoufox`, stdio).
3. Если установка требует сеть и она недоступна — честно отметь пропуск (сервер появится после установки), остальное доделай.

## Шаг 7. LSP: Java + Rust — ОБЯЗАТЕЛЬНЫЙ

`omp/lsp.json` описывает jdtls и rust-analyzer (scoop shims).

1. Уже стоит — НЕ переустанавливай: `jdtls --help`, `rust-analyzer --version`, `java -version`; если путь отличается от scoop shims — поправь `lsp.json`.
2. Java нет: `scoop install temurin21-jdk` (scoop нет — `irm get.scoop.sh | iex`), затем `scoop install jdtls`. Проверка: `jdtls --help` (первый запуск строит индекс 10–30 с).
3. Rust-analyzer нет: `scoop install rust-analyzer` (или `rustup component add rust-analyzer` — поправь command в lsp.json).
4. Язык не нужен пользователю? Спроси; секцию из lsp.json удалять только с его согласия.
5. Перезапусти omp → открой `.java`/`.rs` → запроси у lsp-тула diagnostics/hover — ответ сервера = PASS (сохрани для отчёта).

## Шаг 8. RAG-базы — ОБЯЗАТЕЛЬНЫЙ (воссоздание, не копирование)

Базы знаний НЕ едут в архиве (эмбеддинги). Воссоздаются на новой машине; модели скачаются сами.

**8.1. knowledge-rag (проектная, `D:/RAG/jujutsu`).** Папку документов даёт пользователь (это данные):
- `D:/WorkFlow/jujutsu-minecraft` — репозиторий дзюдзюцу-мода (склонируй с git-ремоута; нет пути — создай, база будет пустой).
- Создай `D:/RAG/jujutsu/config.yaml` (блок «config jujutsu» ниже), `models_cache/`, `data/` — пустые.
- **Патч кириллицы (ОБЯЗАТЕЛЬНО):** knowledge-rag 4.6.0 не ищет русский через BM25 (токенизатор ASCII). После первого старта сервера пропатчь `C:\Users\U\.knowledge-rag\venv\Lib\site-packages\mcp_server\server.py`: в методе `_tokenize` замени строку токенизации на `tokens = re.findall(r"\w[-\w]*\w|\w", text_lower)`. После правки — `/mcp reload`.
- **Пин версии:** в mcp.json `knowledge-rag@4.6.0` — ЗАПИНЕН; не «обновляй» (≥4.7 ломает handshake с omp).
- Первая индексация: сервер сам скачает модель (~240 МБ) и проиндексирует; дождись `get_index_stats` (`total_documents` > 0, `reindex.active: false`); проверь поиск кириллицей («буги вуги»).
- `.omp/RULES.md` дзюдзюцу-репо подхватится сам.

**8.2. knowledge-rag-general (общая, disabled по умолчанию).** Создай `D:/RAG/general` + `D:/WorkFlow/Knowledge` (материалы). Включение: `/mcp enable knowledge-rag-general` (только когда база нужна; экономит RAM).

**config jujutsu** (`D:/RAG/jujutsu/config.yaml`):
```yaml
paths:
  documents_dir: "D:/WorkFlow/jujutsu-minecraft"
  data_dir: "D:/RAG/jujutsu/data"
  models_cache_dir: "D:/RAG/jujutsu/models_cache"
documents:
  supported_formats: [.md, .txt, .pdf, .docx, .xlsx, .pptx]
  exclude_patterns: [".git", ".gradle", "build", "run", "logs", "node_modules", ".idea", ".vscode", ".cache", "__pycache__", ".obsidian", ".codegraph", ".omp"]
  chunking: { chunk_size: 1000, chunk_overlap: 200 }
models:
  embedding:
    model: "sentence-transformers/paraphrase-multilingual-mpnet-base-v2"
    dimensions: 768
    gpu: false
  reranker:
    enabled: true
    model: "jinaai/jina-reranker-v2-base-multilingual"
    top_k_multiplier: 3
search:
  default_results: 5
  max_results: 8
  collection_name: "jujutsu_project"
category_mappings:
  "docs/specs": specs
  "docs/plans": plans
  "docs/decisions": decisions
  "docs/audits": audits
  "docs/knowledge": memory
keyword_routes: {}
query_expansions: {}
query_expansion_groups: []
server:
  transport: stdio
```

## Шаг 9. MCP — проверка серверов, ОБЯЗАТЕЛЬНЫЙ

`mcp.json` содержит 12 серверов. Не все поднимутся на свежей машине сразу — это норма; проверь по списку:

| Сервер | Что нужно | Ожидание |
|---|---|---|
| knowledge-rag | Шаг 8.1 | `/mcp test` PASS |
| knowledge-rag-general | Шаг 8.2 | disabled (норма) |
| camoufox | Шаг 6 | `/mcp test` PASS |
| mcpvault, mcpvault_blockbench | данные в `D:\WorkFlow\Jujutsu Minecraft`, `D:\WorkFlow\BlockBench 3d models\3d models vault` (создать/перенести) | PASS после появления данных |
| context7, codegraph, sequential-thinking | npx-пакеты (скачаются сами) | PASS/первый запуск медленный |
| knowledge-mcp | проект `C:\Users\U\.codex\external\knowledge-mcp` + `~/.codex/knowledge-mcp/jujutsu-minecraft/config.yaml` (перенести с исходной машины; внешняя зависимость) | WARN, если нет — сервер пропусти, отметь |
| blockbench | http://localhost:3000/bb-mcp (внешний сервер BlockBench) | WARN, если не поднят |
| mc-world, mc-client | игровой мост; env `MC_MCP_TOKEN` (токен с исходной машины, спросить пользователя) | WARN без токена |

1. `/mcp list` — все 12 видны (general — disabled). Живой вывод в отчёт.
2. `/mcp test knowledge-rag` и `/mcp test camoufox` — PASS. По остальным — `/mcp test` и пометка.
3. Отсутствующие данные/серверы НЕ чинить молча: отметь в отчёте, что требуется от пользователя.

## Шаг 10. TokenTracker (опционально)

1. Нет трекера — `npm install -g tokentracker-cli`; `tokentracker init --yes` (создаст своё расширение, перезапишет архивное).
2. Проверка: `tokentracker status --light`, `tokentracker doctor` (warn про device_token — норма). Dashboard: `tokentracker serve --port 7680` → http://localhost:7680.
3. Грабли: через omp/hub команда `tokentracker` не резолвится (.cmd-шим); запускать: `node C:\Users\U\AppData\Roaming\npm\node_modules\tokentracker-cli\bin\tracker.js serve --port 7680 --no-open`.

## Шаг 11. Секреты и окружение

1. Ключи провайдеров лежат в `models.yml` — рабочие. В отчёте называй ТОЛЬКО имена провайдеров, без значений.
2. `MC_MCP_TOKEN` — задать как пользовательскую переменную окружения (или в omp `.env`), если мост mc-world нужен.
3. После установки удали распакованную папку, оставь zip в надёжном месте.

## Шаг 12. Nerd Font — ОБЯЗАТЕЛЬНЫЙ (глифы)

`config.yml`: `symbolPreset: nerd` — без Nerd Font иконки будут квадратиками.

1. Нет шрифта: JetBrainsMono.zip с github.com/ryanoasis/nerd-fonts/releases/latest → установить **JetBrainsMonoNerdFontMono-*** (правый клик → «Установить», либо per-user: ttf в `%LOCALAPPDATA%\Microsoft\Windows\Fonts` + записи `HKCU\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Fonts`).
2. Windows Terminal: `profiles.defaults.font.face = "JetBrainsMono Nerd Font Mono"`.
3. **Перезапусти Windows Terminal** (все окна). Проверка: статус-лайн omp рисует глифы.

## Шаг 12б. Апгрейд с 0.7 (если на этой машине уже стоял 0.7)

Скрипты сами сделают бэкап и замену конфигов; софт, данные `D:\` и ключи трогать не нужно.

1. **Старые хуки-блокеры останутся активными.** В `~/.omp\agent\hooks\pre` с 0.7 могут лежать
   `danger-commands.js` и `module-limits.js` — в архиве 1.0 их нет (на доноре они намеренно
   перенесены в `.disabled`), поэтому скрипт их НЕ перезапишет и НЕ удалит. Если нужен
   донорский режим (без блокировок) — перенеси оба файла в `~/.omp\agent\hooks\.disabled\`.
   Проверка: `doctor.py` покажет `1.11b WARN`, пока они в pre.
2. **jujutsu-skills станет 4, а не 1.** Архив несёт 1 скилл (add-vessel); три других
   (gametest-authoring, mcp-lane-launch, vessel-smoke-runner) со старой 0.7-инсталляции
   останутся на месте — это норма и плюс: doctor допускает 1-4.
3. RAG-базы и их venv с 0.7 не трогаются; патч кириллицы (если делал) сохранится.
   Убедись, что в `mcp.json` пин `knowledge-rag@4.6.0` не «обновлён» при апгрейде.

## Шаг 13. ЧЕГО НЕ ТРОГАТЬ (повтор!)

- НЕ копируй/не изменяй `~/.claude.json`, `~/.claude/settings.json` — чужие для omp файлы.
- НЕ переноси базы: `~/.omp/agent/*.db*` (agent/history/models/research), sessions, memories, history, logs, blobs. История находок research.db переносится вручную только по явному желанию пользователя.
- Установленный софт не трогается (Правило 1). `disabledProviders` не включать.
- НЕ удаляй `hooks\.disabled\` (danger-commands, module-limits) — они намеренно выключены; включение — вручную переименованием папки/файла, по желанию пользователя.

## Шаг 14. Финальный чек-лист — БЕЗ НЕГО УСТАНОВКА НЕ ЗАВЕРШЕНА

Собери ЖИВОЙ вывод каждой проверки (не «ок», а реальный вывод команды):

| # | Проверка | Ожидаемо |
|---|---|---|
| 1 | `python install\doctor.py --home C:\Users\U` | PASS: файлы, валидность, счётчики, без `__USERNAME__`; WARN по данным — допустимо |
| 2 | `python install\install_camoufox.py --check` | PASS |
| 3 | `dir C:\Users\U\.claude\skills` | 53 папки |
| 4 | `dir C:\Users\U\.claude\jujutsu-skills` | 1 (add-vessel; остальные — из 0.7 omp.zip при желании) |
| 5 | `dir C:\Users\U\.omp\agent\managed-skills` | 3 |
| 6 | `dir C:\Users\U\.omp\agent\skills` | 44 (43 со SKILL.md + web-research-pack) |
| 7 | `dir C:\Users\U\.omp\agent\hooks\pre` | 4: compact-context, first-run-changes, orchestration-hooks, qa-gate |
| 8 | `dir C:\Users\U\.omp\agent\docs\canon` | ≥25 .md (канон AGGG) |
| 9 | `dir C:\Users\U\.omp\agent\db-tools` | ≥15 .py (build/search/findings/…) |
| 10 | первые строки `C:\Users\U\.omp\agent\config.yml` | modelRoles default opencode-go/deepseek-v4-pro:max, symbolPreset nerd, theme dark gojo |
| 11 | `jdtls --help` / `rust-analyzer --version` | usage/версия |
| 12 | lsp diagnostics на .java/.rs | ответ сервера |
| 13 | обычный ответ omp | deepseek-v4-pro отвечает |
| 14 | субагент-тест (scout) | deepseek-v4-flash отвечает |
| 15 | vision: картинка в omp | minimax-m3 описывает |
| 16 | `/mcp list` | 12 серверов; knowledge-rag-general — disabled |
| 17 | `/mcp test knowledge-rag`, `/mcp test camoufox` | PASS |
| 18 | `search_knowledge` кириллицей | релевантно, reranker_score |
| 19 | патч токенизатора | `\w[-\w]*\w|\w` в `_tokenize` |
| 20 | глифы статус-лайна | не квадратики |
| 21 | `__USERNAME__` в установленных конфигах | пусто (кроме литерала transferring-omp-setup) |
| 22 | старт сессии: 4 бутстрап-скилла | using-superpowers, skill-system, omp-self-orchestration, frontend-bootstrap читаются `skill://` |

## Шаг 15. Отчёт

- путь к бэкапу; число скиллов (51+4+3+45=103); какие файлы куда; ключи — по именам провайдеров, БЕЗ значений;
- скрипты: выводы setup.py --check/--apply, doctor.py (п.1 чек-листа);
- RAG: каталоги, config.yaml, патч токенизатора, число документов после индексации;
- MCP: таблица Шага 9 с пометкой PASS/WARN и что требуется от пользователя;
- таблица Шага 14 с реальным выводом; что уже было установлено (не трогал); что пропущено и почему.

---

## Если поведение агента не устроит

Поведение задаёт `C:\Users\U\.claude\CLAUDE.md` (персона «Луна» + инженерное ядро + AGGG-прошивка).
Откат дословной фразой: **«Смени поведение: запиши содержимое CLAUDE.neutral.md из папки установки в C:\Users\<имя>\.claude\CLAUDE.md, полностью перезаписав его»**.
Влияет только на чат: код, коммиты и доки всегда нейтральные.