# Что нового в 1.0 (против 0.7)

## Скриптовая установка (главное)
- `install/setup.py` — раскладка по манифесту, бэкап в `omp-setup-backup-<дата>`,
  автоматическая подстановка `__USERNAME__`, верификация (json/toml/yaml, `node --check`,
  счётчики скиллов), отчёт-файл.
- `install/doctor.py` — постинсталльный чек-лист PASS/WARN/FAIL (exit 2 при FAIL).
- `install/bootstrap.ps1/.sh` — предусловия + вызов setup --check.
- `install/install_camoufox.py` — ставит MCP-сервер camoufox (venv в архив не входит).
- INSTALL.md переписан: адаптация под новый состав, чек-лист из 22 пунктов с живым выводом.

## Скиллы и знания
- **44 импортных скилла AGGG** в `~/.omp/agent/skills` (камуфокс-ресёрч, fable-loop,
  battle-раннеры, task-cycle, db-first-search, локальные базы, эвалы) — в 0.7 их не было.
- **Канон AGGG: 27 доков** в `~/.omp/agent/docs/canon`.
- **db-tools** (build/search/findings/repomap/…) + research.db; findings.py — канал решений.
- **Мультисудья**: scripts/tools/judge (3 ревьюера + вердикт), конфиг ~/.config/aggg2.
- **Аудит-слой**: lint_gate (гейт приёмки), check_file_sizes, omp_trajectory_audit,
  omp_skill_usage, omp_findings_candidates, harness_snapshot, lint_skills, эвалы триггеров.
- **QA-детекшн**: hooks/pre/qa-gate.js — журнал `qa-sessions.jsonl` с флагом qa_gap
  + одноразовый nudge про тесты (режим «детекшн», без блокировок).
- **Watchdog-подсистема**: WATCHDOG.yml + watchdog/*.md (advisory-правила).
- **frontend-bootstrap** — 4-й бутстрап-скилл: диспетчер дизайн/фронтенд-скиллов
  (14 маршрутов), анти-слоуп-минимум, проверка браузером.
- CLAUDE.md: retrieval router, разводка каналов памяти, жёсткая активация скиллов,
  линт-гейт приёмки, bootstrap из 4.

## MCP
- 12 серверов в mcp.json вместо 1: + camoufox (антидетект-браузер), mcpvault ×2 (Obsidian),
  knowledge-mcp, context7, codegraph, sequential-thinking, blockbench, mc-world/mc-client.
- Серверы перенесены нативно из codex-конфига; node_repl УБРАН.
- knowledge-rag: пин 4.6.0, патч кириллицы для BM25 — в INSTALL.

## Поведение
- hooks/pre: 4 активных (compact-context, first-run-changes, orchestration-hooks, qa-gate);
  danger-commands и module-limits переехали в `.disabled` (защита выключена намеренно —
  включить: перенести файл обратно в pre).

## Не входит
- Базы `*.db*` (включая research.db — переносится вручную при желании), сессии, память,
  логи, кэши, venv/camoufox, снапшоты. Данные `D:\` — по INSTALL (Шаги 8, 9).