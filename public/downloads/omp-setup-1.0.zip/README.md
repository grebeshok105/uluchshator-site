# omp-setup 1.0

Полный слепок конфигурации агента Oh My Pi: правила поведения, 103 скилла, ядро AGGG,
канон, базы-инструменты, 12 MCP-серверов, скрипты установки.

## ⚠️ Секрет
Архив содержит живые API-ключи провайдеров (`omp/models.yml`: forge, opencode-go, a6api).
Не публиковать, не коммитить в открытый git. После установки — удалить распакованную папку,
хранить только zip.

## Состав

| Дерево | Что это |
|---|---|
| `CLAUDE.md` + `CLAUDE.neutral.md` | поведение агента (персона Луна + AGGG-ядро) и нейтральный откат |
| `skills/` | 53 скилла поведения + индексы (registry) |
| `jujutsu-skills/` | 1 скилл Minecraft-мода (add-vessel; остальные 3 — в 0.7 omp.zip) |
| `omp/` | конфиги агента: config.yml, models.yml (ключи), mcp.json (12 серверов), lsp.json, APPEND_SYSTEM.md, hooks/ (4 active + 2 disabled), agents/ (9 ролей), managed-skills/ (3), themes/, skills/ (44 AGGG), db-tools/, docs/canon/ (27), scripts/tools (аудит, батл, судья), watchdog/ |
| `install/` | скриптовая установка: setup.py (раскладка+бэкап+верификация), doctor.py (постинсталльный чек), bootstrap.ps1/.sh, install_camoufox.py |
| `INSTALL.md` | полная инструкция — скормить агенту на новой машине |

## Быстрый старт

```powershell
python install\setup.py --check      # план
python install\setup.py --apply      # раскладка + бэкап + проверки
python install\doctor.py             # постинсталльный чек
python install\install_camoufox.py --apply   # MCP-сервер camoufox
```

Затем выполни ручные шаги INSTALL.md: LSP, RAG-базы, MCP-данные, Nerd Font, финальный чек-лист.

Подробности — в `INSTALL.md` (скорми его содержимое агенту на новой машине целиком).